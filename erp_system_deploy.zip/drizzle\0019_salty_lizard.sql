ALTER TABLE `budgets` ADD `customerDocument` varchar(50);--> statement-breakpoint
ALTER TABLE `budgets` ADD `customerCity` varchar(100);--> statement-breakpoint
ALTER TABLE `budgets` ADD `customerState` varchar(2);--> statement-breakpoint
ALTER TABLE `budgets` ADD `customerZipCode` varchar(20);