ALTER TABLE `orders` ADD `customerName` varchar(255);--> statement-breakpoint
ALTER TABLE `orders` ADD `customerEmail` varchar(255);--> statement-breakpoint
ALTER TABLE `orders` ADD `customerPhone` varchar(50);--> statement-breakpoint
ALTER TABLE `orders` ADD `customerAddress` text;