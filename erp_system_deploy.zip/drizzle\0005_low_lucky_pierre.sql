ALTER TABLE `projects` ADD `meetingDate` timestamp;--> statement-breakpoint
ALTER TABLE `projects` ADD `approvalDate` timestamp;--> statement-breakpoint
ALTER TABLE `projects` ADD `reviewDate` timestamp;