ALTER TABLE `budgets` ADD `customerEmail` varchar(255);--> statement-breakpoint
ALTER TABLE `budgets` ADD `customerPhone` varchar(50);--> statement-breakpoint
ALTER TABLE `budgets` ADD `customerAddress` text;