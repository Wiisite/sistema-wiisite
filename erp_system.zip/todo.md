# Sistema ERP - TODO

## Infraestrutura e Autenticação
- [x] Sistema de autenticação com controle de acesso baseado em roles (admin/usuário)
- [x] Proteção de rotas e procedures baseada em roles

## Banco de Dados
- [x] Schema de clientes
- [x] Schema de produtos/serviços
- [x] Schema de pedidos e itens de pedido
- [x] Schema de fornecedores
- [x] Schema de contas a pagar
- [x] Schema de contas a receber
- [x] Schema de categorias financeiras
- [x] Helpers de consulta para todos os módulos

## Design System e Layout
- [x] Configurar tema elegante com paleta de cores profissional
- [x] Implementar DashboardLayout com sidebar responsiva
- [x] Criar componentes reutilizáveis para formulários
- [x] Criar componentes reutilizáveis para tabelas de dados
- [x] Implementar navegação entre módulos

## Módulo de Gestão de Clientes
- [x] Página de listagem de clientes
- [x] Formulário de cadastro/edição de clientes
- [x] Validação de dados de clientes
- [x] Busca e filtros de clientes

## Módulo de Gestão de Produtos/Serviços
- [x] Página de listagem de produtos
- [x] Formulário de cadastro/edição de produtos
- [x] Controle de preços e categorias
- [x] Busca e filtros de produtos

## Módulo de Gestão de Vendas e Pedidos
- [x] Página de criação de pedidos
- [x] Seleção de cliente e produtos
- [x] Cálculo automático de totais
- [x] Página de listagem de pedidos com pipeline visual
- [x] Atualização de status de pedidos (pendente, aprovado, em produção, concluído, cancelado)
- [x] Histórico detalhado de pedidos
- [x] Filtros por status e período

## Módulo Financeiro - Contas a Pagar
- [x] Página de listagem de contas a pagar
- [x] Cadastro de fornecedores
- [x] Formulário de cadastro de contas a pagar
- [x] Categorização de despesas
- [x] Controle de vencimentos e pagamentos
- [x] Filtros por status, período e fornecedor
- [x] Marcação de contas como pagas

## Módulo Financeiro - Contas a Receber
- [x] Página de listagem de contas a receber
- [x] Vinculação com pedidos
- [x] Controle de vencimentos e recebimentos
- [x] Status de pagamento (pendente, pago, atrasado)
- [x] Filtros por status e período
- [x] Marcação de contas como recebidas

## Dashboard Gerencial
- [x] Cards com indicadores-chave (KPIs)
- [x] Total de vendas do período
- [x] Total de contas a pagar
- [x] Total de contas a receber
- [x] Saldo atual (a receber - a pagar)
- [x] Gráfico de fluxo de caixa mensal
- [x] Gráfico de vendas por período
- [x] Gráfico de despesas por categoria
- [x] Filtros de período no dashboard

## Sistema de Relatórios
- [x] Relatório de vendas por período
- [x] Relatório financeiro consolidado
- [x] Relatório de contas a pagar
- [x] Relatório de contas a receber
- [x] Exportação em formato CSV/Excel
- [x] Filtros personalizados para relatórios

## Testes e Qualidade
- [x] Testes vitest para procedures de autenticação
- [x] Testes vitest para procedures de vendas
- [x] Testes vitest para procedures financeiras
- [x] Validação de responsividade mobile
- [x] Validação de controle de acesso por roles

## Entrega Final
- [x] Checkpoint final com todas as funcionalidades
- [x] Documentação de uso do sistema

## Módulo de Gestão de Projetos
- [x] Schema de projetos no banco de dados
- [x] Página de gestão de projetos com cards visuais
- [x] Cards com status, progresso, prazo e valor
- [x] Formulário de criação/edição de projetos
- [x] Atualização de progresso e status
- [x] Filtros por status e busca

## Módulo de Calendário
- [x] Schema de eventos/reuniões no banco de dados
- [x] Página de calendário estilo Google Calendar
- [x] Visualização mensal de eventos
- [x] Criação de visitas e reuniões
- [x] Edição e exclusão de eventos
- [x] Vinculação de eventos com clientes/projetos

## Correções de Bugs
- [x] Corrigir erro de Select.Item com valor vazio na página de Projetos
- [x] Corrigir erro SQL na query de fluxo de caixa (receivedDate NULL)
- [x] Corrigir erro de Select.Item com valor vazio na página de Calendário

## Melhorias no Calendário
- [x] Adicionar seção de avisos financeiros na base do calendário
- [x] Mostrar contas a pagar vencendo no mês
- [x] Mostrar contas a receber pendentes no mês

## Módulo CRM / Comercial
- [x] Schema de leads no banco de dados
- [x] Campos: origem, etapa do funil, valor estimado, responsável
- [x] Pipeline Kanban configurável com drag-and-drop
- [x] Atividades: ligação, reunião, follow-up
- [x] Propostas comerciais com itens e impostos
- [ ] Conversão de proposta em contrato e projeto
- [x] Página de gestão de leads com filtros
- [x] Visualização de pipeline Kanban

## Módulo de Contratos e Recorrência
- [x] Schema de contratos no banco de dados
- [x] Campos: vigência, mensalidade, reajuste, itens
- [x] Alertas de renovação e vencimentos
- [x] Contratos recorrentes (manutenção/hospedagem)
- [ ] Geração automática de contas a receber
- [x] Página de gestão de contratos
- [x] Dashboard de contratos ativos/vencendo

## Expansão do Módulo de Projetos
- [ ] Adicionar status detalhados (briefing → layout → dev → revisão → publicação → pós)
- [ ] Checklist template por tipo de projeto
- [ ] Visualização Kanban/Sprints
- [ ] Atribuição de responsáveis e prazos por etapa
- [ ] Vinculação de projetos com contratos

## Módulo de Tarefas e Timesheet
- [x] Schema de tarefas no banco de dados
- [x] Campos: prioridade, prazo, estimativa, responsável
- [x] Apontamento de horas por tarefa e projeto
- [ ] Relatório de horas por cliente/colaborador/mês
- [ ] Página de gestão de tarefas
- [ ] Interface de timesheet para apontamento

## Módulo de Suporte / Chamados
- [x] Schema de chamados no banco de dados
- [x] SLA configurável (4h/24h/72h)
- [x] Categorias: bug, ajuste, conteúdo, financeiro
- [x] Comentários, histórico e anexos
- [ ] Base de conhecimento interna
- [ ] Página de gestão de chamados
- [ ] Portal de abertura de chamados

## Melhorias Financeiras
- [ ] Contas a receber avulsas e recorrentes
- [ ] Geração automática a partir de contratos
- [ ] Alertas automáticos de inadimplência
- [ ] Fluxo de caixa e DRE simplificado
- [ ] Centro de custo para contas a pagar

## Sistema de Pagamentos Recorrentes
- [x] Adicionar campo de recorrência em produtos
- [x] Schema de despesas operacionais recorrentes
- [x] Categorias pré-definidas (luz, água, telefone, internet, aluguel)
- [x] Geração automática de contas a pagar mensais
- [x] Página de gestão de despesas operacionais
- [x] Histórico de pagamentos recorrentes
- [x] Corrigir erro de Select.Item com valor vazio na página de Contas a Receber
- [x] Corrigir erro SQL na query getMonthlyCashFlow do dashboard

## Script de Seed
- [x] Criar script de seed com dados de exemplo
- [x] Popular clientes, fornecedores e produtos
- [x] Gerar pedidos e transações financeiras
- [x] Criar projetos de exemplo
- [ ] Adicionar leads, contratos e eventos (enums incompatíveis)

## Implementação de Tarefas e Suporte
- [ ] Criar página de Tarefas com visualização Kanban
- [ ] Implementar formulário de criação/edição de tarefas
- [ ] Adicionar interface de timesheet para apontamento de horas
- [ ] Criar página de Suporte/Chamados com lista de tickets
- [ ] Implementar sistema de SLA automático
- [ ] Adicionar sistema de comentários nos chamados
- [ ] Criar filtros por status, prioridade e categoria

## Nova Implementação - Tarefas e Suporte
- [x] Criar página de Tarefas com visualização Kanban
- [ ] Implementar drag-and-drop entre colunas de status
- [x] Adicionar formulário de criação/edição de tarefas
- [x] Criar página de Suporte/Chamados com lista de tickets
- [x] Implementar abas por status de chamados
- [x] Adicionar formulário de criação de tickets
- [x] Implementar sistema de mudança de status
- [x] Adicionar rotas no App.tsx e DashboardLayout

## Drag-and-Drop no Kanban de Tarefas
- [x] Instalar biblioteca @dnd-kit para drag-and-drop
- [x] Implementar drag-and-drop entre colunas do Kanban
- [x] Atualizar status da tarefa ao soltar em nova coluna
- [x] Adicionar feedback visual durante o arraste

## Bug - Drag-and-Drop não funciona
- [x] Investigar por que cards não movem entre colunas
- [x] Corrigir configuração do DndContext
- [x] Adicionar droppable zones nas colunas

## Kanban de Projetos
- [x] Transformar página de Projetos em visualização Kanban
- [x] Implementar drag-and-drop entre status de projetos
- [x] Adicionar botão de edição em cada card de projeto
- [x] Criar modal de edição rápida de projetos

## Botão de Remover no Kanban de Projetos
- [x] Adicionar botão de excluir (ícone Trash2) em cada card de projeto
- [x] Implementar confirmação antes de excluir projeto
- [x] Criar procedure tRPC para deletar projeto
- [x] Atualizar UI após exclusão com feedback visual

## Bug - Erro ao arrastar projeto no Kanban
- [x] Corrigir erro de validação ao arrastar projeto entre colunas
- [x] Ajustar handleDragEnd para enviar apenas campos necessários na atualização

## Bug Persistente - Erro de validação no drag-and-drop
- [x] Investigar por que o erro de validação ainda ocorre - over.id retorna ID do projeto ao invés do status
- [x] Verificar se o status está vindo como null ou undefined
- [x] Adicionar logs para debug do valor do status
- [ ] Corrigir DroppableColumn para usar useDroppable corretamente
- [ ] Ajustar handleDragEnd para pegar status da coluna, não do over.id
