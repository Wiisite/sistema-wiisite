import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { AlertCircle, Calendar, DollarSign, FileText, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const statusMap = {
  active: { label: "Ativo", color: "bg-green-500" },
  suspended: { label: "Suspenso", color: "bg-yellow-500" },
  cancelled: { label: "Cancelado", color: "bg-red-500" },
  expired: { label: "Expirado", color: "bg-gray-500" },
};

const contractTypeMap = {
  maintenance: "Manutenção",
  hosting: "Hospedagem",
  support: "Suporte",
  other: "Outro",
};

export default function Contracts() {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    customerId: "",
    title: "",
    description: "",
    contractType: "maintenance",
    monthlyValue: "",
    startDate: "",
    endDate: "",
    renewalDate: "",
    billingDay: "1",
    notes: "",
  });

  const { data: contracts, refetch } = trpc.contracts.list.useQuery();
  const { data: customers } = trpc.customers.list.useQuery();

  const createMutation = trpc.contracts.create.useMutation({
    onSuccess: () => {
      toast.success("Contrato criado com sucesso!");
      setIsDialogOpen(false);
      refetch();
      setFormData({
        customerId: "",
        title: "",
        description: "",
        contractType: "maintenance",
        monthlyValue: "",
        startDate: "",
        endDate: "",
        renewalDate: "",
        billingDay: "1",
        notes: "",
      });
    },
    onError: (error) => {
      toast.error("Erro ao criar contrato: " + error.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createMutation.mutate({
      customerId: parseInt(formData.customerId),
      title: formData.title,
      description: formData.description,
      contractType: formData.contractType as any,
      monthlyValue: formData.monthlyValue,
      startDate: new Date(formData.startDate),
      endDate: formData.endDate ? new Date(formData.endDate) : undefined,
      renewalDate: formData.renewalDate ? new Date(formData.renewalDate) : undefined,
      billingDay: parseInt(formData.billingDay),
      notes: formData.notes,
    });
  };

  const formatPrice = (value: string | null) => {
    if (!value) return "R$ 0,00";
    return `R$ ${parseFloat(value).toLocaleString("pt-BR", {
      minimumFractionDigits: 2,
    })}`;
  };

  const formatDate = (date: Date | string | null) => {
    if (!date) return "-";
    return new Date(date).toLocaleDateString("pt-BR");
  };

  const isExpiringSoon = (renewalDate: Date | string | null) => {
    if (!renewalDate) return false;
    const renewal = new Date(renewalDate);
    const today = new Date();
    const diffDays = Math.ceil((renewal.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return diffDays <= 30 && diffDays >= 0;
  };

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Contratos</h1>
            <p className="text-muted-foreground">
              Gerencie contratos recorrentes e renovações
            </p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Novo Contrato
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Criar Novo Contrato</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label htmlFor="customerId">Cliente *</Label>
                    <Select
                      value={formData.customerId}
                      onValueChange={(value) =>
                        setFormData({ ...formData, customerId: value })
                      }
                      required
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione um cliente" />
                      </SelectTrigger>
                      <SelectContent>
                        {customers?.map((c: any) => (
                          <SelectItem key={c.id} value={c.id.toString()}>
                            {c.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="title">Título do Contrato *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) =>
                        setFormData({ ...formData, title: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="contractType">Tipo *</Label>
                    <Select
                      value={formData.contractType}
                      onValueChange={(value) =>
                        setFormData({ ...formData, contractType: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.entries(contractTypeMap).map(([key, label]) => (
                          <SelectItem key={key} value={key}>
                            {label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="monthlyValue">Valor Mensal *</Label>
                    <Input
                      id="monthlyValue"
                      type="number"
                      step="0.01"
                      value={formData.monthlyValue}
                      onChange={(e) =>
                        setFormData({ ...formData, monthlyValue: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="startDate">Data de Início *</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={formData.startDate}
                      onChange={(e) =>
                        setFormData({ ...formData, startDate: e.target.value })
                      }
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="endDate">Data de Término</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={formData.endDate}
                      onChange={(e) =>
                        setFormData({ ...formData, endDate: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="renewalDate">Data de Renovação</Label>
                    <Input
                      id="renewalDate"
                      type="date"
                      value={formData.renewalDate}
                      onChange={(e) =>
                        setFormData({ ...formData, renewalDate: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <Label htmlFor="billingDay">Dia de Cobrança</Label>
                    <Input
                      id="billingDay"
                      type="number"
                      min="1"
                      max="31"
                      value={formData.billingDay}
                      onChange={(e) =>
                        setFormData({ ...formData, billingDay: e.target.value })
                      }
                    />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="description">Descrição</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) =>
                        setFormData({ ...formData, description: e.target.value })
                      }
                      rows={3}
                    />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="notes">Observações</Label>
                    <Textarea
                      id="notes"
                      value={formData.notes}
                      onChange={(e) =>
                        setFormData({ ...formData, notes: e.target.value })
                      }
                      rows={2}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                  >
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={createMutation.isPending}>
                    {createMutation.isPending ? "Criando..." : "Criar Contrato"}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Alertas de Renovação */}
        {contracts && contracts.filter((c: any) => isExpiringSoon(c.contract.renewalDate)).length > 0 && (
          <Card className="border-yellow-500 bg-yellow-50">
            <CardHeader>
              <CardTitle className="text-sm flex items-center gap-2 text-yellow-700">
                <AlertCircle className="h-4 w-4" />
                Contratos com Renovação Próxima (30 dias)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {contracts
                  ?.filter((c: any) => isExpiringSoon(c.contract.renewalDate))
                  .map((item: any) => (
                    <div
                      key={item.contract.id}
                      className="flex items-center justify-between p-2 bg-white rounded"
                    >
                      <div>
                        <p className="font-medium">{item.contract.title}</p>
                        <p className="text-sm text-muted-foreground">
                          {item.customer?.name}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">
                          Renovação: {formatDate(item.contract.renewalDate)}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {formatPrice(item.contract.monthlyValue)}/mês
                        </p>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tabela de Contratos */}
        <Card>
          <CardHeader>
            <CardTitle>Todos os Contratos</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Cliente</TableHead>
                  <TableHead>Título</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Valor Mensal</TableHead>
                  <TableHead>Início</TableHead>
                  <TableHead>Renovação</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {contracts && contracts.length > 0 ? contracts.map((item: any) => (
                  <TableRow key={item.contract.id}>
                    <TableCell className="font-medium">
                      {item.customer?.name || "-"}
                    </TableCell>
                    <TableCell>{item.contract.title}</TableCell>
                    <TableCell>
                      {contractTypeMap[item.contract.contractType as keyof typeof contractTypeMap]}
                    </TableCell>
                    <TableCell>{formatPrice(item.contract.monthlyValue)}</TableCell>
                    <TableCell>{formatDate(item.contract.startDate)}</TableCell>
                    <TableCell>
                      {isExpiringSoon(item.contract.renewalDate) ? (
                        <span className="flex items-center gap-1 text-yellow-600">
                          <AlertCircle className="h-3 w-3" />
                          {formatDate(item.contract.renewalDate)}
                        </span>
                      ) : (
                        formatDate(item.contract.renewalDate)
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge
                        className={`${statusMap[item.contract.status as keyof typeof statusMap].color} text-white`}
                      >
                        {statusMap[item.contract.status as keyof typeof statusMap].label}
                      </Badge>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center text-muted-foreground">
                      Nenhum contrato encontrado
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
