import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { AlertCircle, Calendar, CheckCircle2, Clock, GripVertical, ListTodo, Plus } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import {
  DndContext,
  DragEndEvent,
  DragOverlay,
  DragStartEvent,
  PointerSensor,
  closestCorners,
  useSensor,
  useSensors,
  useDroppable,
} from "@dnd-kit/core";
import { SortableContext, useSortable, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

type TaskStatus = "todo" | "in_progress" | "review" | "done" | "cancelled";
type TaskPriority = "low" | "medium" | "high" | "urgent";

const statusConfig: Record<TaskStatus, { label: string; icon: any; color: string }> = {
  todo: { label: "A Fazer", icon: ListTodo, color: "bg-gray-100 text-gray-700 border-gray-300" },
  in_progress: { label: "Em Progresso", icon: Clock, color: "bg-blue-100 text-blue-700 border-blue-300" },
  review: { label: "Em Revisão", icon: AlertCircle, color: "bg-yellow-100 text-yellow-700 border-yellow-300" },
  done: { label: "Concluído", icon: CheckCircle2, color: "bg-green-100 text-green-700 border-green-300" },
  cancelled: { label: "Cancelado", icon: AlertCircle, color: "bg-red-100 text-red-700 border-red-300" },
};

const priorityColors: Record<TaskPriority, string> = {
  low: "bg-gray-200 text-gray-700",
  medium: "bg-blue-200 text-blue-700",
  high: "bg-orange-200 text-orange-700",
  urgent: "bg-red-200 text-red-700",
};

interface TaskCardProps {
  item: any;
  isDragging?: boolean;
}

function TaskCard({ item, isDragging }: TaskCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging: isSortableDragging,
  } = useSortable({ id: item.task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isSortableDragging || isDragging ? 0.5 : 1,
  };

  return (
    <Card
      ref={setNodeRef}
      style={style}
      className="p-3 hover:shadow-md transition-shadow cursor-grab active:cursor-grabbing"
    >
      <div className="space-y-2">
        <div className="flex items-start gap-2">
          <div {...attributes} {...listeners} className="mt-1 cursor-grab active:cursor-grabbing">
            <GripVertical className="h-4 w-4 text-muted-foreground" />
          </div>
          <div className="flex-1 space-y-2">
            <h4 className="font-semibold text-sm line-clamp-2">{item.task.title}</h4>
            {item.task.description && (
              <p className="text-xs text-muted-foreground line-clamp-2">{item.task.description}</p>
            )}
            <div className="flex items-center gap-2 flex-wrap">
              <span
                className={`text-xs px-2 py-0.5 rounded-full ${priorityColors[item.task.priority as TaskPriority]}`}
              >
                {item.task.priority === "low" && "Baixa"}
                {item.task.priority === "medium" && "Média"}
                {item.task.priority === "high" && "Alta"}
                {item.task.priority === "urgent" && "Urgente"}
              </span>
              {item.task.dueDate && (
                <span className="text-xs flex items-center gap-1 text-muted-foreground">
                  <Calendar className="h-3 w-3" />
                  {new Date(item.task.dueDate).toLocaleDateString("pt-BR")}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}

function DroppableColumn({ status, children }: { status: TaskStatus; children: React.ReactNode }) {
  const { setNodeRef, isOver } = useDroppable({
    id: status,
  });

  return (
    <div
      ref={setNodeRef}
      className={`flex-1 p-3 space-y-2 bg-muted/20 min-h-[200px] rounded-b-lg transition-colors ${
        isOver ? "bg-primary/10 ring-2 ring-primary" : ""
      }`}
    >
      {children}
    </div>
  );
}

export default function Tasks() {
  const { user } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [activeId, setActiveId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    priority: "medium" as TaskPriority,
    dueDate: "",
  });

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const { data: tasks, refetch } = trpc.tasks.list.useQuery();

  const createMutation = trpc.tasks.create.useMutation({
    onSuccess: () => {
      toast.success("Tarefa criada com sucesso!");
      refetch();
      setIsDialogOpen(false);
      setFormData({ title: "", description: "", priority: "medium", dueDate: "" });
    },
    onError: (error) => {
      toast.error(`Erro ao criar tarefa: ${error.message}`);
    },
  });

  const updateMutation = trpc.tasks.update.useMutation({
    onSuccess: () => {
      toast.success("Tarefa movida com sucesso!");
      refetch();
    },
    onError: (error) => {
      toast.error(`Erro ao mover tarefa: ${error.message}`);
    },
  });

  const handleCreate = () => {
    if (!formData.title.trim()) {
      toast.error("Título é obrigatório");
      return;
    }

    createMutation.mutate({
      title: formData.title,
      description: formData.description || undefined,
      priority: formData.priority,
      dueDate: formData.dueDate ? new Date(formData.dueDate) : undefined,
    });
  };

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as number);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);

    if (!over) return;

    const taskId = active.id as number;
    const newStatus = over.id as TaskStatus;

    // Encontrar a tarefa atual
    const currentTask = (tasks || []).find((item) => item.task.id === taskId);
    if (!currentTask) return;

    const currentStatus = currentTask.task.status as TaskStatus;

    // Se mudou de coluna, atualizar o status
    if (currentStatus !== newStatus) {
      updateMutation.mutate({
        id: taskId,
        data: {
          status: newStatus,
          completedDate: newStatus === "done" ? new Date() : undefined,
        },
      });
    }
  };

  const tasksByStatus = (tasks || []).reduce((acc, item) => {
    const status = item.task.status as TaskStatus;
    if (!acc[status]) acc[status] = [];
    acc[status].push(item);
    return acc;
  }, {} as Record<TaskStatus, typeof tasks>);

  const activeTask = activeId ? (tasks || []).find((item) => item.task.id === activeId) : null;

  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Tarefas</h1>
            <p className="text-muted-foreground">Arraste e solte tarefas entre as colunas</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Nova Tarefa
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Nova Tarefa</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Título *</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="Digite o título da tarefa"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Descrição</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Descreva a tarefa..."
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="priority">Prioridade</Label>
                  <Select
                    value={formData.priority}
                    onValueChange={(value) => setFormData({ ...formData, priority: value as TaskPriority })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Baixa</SelectItem>
                      <SelectItem value="medium">Média</SelectItem>
                      <SelectItem value="high">Alta</SelectItem>
                      <SelectItem value="urgent">Urgente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="dueDate">Data de Vencimento</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={formData.dueDate}
                    onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })}
                  />
                </div>
                <Button onClick={handleCreate} className="w-full" disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Criando..." : "Criar Tarefa"}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <DndContext
          sensors={sensors}
          collisionDetection={closestCorners}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {(["todo", "in_progress", "review", "done", "cancelled"] as TaskStatus[]).map((status) => {
              const config = statusConfig[status];
              const Icon = config.icon;
              const statusTasks = tasksByStatus[status] || [];

              return (
                <Card key={status} className="flex flex-col">
                  <CardHeader className={`${config.color} border-b-2`}>
                    <CardTitle className="flex items-center gap-2 text-sm font-semibold">
                      <Icon className="h-4 w-4" />
                      {config.label}
                      <span className="ml-auto text-xs">({statusTasks.length})</span>
                    </CardTitle>
                  </CardHeader>
                  <SortableContext
                    id={status}
                    items={statusTasks.map((item) => item.task.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    <DroppableColumn status={status}>
                      {statusTasks.map((item) => (
                        <TaskCard key={item.task.id} item={item} />
                      ))}
                      {statusTasks.length === 0 && (
                        <p className="text-xs text-center text-muted-foreground py-8">
                          Arraste tarefas aqui
                        </p>
                      )}
                    </DroppableColumn>
                  </SortableContext>
                </Card>
              );
            })}
          </div>

          <DragOverlay>
            {activeTask ? <TaskCard item={activeTask} isDragging /> : null}
          </DragOverlay>
        </DndContext>
      </div>
    </DashboardLayout>
  );
}
