import { and, desc, eq, gte, lte, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, 
  users, 
  customers, 
  InsertCustomer,
  products,
  InsertProduct,
  orders,
  InsertOrder,
  orderItems,
  InsertOrderItem,
  suppliers,
  InsertSupplier,
  financialCategories,
  InsertFinancialCategory,
  accountsPayable,
  InsertAccountPayable,
  accountsReceivable,
  InsertAccountReceivable,
  projects,
  InsertProject,
  calendarEvents,
  InsertCalendarEvent,
  leads,
  InsertLead,
  leadActivities,
  InsertLeadActivity,
  proposals,
  InsertProposal,
  proposalItems,
  InsertProposalItem,
  contracts,
  InsertContract,
  contractItems,
  tasks,
  InsertTask,
  timeEntries,
  InsertTimeEntry,
  tickets,
  InsertTicket,
  ticketComments,
  InsertTicketComment,
  projectChecklists,
  InsertProjectChecklist,
  recurringExpenses,
  InsertRecurringExpense,
  productSubscriptions,
  InsertProductSubscription
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER HELPERS ============

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ============ CUSTOMER HELPERS ============

export async function createCustomer(customer: InsertCustomer) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(customers).values(customer);
  return result;
}

export async function getCustomers(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(customers).orderBy(desc(customers.createdAt));
}

export async function getCustomerById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  return result[0];
}

export async function updateCustomer(id: number, data: Partial<InsertCustomer>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(customers).set(data).where(eq(customers.id, id));
}

export async function deleteCustomer(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.delete(customers).where(eq(customers.id, id));
}

// ============ PRODUCT HELPERS ============

export async function createProduct(product: InsertProduct) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(products).values(product);
  return result;
}

export async function getProducts(activeOnly: boolean = false) {
  const db = await getDb();
  if (!db) return [];
  
  if (activeOnly) {
    return await db.select().from(products).where(eq(products.active, "yes")).orderBy(desc(products.createdAt));
  }
  
  return await db.select().from(products).orderBy(desc(products.createdAt));
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result[0];
}

export async function updateProduct(id: number, data: Partial<InsertProduct>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(products).set(data).where(eq(products.id, id));
}

export async function deleteProduct(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.delete(products).where(eq(products.id, id));
}

// ============ ORDER HELPERS ============

export async function createOrder(order: InsertOrder, items: Omit<InsertOrderItem, 'orderId'>[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const orderResult = await db.insert(orders).values(order);
  const orderId = Number(orderResult[0].insertId);
  
  const itemsWithOrderId = items.map(item => ({ ...item, orderId }));
  await db.insert(orderItems).values(itemsWithOrderId);
  
  return orderId;
}

export async function getOrders(filters?: { status?: string; startDate?: Date; endDate?: Date }) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select({
    order: orders,
    customer: customers
  }).from(orders).leftJoin(customers, eq(orders.customerId, customers.id));
  
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(orders.status, filters.status as any));
  }
  if (filters?.startDate) {
    conditions.push(gte(orders.orderDate, filters.startDate));
  }
  if (filters?.endDate) {
    conditions.push(lte(orders.orderDate, filters.endDate));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }
  
  return await query.orderBy(desc(orders.createdAt));
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const orderResult = await db.select({
    order: orders,
    customer: customers
  }).from(orders)
    .leftJoin(customers, eq(orders.customerId, customers.id))
    .where(eq(orders.id, id))
    .limit(1);
  
  if (orderResult.length === 0) return undefined;
  
  const items = await db.select({
    item: orderItems,
    product: products
  }).from(orderItems)
    .leftJoin(products, eq(orderItems.productId, products.id))
    .where(eq(orderItems.orderId, id));
  
  return {
    ...orderResult[0],
    items
  };
}

export async function updateOrderStatus(id: number, status: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(orders).set({ status: status as any }).where(eq(orders.id, id));
}

// ============ SUPPLIER HELPERS ============

export async function createSupplier(supplier: InsertSupplier) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(suppliers).values(supplier);
  return result;
}

export async function getSuppliers() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(suppliers).orderBy(desc(suppliers.createdAt));
}

export async function getSupplierById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1);
  return result[0];
}

export async function updateSupplier(id: number, data: Partial<InsertSupplier>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(suppliers).set(data).where(eq(suppliers.id, id));
}

// ============ FINANCIAL CATEGORY HELPERS ============

export async function createFinancialCategory(category: InsertFinancialCategory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(financialCategories).values(category);
  return result;
}

export async function getFinancialCategories(type?: "expense" | "income") {
  const db = await getDb();
  if (!db) return [];
  
  if (type) {
    return await db.select().from(financialCategories).where(eq(financialCategories.type, type));
  }
  
  return await db.select().from(financialCategories);
}

// ============ ACCOUNTS PAYABLE HELPERS ============

export async function createAccountPayable(account: InsertAccountPayable) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(accountsPayable).values(account);
  return result;
}

export async function getAccountsPayable(filters?: { status?: string; startDate?: Date; endDate?: Date }) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select({
    account: accountsPayable,
    supplier: suppliers,
    category: financialCategories
  }).from(accountsPayable)
    .leftJoin(suppliers, eq(accountsPayable.supplierId, suppliers.id))
    .leftJoin(financialCategories, eq(accountsPayable.categoryId, financialCategories.id));
  
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(accountsPayable.status, filters.status as any));
  }
  if (filters?.startDate) {
    conditions.push(gte(accountsPayable.dueDate, filters.startDate));
  }
  if (filters?.endDate) {
    conditions.push(lte(accountsPayable.dueDate, filters.endDate));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }
  
  return await query.orderBy(desc(accountsPayable.dueDate));
}

export async function updateAccountPayable(id: number, data: Partial<InsertAccountPayable>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(accountsPayable).set(data).where(eq(accountsPayable.id, id));
}

export async function markAccountPayableAsPaid(id: number, paymentDate: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(accountsPayable).set({
    status: "paid",
    paymentDate
  }).where(eq(accountsPayable.id, id));
}

// ============ ACCOUNTS RECEIVABLE HELPERS ============

export async function createAccountReceivable(account: InsertAccountReceivable) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(accountsReceivable).values(account);
  return result;
}

export async function getAccountsReceivable(filters?: { status?: string; startDate?: Date; endDate?: Date }) {
  const db = await getDb();
  if (!db) return [];
  
  let query = db.select({
    account: accountsReceivable,
    customer: customers,
    order: orders
  }).from(accountsReceivable)
    .leftJoin(customers, eq(accountsReceivable.customerId, customers.id))
    .leftJoin(orders, eq(accountsReceivable.orderId, orders.id));
  
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(accountsReceivable.status, filters.status as any));
  }
  if (filters?.startDate) {
    conditions.push(gte(accountsReceivable.dueDate, filters.startDate));
  }
  if (filters?.endDate) {
    conditions.push(lte(accountsReceivable.dueDate, filters.endDate));
  }
  
  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }
  
  return await query.orderBy(desc(accountsReceivable.dueDate));
}

export async function updateAccountReceivable(id: number, data: Partial<InsertAccountReceivable>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(accountsReceivable).set(data).where(eq(accountsReceivable.id, id));
}

export async function markAccountReceivableAsReceived(id: number, receivedDate: Date) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(accountsReceivable).set({
    status: "received",
    receivedDate
  }).where(eq(accountsReceivable.id, id));
}

// ============ DASHBOARD HELPERS ============

export async function getDashboardStats(startDate?: Date, endDate?: Date) {
  const db = await getDb();
  if (!db) return null;
  
  const conditions = [];
  if (startDate) conditions.push(gte(orders.orderDate, startDate));
  if (endDate) conditions.push(lte(orders.orderDate, endDate));
  
  // Total de vendas
  const salesQuery = db.select({
    total: sql<string>`COALESCE(SUM(${orders.totalAmount}), 0)`
  }).from(orders).where(and(...conditions, eq(orders.status, "completed")));
  
  // Contas a pagar
  const payableQuery = db.select({
    pending: sql<string>`COALESCE(SUM(CASE WHEN ${accountsPayable.status} = 'pending' THEN ${accountsPayable.amount} ELSE 0 END), 0)`,
    paid: sql<string>`COALESCE(SUM(CASE WHEN ${accountsPayable.status} = 'paid' THEN ${accountsPayable.amount} ELSE 0 END), 0)`,
  }).from(accountsPayable);
  
  // Contas a receber
  const receivableQuery = db.select({
    pending: sql<string>`COALESCE(SUM(CASE WHEN ${accountsReceivable.status} = 'pending' THEN ${accountsReceivable.amount} ELSE 0 END), 0)`,
    received: sql<string>`COALESCE(SUM(CASE WHEN ${accountsReceivable.status} = 'received' THEN ${accountsReceivable.amount} ELSE 0 END), 0)`,
  }).from(accountsReceivable);
  
  const [salesResult, payableResult, receivableResult] = await Promise.all([
    salesQuery,
    payableQuery,
    receivableQuery
  ]);
  
  return {
    totalSales: parseFloat(salesResult[0]?.total || "0"),
    accountsPayable: {
      pending: parseFloat(payableResult[0]?.pending || "0"),
      paid: parseFloat(payableResult[0]?.paid || "0"),
    },
    accountsReceivable: {
      pending: parseFloat(receivableResult[0]?.pending || "0"),
      received: parseFloat(receivableResult[0]?.received || "0"),
    }
  };
}

// ============ PROJECT HELPERS ============

export async function getProjects(filters?: { status?: string }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select({
    project: projects,
    customer: customers,
  }).from(projects).leftJoin(customers, eq(projects.customerId, customers.id));

  if (filters?.status) {
    query = query.where(eq(projects.status, filters.status as any)) as any;
  }

  return await query.orderBy(desc(projects.createdAt));
}

export async function createProject(project: InsertProject) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(projects).values(project);
  return result;
}

export async function updateProject(id: number, data: Partial<InsertProject>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(projects).set(data).where(eq(projects.id, id));
}

export async function deleteProject(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(projects).where(eq(projects.id, id));
}

// ============ CALENDAR EVENT HELPERS ============

export async function getCalendarEvents(filters?: { startDate?: Date; endDate?: Date }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select({
    event: calendarEvents,
    customer: customers,
    project: projects,
  }).from(calendarEvents)
    .leftJoin(customers, eq(calendarEvents.customerId, customers.id))
    .leftJoin(projects, eq(calendarEvents.projectId, projects.id));

  if (filters?.startDate && filters?.endDate) {
    query = query.where(
      and(
        gte(calendarEvents.startDate, filters.startDate),
        lte(calendarEvents.endDate, filters.endDate)
      )
    ) as any;
  }

  return await query.orderBy(calendarEvents.startDate);
}

export async function createCalendarEvent(event: InsertCalendarEvent) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(calendarEvents).values(event);
  return result;
}

export async function updateCalendarEvent(id: number, data: Partial<InsertCalendarEvent>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(calendarEvents).set(data).where(eq(calendarEvents.id, id));
}

export async function deleteCalendarEvent(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(calendarEvents).where(eq(calendarEvents.id, id));
}

export async function getMonthlyCashFlow(year: number) {
  const db = await getDb();
  if (!db) return [];
  
  try {
    const receivables = await db.execute(sql`
      SELECT MONTH(receivedDate) as month, SUM(amount) as amount
      FROM accountsReceivable
      WHERE status = 'received'
        AND receivedDate IS NOT NULL
        AND YEAR(receivedDate) = ${year}
      GROUP BY MONTH(receivedDate)
    `);
    
    const payables = await db.execute(sql`
      SELECT MONTH(paymentDate) as month, SUM(amount) as amount
      FROM accountsPayable
      WHERE status = 'paid'
        AND paymentDate IS NOT NULL
        AND YEAR(paymentDate) = ${year}
      GROUP BY MONTH(paymentDate)
    `);
    
    const receivablesData = (receivables[0] as unknown) as any[];
    const payablesData = (payables[0] as unknown) as any[];
    
    const cashFlow = [];
    for (let month = 1; month <= 12; month++) {
      const income = receivablesData.find((r: any) => r.month === month);
      const expense = payablesData.find((p: any) => p.month === month);
      
      cashFlow.push({
        month,
        income: parseFloat(income?.amount || "0"),
        expense: parseFloat(expense?.amount || "0"),
        balance: parseFloat(income?.amount || "0") - parseFloat(expense?.amount || "0")
      });
    }
    
    return cashFlow;
  } catch (error) {
    console.error("Error in getMonthlyCashFlow:", error);
    // Return empty data for all months instead of failing
    return Array.from({ length: 12 }, (_, i) => ({
      month: i + 1,
      income: 0,
      expense: 0,
      balance: 0
    }));
  }
}

export async function getMonthlyFinancialAlerts(year: number, month: number) {
  const db = await getDb();
  if (!db) return { payables: [], receivables: [] };

  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59);

  const payables = await db.select({
    accountPayable: accountsPayable,
    supplier: suppliers,
    category: financialCategories,
  })
    .from(accountsPayable)
    .leftJoin(suppliers, eq(accountsPayable.supplierId, suppliers.id))
    .leftJoin(financialCategories, eq(accountsPayable.categoryId, financialCategories.id))
    .where(and(
      eq(accountsPayable.status, "pending"),
      gte(accountsPayable.dueDate, startDate),
      lte(accountsPayable.dueDate, endDate)
    ))
    .orderBy(accountsPayable.dueDate);

  const receivables = await db.select({
    accountReceivable: accountsReceivable,
    order: orders,
    customer: customers,
  })
    .from(accountsReceivable)
    .leftJoin(orders, eq(accountsReceivable.orderId, orders.id))
    .leftJoin(customers, eq(orders.customerId, customers.id))
    .where(and(
      eq(accountsReceivable.status, "pending"),
      gte(accountsReceivable.dueDate, startDate),
      lte(accountsReceivable.dueDate, endDate)
    ))
    .orderBy(accountsReceivable.dueDate);

  return { payables, receivables };
}

// ============ LEADS / CRM ============

export async function getLeads(filters?: { stage?: string; assignedTo?: number }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select({
    lead: leads,
    assignedUser: users,
  })
    .from(leads)
    .leftJoin(users, eq(leads.assignedTo, users.id));

  const conditions = [];
  if (filters?.stage) conditions.push(eq(leads.stage, filters.stage as any));
  if (filters?.assignedTo) conditions.push(eq(leads.assignedTo, filters.assignedTo));

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  return await query.orderBy(desc(leads.createdAt));
}

export async function createLead(data: InsertLead) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(leads).values(data);
  return result;
}

export async function updateLead(id: number, data: Partial<InsertLead>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(leads).set(data).where(eq(leads.id, id));
  return { success: true };
}

export async function getLeadActivities(leadId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select({
    activity: leadActivities,
    creator: users,
  })
    .from(leadActivities)
    .leftJoin(users, eq(leadActivities.createdBy, users.id))
    .where(eq(leadActivities.leadId, leadId))
    .orderBy(desc(leadActivities.createdAt));
}

export async function createLeadActivity(data: InsertLeadActivity) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(leadActivities).values(data);
  return result;
}

// ============ PROPOSALS ============

export async function getProposals(filters?: { status?: string }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select({
    proposal: proposals,
    lead: leads,
    customer: customers,
    creator: users,
  })
    .from(proposals)
    .leftJoin(leads, eq(proposals.leadId, leads.id))
    .leftJoin(customers, eq(proposals.customerId, customers.id))
    .leftJoin(users, eq(proposals.createdBy, users.id));

  if (filters?.status) {
    query = query.where(eq(proposals.status, filters.status as any)) as any;
  }

  return await query.orderBy(desc(proposals.createdAt));
}

export async function createProposal(data: InsertProposal) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(proposals).values(data);
  return result;
}

export async function getProposalItems(proposalId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select()
    .from(proposalItems)
    .where(eq(proposalItems.proposalId, proposalId));
}

export async function createProposalItem(data: InsertProposalItem) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(proposalItems).values(data);
  return result;
}

// ============ CONTRACTS ============

export async function getContracts(filters?: { status?: string; customerId?: number }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select({
    contract: contracts,
    customer: customers,
    creator: users,
  })
    .from(contracts)
    .leftJoin(customers, eq(contracts.customerId, customers.id))
    .leftJoin(users, eq(contracts.createdBy, users.id));

  const conditions = [];
  if (filters?.status) conditions.push(eq(contracts.status, filters.status as any));
  if (filters?.customerId) conditions.push(eq(contracts.customerId, filters.customerId));

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  return await query.orderBy(desc(contracts.createdAt));
}

export async function createContract(data: InsertContract) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(contracts).values(data);
  return result;
}

export async function updateContract(id: number, data: Partial<InsertContract>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(contracts).set(data).where(eq(contracts.id, id));
  return { success: true };
}

export async function getContractItems(contractId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select()
    .from(contractItems)
    .where(eq(contractItems.contractId, contractId));
}

// ============ TASKS ============

export async function getTasks(filters?: { status?: string; projectId?: number; assignedTo?: number }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select({
    task: tasks,
    project: projects,
    assignedUser: users,
    creator: users,
  })
    .from(tasks)
    .leftJoin(projects, eq(tasks.projectId, projects.id))
    .leftJoin(users, eq(tasks.assignedTo, users.id));

  const conditions = [];
  if (filters?.status) conditions.push(eq(tasks.status, filters.status as any));
  if (filters?.projectId) conditions.push(eq(tasks.projectId, filters.projectId));
  if (filters?.assignedTo) conditions.push(eq(tasks.assignedTo, filters.assignedTo));

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  return await query.orderBy(desc(tasks.createdAt));
}

export async function createTask(data: InsertTask) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(tasks).values(data);
  return result;
}

export async function updateTask(id: number, data: Partial<InsertTask>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(tasks).set(data).where(eq(tasks.id, id));
  return { success: true };
}

// ============ TIME ENTRIES ============

export async function getTimeEntries(filters?: { userId?: number; projectId?: number; startDate?: Date; endDate?: Date }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select({
    timeEntry: timeEntries,
    task: tasks,
    project: projects,
    user: users,
  })
    .from(timeEntries)
    .leftJoin(tasks, eq(timeEntries.taskId, tasks.id))
    .leftJoin(projects, eq(timeEntries.projectId, projects.id))
    .leftJoin(users, eq(timeEntries.userId, users.id));

  const conditions = [];
  if (filters?.userId) conditions.push(eq(timeEntries.userId, filters.userId));
  if (filters?.projectId) conditions.push(eq(timeEntries.projectId, filters.projectId));
  if (filters?.startDate) conditions.push(gte(timeEntries.date, filters.startDate));
  if (filters?.endDate) conditions.push(lte(timeEntries.date, filters.endDate));

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  return await query.orderBy(desc(timeEntries.date));
}

export async function createTimeEntry(data: InsertTimeEntry) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(timeEntries).values(data);
  return result;
}

// ============ TICKETS / SUPPORT ============

export async function getTickets(filters?: { status?: string; customerId?: number; assignedTo?: number }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select({
    ticket: tickets,
    customer: customers,
    assignedUser: users,
    creator: users,
  })
    .from(tickets)
    .leftJoin(customers, eq(tickets.customerId, customers.id))
    .leftJoin(users, eq(tickets.assignedTo, users.id));

  const conditions = [];
  if (filters?.status) conditions.push(eq(tickets.status, filters.status as any));
  if (filters?.customerId) conditions.push(eq(tickets.customerId, filters.customerId));
  if (filters?.assignedTo) conditions.push(eq(tickets.assignedTo, filters.assignedTo));

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  return await query.orderBy(desc(tickets.createdAt));
}

export async function createTicket(data: InsertTicket) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Calculate due date based on SLA
  const now = new Date();
  let dueDate = new Date(now);
  
  switch (data.sla) {
    case "4h":
      dueDate.setHours(dueDate.getHours() + 4);
      break;
    case "24h":
      dueDate.setHours(dueDate.getHours() + 24);
      break;
    case "72h":
      dueDate.setHours(dueDate.getHours() + 72);
      break;
  }
  
  const result = await db.insert(tickets).values({ ...data, dueDate });
  return result;
}

export async function updateTicket(id: number, data: Partial<InsertTicket>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(tickets).set(data).where(eq(tickets.id, id));
  return { success: true };
}

export async function getTicketComments(ticketId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select({
    comment: ticketComments,
    creator: users,
  })
    .from(ticketComments)
    .leftJoin(users, eq(ticketComments.createdBy, users.id))
    .where(eq(ticketComments.ticketId, ticketId))
    .orderBy(ticketComments.createdAt);
}

export async function createTicketComment(data: InsertTicketComment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(ticketComments).values(data);
  return result;
}

// ============ PROJECT CHECKLISTS ============

export async function getProjectChecklists(projectId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select()
    .from(projectChecklists)
    .where(eq(projectChecklists.projectId, projectId))
    .orderBy(projectChecklists.order);
}

export async function createProjectChecklist(data: InsertProjectChecklist) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(projectChecklists).values(data);
  return result;
}

export async function updateProjectChecklist(id: number, data: Partial<InsertProjectChecklist>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(projectChecklists).set(data).where(eq(projectChecklists.id, id));
  return { success: true };
}

// ============ RECURRING EXPENSES ============

export async function getRecurringExpenses(filters?: { status?: string; category?: string }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select({
    expense: recurringExpenses,
    supplier: suppliers,
    creator: users,
  })
    .from(recurringExpenses)
    .leftJoin(suppliers, eq(recurringExpenses.supplierId, suppliers.id))
    .leftJoin(users, eq(recurringExpenses.createdBy, users.id));

  const conditions = [];
  if (filters?.status) conditions.push(eq(recurringExpenses.status, filters.status as any));
  if (filters?.category) conditions.push(eq(recurringExpenses.category, filters.category as any));

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  return await query.orderBy(desc(recurringExpenses.createdAt));
}

export async function createRecurringExpense(data: InsertRecurringExpense) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(recurringExpenses).values(data);
  return result;
}

export async function updateRecurringExpense(id: number, data: Partial<InsertRecurringExpense>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(recurringExpenses).set(data).where(eq(recurringExpenses.id, id));
  return { success: true };
}

export async function generateRecurringExpensePayments() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const currentDay = now.getDate();
  
  // Get active recurring expenses that should be generated today
  const expensesToGenerate = await db.select()
    .from(recurringExpenses)
    .where(and(
      eq(recurringExpenses.status, "active"),
      eq(recurringExpenses.dayOfMonth, currentDay)
    ));

  const generated = [];
  
  for (const expense of expensesToGenerate) {
    // Check if already generated this month
    if (expense.lastGenerated) {
      const lastGen = new Date(expense.lastGenerated);
      if (lastGen.getMonth() === now.getMonth() && lastGen.getFullYear() === now.getFullYear()) {
        continue; // Already generated this month
      }
    }

    // Create account payable
    const dueDate = new Date(now.getFullYear(), now.getMonth(), expense.dayOfMonth);
    
    const payableData: any = {
      amount: expense.amount,
      dueDate,
      status: "pending",
      description: `${expense.name} - ${now.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}`,
      notes: `Gerado automaticamente de despesa recorrente #${expense.id}`,
      createdBy: expense.createdBy,
    };
    
    if (expense.supplierId) {
      payableData.supplierId = expense.supplierId;
    }
    
    await db.insert(accountsPayable).values(payableData);

    // Update last generated date
    await db.update(recurringExpenses)
      .set({ lastGenerated: now })
      .where(eq(recurringExpenses.id, expense.id));

    generated.push(expense.id);
  }

  return { generated: generated.length, ids: generated };
}

// ============ PRODUCT SUBSCRIPTIONS ============

export async function getProductSubscriptions(filters?: { status?: string; customerId?: number }) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select({
    subscription: productSubscriptions,
    product: products,
    customer: customers,
    creator: users,
  })
    .from(productSubscriptions)
    .leftJoin(products, eq(productSubscriptions.productId, products.id))
    .leftJoin(customers, eq(productSubscriptions.customerId, customers.id))
    .leftJoin(users, eq(productSubscriptions.createdBy, users.id));

  const conditions = [];
  if (filters?.status) conditions.push(eq(productSubscriptions.status, filters.status as any));
  if (filters?.customerId) conditions.push(eq(productSubscriptions.customerId, filters.customerId));

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  return await query.orderBy(desc(productSubscriptions.createdAt));
}

export async function createProductSubscription(data: InsertProductSubscription) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(productSubscriptions).values(data);
  return result;
}

export async function updateProductSubscription(id: number, data: Partial<InsertProductSubscription>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(productSubscriptions).set(data).where(eq(productSubscriptions.id, id));
  return { success: true };
}

export async function generateSubscriptionInvoices() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  
  // Get active subscriptions where next billing date is today or past
  const subscriptionsToBill = await db.select({
    subscription: productSubscriptions,
    customer: customers,
    product: products,
  })
    .from(productSubscriptions)
    .leftJoin(customers, eq(productSubscriptions.customerId, customers.id))
    .leftJoin(products, eq(productSubscriptions.productId, products.id))
    .where(and(
      eq(productSubscriptions.status, "active"),
      lte(productSubscriptions.nextBillingDate, now)
    ));

  const generated = [];

  for (const item of subscriptionsToBill) {
    const sub = item.subscription;
    const customer = item.customer;
    const product = item.product;

    if (!customer || !product) continue;

    // Create order for this subscription
    const orderNumber = `SUB-${sub.id}-${now.getTime()}`;
    const orderId = await createOrder(
      {
        orderNumber,
        customerId: sub.customerId,
        totalAmount: sub.price,
        status: "pending",
        orderDate: now,
        createdBy: sub.createdBy,
      },
      [
        {
          productId: sub.productId,
          quantity: "1",
          unitPrice: sub.price,
          subtotal: sub.price,
        },
      ]
    );

    // Create account receivable
    const dueDate = new Date(now);
    dueDate.setDate(dueDate.getDate() + 7); // 7 days to pay

    await db.insert(accountsReceivable).values({
      customerId: sub.customerId,
      amount: sub.price,
      dueDate,
      status: "pending",
      description: `Assinatura ${product.name} - ${now.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}`,
      notes: `Gerado automaticamente de assinatura #${sub.id}`,
      createdBy: sub.createdBy,
    });

    // Calculate next billing date
    let nextBilling = new Date(sub.nextBillingDate);
    switch (sub.frequency) {
      case "monthly":
        nextBilling.setMonth(nextBilling.getMonth() + 1);
        break;
      case "quarterly":
        nextBilling.setMonth(nextBilling.getMonth() + 3);
        break;
      case "yearly":
        nextBilling.setFullYear(nextBilling.getFullYear() + 1);
        break;
    }

    // Update subscription
    await db.update(productSubscriptions)
      .set({
        lastBilled: now,
        nextBillingDate: nextBilling,
      })
      .where(eq(productSubscriptions.id, sub.id));

    generated.push(sub.id);
  }

  return { generated: generated.length, ids: generated };
}
