import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { getCalendarEvents, createCalendarEvent, updateCalendarEvent, deleteCalendarEvent, getMonthlyFinancialAlerts } from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ============ CUSTOMERS ============
  customers: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getCustomers(ctx.user.id);
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getCustomerById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().email().optional().or(z.literal("")),
        phone: z.string().optional(),
        document: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
        state: z.string().max(2).optional(),
        zipCode: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const customer = {
          ...input,
          email: input.email || null,
          createdBy: ctx.user.id,
        };
        return await db.createCustomer(customer);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        email: z.string().email().optional().or(z.literal("")),
        phone: z.string().optional(),
        document: z.string().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
        state: z.string().max(2).optional(),
        zipCode: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        if (data.email === "") data.email = null as any;
        return await db.updateCustomer(id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteCustomer(input.id);
      }),
  }),

  // ============ PRODUCTS ============
  products: router({
    list: protectedProcedure
      .input(z.object({ activeOnly: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getProducts(input?.activeOnly);
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getProductById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        type: z.enum(["product", "service"]),
        price: z.string().regex(/^\d+(\.\d{1,2})?$/),
        unit: z.string().default("un"),
        category: z.string().optional(),
        active: z.enum(["yes", "no"]).default("yes"),
      }))
      .mutation(async ({ ctx, input }) => {
        const product = {
          ...input,
          createdBy: ctx.user.id,
        };
        return await db.createProduct(product);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        description: z.string().optional(),
        type: z.enum(["product", "service"]).optional(),
        price: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
        unit: z.string().optional(),
        category: z.string().optional(),
        active: z.enum(["yes", "no"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateProduct(id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteProduct(input.id);
      }),
  }),

  // ============ SUPPLIERS ============
  suppliers: router({
    list: protectedProcedure.query(async () => {
      return await db.getSuppliers();
    }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getSupplierById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        email: z.string().email().optional().or(z.literal("")),
        phone: z.string().optional(),
        document: z.string().optional(),
        address: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const supplier = {
          ...input,
          email: input.email || null,
          createdBy: ctx.user.id,
        };
        return await db.createSupplier(supplier);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        email: z.string().email().optional().or(z.literal("")),
        phone: z.string().optional(),
        document: z.string().optional(),
        address: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        if (data.email === "") data.email = null as any;
        return await db.updateSupplier(id, data);
      }),
  }),

  // ============ ORDERS ============
  orders: router({
    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getOrders(input);
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await db.getOrderById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        customerId: z.number(),
        orderNumber: z.string(),
        items: z.array(z.object({
          productId: z.number(),
          quantity: z.string(),
          unitPrice: z.string(),
          subtotal: z.string(),
        })),
        totalAmount: z.string(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const { items, ...orderData } = input;
        const order = {
          ...orderData,
          status: "pending" as const,
          createdBy: ctx.user.id,
        };
        return await db.createOrder(order, items);
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pending", "approved", "in_production", "completed", "cancelled"]),
      }))
      .mutation(async ({ input }) => {
        return await db.updateOrderStatus(input.id, input.status);
      }),
  }),

  // ============ FINANCIAL CATEGORIES ============
  financialCategories: router({
    list: protectedProcedure
      .input(z.object({ type: z.enum(["expense", "income"]).optional() }).optional())
      .query(async ({ input }) => {
        return await db.getFinancialCategories(input?.type);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        type: z.enum(["expense", "income"]),
        color: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const category = {
          ...input,
          createdBy: ctx.user.id,
        };
        return await db.createFinancialCategory(category);
      }),
  }),

  // ============ ACCOUNTS PAYABLE ============
  accountsPayable: router({
    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAccountsPayable(input);
      }),

    create: protectedProcedure
      .input(z.object({
        supplierId: z.number(),
        categoryId: z.number().optional(),
        description: z.string().min(1),
        amount: z.string().regex(/^\d+(\.\d{1,2})?$/),
        dueDate: z.date(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const account = {
          ...input,
          createdBy: ctx.user.id,
        };
        return await db.createAccountPayable(account);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        supplierId: z.number().optional(),
        categoryId: z.number().optional(),
        description: z.string().min(1).optional(),
        amount: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
        dueDate: z.date().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateAccountPayable(id, data);
      }),

    markAsPaid: protectedProcedure
      .input(z.object({
        id: z.number(),
        paymentDate: z.date(),
      }))
      .mutation(async ({ input }) => {
        return await db.markAccountPayableAsPaid(input.id, input.paymentDate);
      }),
  }),

  // ============ ACCOUNTS RECEIVABLE ============
  accountsReceivable: router({
    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getAccountsReceivable(input);
      }),

    create: protectedProcedure
      .input(z.object({
        orderId: z.number().optional(),
        customerId: z.number(),
        description: z.string().min(1),
        amount: z.string().regex(/^\d+(\.\d{1,2})?$/),
        dueDate: z.date(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        const account = {
          ...input,
          createdBy: ctx.user.id,
        };
        return await db.createAccountReceivable(account);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        orderId: z.number().optional(),
        customerId: z.number().optional(),
        description: z.string().min(1).optional(),
        amount: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
        dueDate: z.date().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateAccountReceivable(id, data);
      }),

    markAsReceived: protectedProcedure
      .input(z.object({
        id: z.number(),
        receivedDate: z.date(),
      }))
      .mutation(async ({ input }) => {
        return await db.markAccountReceivableAsReceived(input.id, input.receivedDate);
      }),
  }),

  // ============ PROJECTS ============
  projects: router({
    list: protectedProcedure
      .input(z.object({ status: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getProjects(input);
      }),

    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        customerId: z.number().optional(),
        status: z.enum(["development", "design", "launched", "cancelled"]),
        progress: z.number().min(0).max(100),
        value: z.string().regex(/^\d+(\.\d{1,2})?$/),
        deadline: z.date(),
      }))
      .mutation(async ({ ctx, input }) => {
        const project = {
          ...input,
          createdBy: ctx.user.id,
        };
        return await db.createProject(project);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        description: z.string().optional(),
        customerId: z.number().optional(),
        status: z.enum(["development", "design", "launched", "cancelled"]).optional(),
        progress: z.number().min(0).max(100).optional(),
        value: z.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
        deadline: z.date().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateProject(id, data);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        return await db.deleteProject(input.id);
      }),
  }),

  // ============ CALENDAR ============
  calendar: router({
      events: protectedProcedure
        .input(z.object({
          startDate: z.date().optional(),
          endDate: z.date().optional(),
        }).optional())
        .query(async ({ input }) => {
          return await getCalendarEvents(input);
        }),
      financialAlerts: protectedProcedure
        .input(z.object({
          year: z.number(),
          month: z.number(),
        }))
        .query(async ({ input }) => {
          return await getMonthlyFinancialAlerts(input.year, input.month);
        }),
      create: protectedProcedure
        .input(z.object({
          title: z.string(),
          description: z.string().optional(),
          eventType: z.enum(["meeting", "visit", "call", "other"]),
          startDate: z.date(),
          endDate: z.date(),
          customerId: z.number().optional(),
          projectId: z.number().optional(),
          location: z.string().optional(),
        }))
        .mutation(async ({ input, ctx }) => {
          return await createCalendarEvent({ ...input, createdBy: ctx.user.id });
        }),
      update: protectedProcedure
        .input(z.object({
          id: z.number(),
          data: z.object({
            title: z.string().optional(),
            description: z.string().optional(),
            eventType: z.enum(["meeting", "visit", "call", "other"]).optional(),
            startDate: z.date().optional(),
            endDate: z.date().optional(),
            customerId: z.number().optional(),
            projectId: z.number().optional(),
            location: z.string().optional(),
          }),
        }))
        .mutation(async ({ input }) => {
          return await updateCalendarEvent(input.id, input.data);
        }),
      delete: protectedProcedure
        .input(z.object({ id: z.number() }))
        .mutation(async ({ input }) => {
          return await deleteCalendarEvent(input.id);
        }),
    }),

  // ============ LEADS / CRM ============
  leads: router({
    list: protectedProcedure
      .input(z.object({
        stage: z.string().optional(),
        assignedTo: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getLeads(input);
      }),
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        company: z.string().optional(),
        email: z.string().optional(),
        phone: z.string().optional(),
        source: z.enum(["website", "referral", "cold_call", "social_media", "event", "other"]),
        stage: z.enum(["new", "contacted", "qualified", "proposal", "negotiation", "won", "lost"]).default("new"),
        estimatedValue: z.string().optional(),
        assignedTo: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createLead({ ...input, createdBy: ctx.user.id });
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          name: z.string().optional(),
          company: z.string().optional(),
          email: z.string().optional(),
          phone: z.string().optional(),
          source: z.enum(["website", "referral", "cold_call", "social_media", "event", "other"]).optional(),
          stage: z.enum(["new", "contacted", "qualified", "proposal", "negotiation", "won", "lost"]).optional(),
          estimatedValue: z.string().optional(),
          assignedTo: z.number().optional(),
          notes: z.string().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        return await db.updateLead(input.id, input.data);
      }),
    activities: protectedProcedure
      .input(z.object({ leadId: z.number() }))
      .query(async ({ input }) => {
        return await db.getLeadActivities(input.leadId);
      }),
    createActivity: protectedProcedure
      .input(z.object({
        leadId: z.number(),
        activityType: z.enum(["call", "meeting", "email", "follow_up", "note"]),
        subject: z.string(),
        description: z.string().optional(),
        scheduledDate: z.date().optional(),
        status: z.enum(["scheduled", "completed", "cancelled"]).default("scheduled"),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createLeadActivity({ ...input, createdBy: ctx.user.id });
      }),
  }),

  // ============ PROPOSALS ============
  proposals: router({
    list: protectedProcedure
      .input(z.object({ status: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getProposals(input);
      }),
    create: protectedProcedure
      .input(z.object({
        leadId: z.number().optional(),
        customerId: z.number().optional(),
        title: z.string(),
        description: z.string().optional(),
        totalValue: z.string(),
        estimatedTax: z.string().optional(),
        validUntil: z.date().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createProposal({ ...input, status: "draft", createdBy: ctx.user.id });
      }),
    items: protectedProcedure
      .input(z.object({ proposalId: z.number() }))
      .query(async ({ input }) => {
        return await db.getProposalItems(input.proposalId);
      }),
  }),

  // ============ CONTRACTS ============
  contracts: router({
    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        customerId: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getContracts(input);
      }),
    create: protectedProcedure
      .input(z.object({
        customerId: z.number(),
        title: z.string(),
        description: z.string().optional(),
        contractType: z.enum(["maintenance", "hosting", "support", "other"]),
        monthlyValue: z.string(),
        startDate: z.date(),
        endDate: z.date().optional(),
        renewalDate: z.date().optional(),
        adjustmentRate: z.string().optional(),
        billingDay: z.number().default(1),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createContract({ ...input, status: "active", createdBy: ctx.user.id });
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          title: z.string().optional(),
          description: z.string().optional(),
          monthlyValue: z.string().optional(),
          status: z.enum(["active", "suspended", "cancelled", "expired"]).optional(),
          endDate: z.date().optional(),
          renewalDate: z.date().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        return await db.updateContract(input.id, input.data);
      }),
    items: protectedProcedure
      .input(z.object({ contractId: z.number() }))
      .query(async ({ input }) => {
        return await db.getContractItems(input.contractId);
      }),
  }),

  // ============ TASKS ============
  tasks: router({
    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        projectId: z.number().optional(),
        assignedTo: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getTasks(input);
      }),
    create: protectedProcedure
      .input(z.object({
        title: z.string(),
        description: z.string().optional(),
        projectId: z.number().optional(),
        assignedTo: z.number().optional(),
        priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
        estimatedHours: z.string().optional(),
        dueDate: z.date().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createTask({ ...input, status: "todo", createdBy: ctx.user.id });
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          title: z.string().optional(),
          description: z.string().optional(),
          status: z.enum(["todo", "in_progress", "review", "done", "cancelled"]).optional(),
          priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
          assignedTo: z.number().optional(),
          dueDate: z.date().optional(),
          completedDate: z.date().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        return await db.updateTask(input.id, input.data);
      }),
  }),

  // ============ TIME ENTRIES ============
  timeEntries: router({
    list: protectedProcedure
      .input(z.object({
        userId: z.number().optional(),
        projectId: z.number().optional(),
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getTimeEntries(input);
      }),
    create: protectedProcedure
      .input(z.object({
        taskId: z.number().optional(),
        projectId: z.number().optional(),
        description: z.string().optional(),
        hours: z.string(),
        date: z.date(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createTimeEntry({ ...input, userId: ctx.user.id });
      }),
  }),

  // ============ TICKETS / SUPPORT ============
  tickets: router({
    list: protectedProcedure
      .input(z.object({
        status: z.string().optional(),
        customerId: z.number().optional(),
        assignedTo: z.number().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getTickets(input);
      }),
    create: protectedProcedure
      .input(z.object({
        customerId: z.number(),
        subject: z.string(),
        description: z.string(),
        category: z.enum(["bug", "adjustment", "content", "financial", "other"]),
        priority: z.enum(["low", "medium", "high", "urgent"]).default("medium"),
        sla: z.enum(["4h", "24h", "72h"]).default("24h"),
        assignedTo: z.number().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createTicket({ ...input, status: "open", createdBy: ctx.user.id });
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        data: z.object({
          status: z.enum(["open", "in_progress", "waiting_customer", "resolved", "closed"]).optional(),
          assignedTo: z.number().optional(),
          resolvedDate: z.date().optional(),
          closedDate: z.date().optional(),
        }),
      }))
      .mutation(async ({ input }) => {
        return await db.updateTicket(input.id, input.data);
      }),
    comments: protectedProcedure
      .input(z.object({ ticketId: z.number() }))
      .query(async ({ input }) => {
        return await db.getTicketComments(input.ticketId);
      }),
    createComment: protectedProcedure
      .input(z.object({
        ticketId: z.number(),
        comment: z.string(),
        isInternal: z.number().default(0),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createTicketComment({ ...input, createdBy: ctx.user.id });
      }),
  }),

  // ============ RECURRING EXPENSES ============
  recurringExpenses: router({
    list: protectedProcedure
      .input(z.object({ status: z.string().optional(), category: z.string().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getRecurringExpenses(input);
      }),
    create: protectedProcedure
      .input(z.object({
        name: z.string(),
        category: z.enum(["electricity", "water", "phone", "internet", "rent", "insurance", "software", "maintenance", "other"]),
        supplierId: z.number().optional(),
        amount: z.string(),
        frequency: z.enum(["monthly", "quarterly", "yearly"]),
        dayOfMonth: z.number().min(1).max(31),
        startDate: z.date(),
        endDate: z.date().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createRecurringExpense({ ...input, createdBy: ctx.user.id });
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["active", "paused", "cancelled"]).optional(),
        amount: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateRecurringExpense(id, data);
      }),
  }),
  
  productSubscriptions: router({
    list: protectedProcedure
      .input(z.object({ status: z.string().optional(), customerId: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return await db.getProductSubscriptions(input);
      }),
    create: protectedProcedure
      .input(z.object({
        productId: z.number(),
        customerId: z.number(),
        frequency: z.enum(["monthly", "quarterly", "yearly"]),
        price: z.string(),
        startDate: z.date(),
        endDate: z.date().optional(),
        nextBillingDate: z.date(),
      }))
      .mutation(async ({ input, ctx }) => {
        return await db.createProductSubscription({ ...input, createdBy: ctx.user.id, status: "active" });
      }),
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["active", "paused", "cancelled"]).optional(),
        price: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await db.updateProductSubscription(id, data);
      }),
  }),

  // ============ DASHBOARD ============
  dashboard: router({
    stats: protectedProcedure
      .input(z.object({
        startDate: z.date().optional(),
        endDate: z.date().optional(),
      }).optional())
      .query(async ({ input }) => {
        return await db.getDashboardStats(input?.startDate, input?.endDate);
      }),

    cashFlow: protectedProcedure
      .input(z.object({ year: z.number() }))
      .query(async ({ input }) => {
        return await db.getMonthlyCashFlow(input.year);
      }),
  }),
});





export type AppRouter = typeof appRouter;
