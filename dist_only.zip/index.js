var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined") return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/_core/env.ts
var ENV;
var init_env = __esm({
  "server/_core/env.ts"() {
    "use strict";
    ENV = {
      appId: process.env.VITE_APP_ID ?? "",
      cookieSecret: process.env.JWT_SECRET ?? "",
      databaseUrl: process.env.DATABASE_URL ?? "",
      oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
      ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
      isProduction: process.env.NODE_ENV === "production",
      forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
      forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? ""
    };
  }
});

// server/budgetPDF.ts
var budgetPDF_exports = {};
__export(budgetPDF_exports, {
  generateBudgetPDF: () => generateBudgetPDF
});
import PDFDocument from "pdfkit";
async function generateBudgetPDF(data) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: "A4", margin: 40 });
    const chunks = [];
    doc.on("data", (chunk) => chunks.push(chunk));
    doc.on("end", () => resolve(Buffer.concat(chunks)));
    doc.on("error", reject);
    const logoPath = "/home/ubuntu/erp_system/server/assets/logo_wiisite.png";
    const logoWidth = 80;
    const logoHeight = 40;
    const logoX = 40;
    const logoY = 40;
    try {
      const fs2 = __require("fs");
      if (fs2.existsSync(logoPath)) {
        doc.image(logoPath, logoX, logoY, { width: logoWidth, height: logoHeight });
      } else {
        console.warn("Logo n\xE3o encontrada:", logoPath);
      }
    } catch (error) {
      console.error("Erro ao carregar logo:", error?.message || error);
    }
    const companyX = 350;
    doc.fontSize(10).font("Helvetica-Bold").fillColor("#000000").text("WIISITE DIGITAL LTDA - ME", companyX, logoY, { align: "right" });
    doc.fontSize(8).font("Helvetica").fillColor("#64748b").text("CNPJ: 55.895.370/0001-26", companyX, logoY + 12, { align: "right" });
    doc.text("Tel: (11) 99492-3018", companyX, logoY + 22, { align: "right" });
    doc.y = logoY + logoHeight + 10;
    doc.strokeColor("#2563eb").lineWidth(1).moveTo(40, doc.y).lineTo(555, doc.y).stroke().moveDown(0.5);
    doc.fillColor("#000000").fontSize(11).font("Helvetica-Bold").text(`OR\xC7AMENTO N\xBA ${data.budget.budgetNumber || data.budget.id.toString().padStart(6, "0")}`, { align: "center" }).moveDown(0.2);
    doc.fontSize(8).font("Helvetica").fillColor("#64748b").text(`Emitido em ${new Date(data.budget.createdAt).toLocaleDateString("pt-BR")}`, { align: "center" }).moveDown(0.8);
    const clientBoxY = doc.y;
    doc.fillColor("#f1f5f9").rect(40, clientBoxY, 515, 55).fill();
    doc.fillColor("#1e40af").fontSize(9).font("Helvetica-Bold").text("CLIENTE", 50, clientBoxY + 8);
    const customerName = data.budget.customerName || data.customer?.name || "N\xE3o informado";
    const customerEmail = data.budget.customerEmail || data.customer?.email || "";
    const customerPhone = data.budget.customerPhone || data.customer?.phone || "";
    const customerAddress = data.budget.customerAddress || "";
    doc.fillColor("#000000").fontSize(8).font("Helvetica").text(`Nome: ${customerName}`, 50, clientBoxY + 22);
    if (customerEmail || customerPhone) {
      doc.text(
        `${customerEmail ? `Email: ${customerEmail}` : ""}${customerEmail && customerPhone ? " | " : ""}${customerPhone ? `Tel: ${customerPhone}` : ""}`,
        50,
        clientBoxY + 34
      );
    }
    if (customerAddress) {
      doc.text(`Endere\xE7o: ${customerAddress}`, 50, clientBoxY + 46, { width: 500 });
    }
    doc.moveDown(1.5);
    doc.fillColor("#000000").fontSize(10).font("Helvetica-Bold").text(data.budget.title, { align: "left" }).moveDown(0.3);
    if (data.budget.description) {
      doc.fontSize(8).font("Helvetica").fillColor("#64748b").text(data.budget.description, { align: "left", width: 515 }).moveDown(0.5);
    }
    if (data.items && data.items.length > 0) {
      doc.fillColor("#1e40af").fontSize(9).font("Helvetica-Bold").text("SERVI\xC7OS INCLUSOS", 40);
      doc.moveDown(0.3);
      doc.fontSize(8).font("Helvetica").fillColor("#000000");
      data.items.forEach((item) => {
        doc.text(`\u2022 ${item.productName || item.description || "Servi\xE7o"}`, 50);
      });
      doc.moveDown(0.5);
    }
    const formatCurrency = (value) => {
      const numValue = typeof value === "string" ? parseFloat(value) : value;
      if (isNaN(numValue)) return "R$ 0,00";
      return new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL"
      }).format(numValue);
    };
    const startY = doc.y;
    doc.fillColor("#1e40af").fontSize(9).font("Helvetica-Bold").text("IMPOSTOS INCLUSOS", 40, startY);
    doc.moveDown(0.5);
    doc.fontSize(8).font("Helvetica").fillColor("#000000");
    doc.text(`CBS (${data.budget.cbsRate}%): ${formatCurrency(data.budget.cbsAmount)}`, 40);
    doc.text(`IBS (${data.budget.ibsRate}%): ${formatCurrency(data.budget.ibsAmount)}`, 40);
    doc.text(`IRPJ: ${formatCurrency(data.budget.irpjAmount)}`, 40);
    doc.text(`CSLL: ${formatCurrency(data.budget.csllAmount)}`, 40);
    doc.font("Helvetica-Bold").text(`Total Impostos: ${formatCurrency(data.budget.totalConsumptionTaxes)}`, 40);
    doc.moveDown(0.5);
    doc.moveDown(3);
    const totalBoxY = doc.y;
    doc.fillColor("#2563eb").rect(40, totalBoxY, 515, 30).fill();
    doc.fillColor("#ffffff").fontSize(12).font("Helvetica-Bold").text(`VALOR TOTAL: ${formatCurrency(data.budget.finalPrice)}`, 40, totalBoxY + 10, {
      width: 515,
      align: "center"
    });
    doc.moveDown(1.5).fontSize(7).fillColor("#64748b").font("Helvetica").text("Este or\xE7amento \xE9 v\xE1lido por 30 dias a partir da data de emiss\xE3o.", { align: "center" }).moveDown(0.3).text("Valores sujeitos a altera\xE7\xE3o sem aviso pr\xE9vio.", { align: "center" });
    doc.end();
  });
}
var init_budgetPDF = __esm({
  "server/budgetPDF.ts"() {
    "use strict";
  }
});

// server/storage.ts
var storage_exports = {};
__export(storage_exports, {
  storageGet: () => storageGet,
  storagePut: () => storagePut
});
function getStorageConfig() {
  const baseUrl = ENV.forgeApiUrl;
  const apiKey = ENV.forgeApiKey;
  if (!baseUrl || !apiKey) {
    throw new Error(
      "Storage proxy credentials missing: set BUILT_IN_FORGE_API_URL and BUILT_IN_FORGE_API_KEY"
    );
  }
  return { baseUrl: baseUrl.replace(/\/+$/, ""), apiKey };
}
function buildUploadUrl(baseUrl, relKey) {
  const url = new URL("v1/storage/upload", ensureTrailingSlash(baseUrl));
  url.searchParams.set("path", normalizeKey(relKey));
  return url;
}
async function buildDownloadUrl(baseUrl, relKey, apiKey) {
  const downloadApiUrl = new URL(
    "v1/storage/downloadUrl",
    ensureTrailingSlash(baseUrl)
  );
  downloadApiUrl.searchParams.set("path", normalizeKey(relKey));
  const response = await fetch(downloadApiUrl, {
    method: "GET",
    headers: buildAuthHeaders(apiKey)
  });
  return (await response.json()).url;
}
function ensureTrailingSlash(value) {
  return value.endsWith("/") ? value : `${value}/`;
}
function normalizeKey(relKey) {
  return relKey.replace(/^\/+/, "");
}
function toFormData(data, contentType, fileName) {
  const blob = typeof data === "string" ? new Blob([data], { type: contentType }) : new Blob([data], { type: contentType });
  const form = new FormData();
  form.append("file", blob, fileName || "file");
  return form;
}
function buildAuthHeaders(apiKey) {
  return { Authorization: `Bearer ${apiKey}` };
}
async function storagePut(relKey, data, contentType = "application/octet-stream") {
  const { baseUrl, apiKey } = getStorageConfig();
  const key = normalizeKey(relKey);
  const uploadUrl = buildUploadUrl(baseUrl, key);
  const formData = toFormData(data, contentType, key.split("/").pop() ?? key);
  const response = await fetch(uploadUrl, {
    method: "POST",
    headers: buildAuthHeaders(apiKey),
    body: formData
  });
  if (!response.ok) {
    const message = await response.text().catch(() => response.statusText);
    throw new Error(
      `Storage upload failed (${response.status} ${response.statusText}): ${message}`
    );
  }
  const url = (await response.json()).url;
  return { key, url };
}
async function storageGet(relKey) {
  const { baseUrl, apiKey } = getStorageConfig();
  const key = normalizeKey(relKey);
  return {
    key,
    url: await buildDownloadUrl(baseUrl, key, apiKey)
  };
}
var init_storage = __esm({
  "server/storage.ts"() {
    "use strict";
    init_env();
  }
});

// server/_core/index.prod.ts
import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import path from "path";
import fs from "fs";
import { createExpressMiddleware } from "@trpc/server/adapters/express";

// shared/const.ts
var COOKIE_NAME = "app_session_id";
var ONE_YEAR_MS = 1e3 * 60 * 60 * 24 * 365;
var AXIOS_TIMEOUT_MS = 3e4;
var UNAUTHED_ERR_MSG = "Please login (10001)";
var NOT_ADMIN_ERR_MSG = "You do not have required permission (10002)";

// server/db.ts
import { and, desc, eq, gte, inArray, lt, lte, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";

// drizzle/schema.ts
import { boolean, decimal, int, longtext, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";
var users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull()
});
var customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  document: varchar("document", { length: 50 }),
  // CPF/CNPJ
  address: text("address"),
  neighborhood: varchar("neighborhood", { length: 100 }),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 2 }),
  zipCode: varchar("zipCode", { length: 20 }),
  notes: text("notes"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  type: mysqlEnum("type", ["product", "service"]).default("product").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  unit: varchar("unit", { length: 20 }).default("un").notNull(),
  // un, kg, m, h, etc
  category: varchar("category", { length: 100 }),
  active: mysqlEnum("active", ["yes", "no"]).default("yes").notNull(),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  orderNumber: varchar("orderNumber", { length: 50 }).notNull().unique(),
  customerId: int("customerId"),
  customerName: varchar("customerName", { length: 255 }),
  customerEmail: varchar("customerEmail", { length: 255 }),
  customerPhone: varchar("customerPhone", { length: 50 }),
  customerAddress: text("customerAddress"),
  budgetId: int("budgetId"),
  status: mysqlEnum("status", ["pending", "approved", "in_production", "completed", "cancelled"]).default("pending").notNull(),
  totalAmount: decimal("totalAmount", { precision: 10, scale: 2 }).notNull(),
  notes: text("notes"),
  orderDate: timestamp("orderDate").defaultNow().notNull(),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var orderItems = mysqlTable("orderItems", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  productId: int("productId").notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unitPrice: decimal("unitPrice", { precision: 10, scale: 2 }).notNull(),
  subtotal: decimal("subtotal", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var suppliers = mysqlTable("suppliers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 50 }),
  document: varchar("document", { length: 50 }),
  // CPF/CNPJ
  address: text("address"),
  notes: text("notes"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var financialCategories = mysqlTable("financialCategories", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  type: mysqlEnum("type", ["expense", "income"]).notNull(),
  color: varchar("color", { length: 7 }).default("#6366f1"),
  // hex color
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var accountsPayable = mysqlTable("accountsPayable", {
  id: int("id").autoincrement().primaryKey(),
  supplierId: int("supplierId"),
  categoryId: int("categoryId"),
  description: varchar("description", { length: 255 }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  dueDate: timestamp("dueDate").notNull(),
  paymentDate: timestamp("paymentDate"),
  status: mysqlEnum("status", ["pending", "paid", "overdue", "cancelled"]).default("pending").notNull(),
  notes: text("notes"),
  // Campos de parcelamento
  installmentNumber: int("installmentNumber").default(1),
  // Número da parcela atual (ex: 1, 2, 3...)
  totalInstallments: int("totalInstallments").default(1),
  // Total de parcelas (ex: 12)
  parentPayableId: int("parentPayableId"),
  // ID da conta a pagar "pai" (primeira parcela)
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var accountsReceivable = mysqlTable("accountsReceivable", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId"),
  customerId: int("customerId").notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  dueDate: timestamp("dueDate").notNull(),
  receivedDate: timestamp("receivedDate"),
  status: mysqlEnum("status", ["pending", "received", "overdue", "cancelled"]).default("pending").notNull(),
  notes: text("notes"),
  // Campos de parcelamento
  installmentNumber: int("installmentNumber").default(1),
  // Número da parcela atual (ex: 1, 2, 3...)
  totalInstallments: int("totalInstallments").default(1),
  // Total de parcelas (ex: 12)
  parentReceivableId: int("parentReceivableId"),
  // ID da conta a receber "pai" (primeira parcela)
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  customerId: int("customerId").references(() => customers.id),
  status: mysqlEnum("status", ["project", "development", "design", "review", "launched", "cancelled"]).default("project").notNull(),
  progress: int("progress").default(0).notNull(),
  value: decimal("value", { precision: 10, scale: 2 }).notNull(),
  deadline: timestamp("deadline").notNull(),
  meetingDate: timestamp("meetingDate"),
  approvalDate: timestamp("approvalDate"),
  reviewDate: timestamp("reviewDate"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var calendarEvents = mysqlTable("calendar_events", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  eventType: mysqlEnum("eventType", ["meeting", "visit", "call", "other"]).default("meeting").notNull(),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate").notNull(),
  customerId: int("customerId").references(() => customers.id),
  projectId: int("projectId").references(() => projects.id),
  location: varchar("location", { length: 255 }),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var leads = mysqlTable("leads", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  company: varchar("company", { length: 255 }),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  source: mysqlEnum("source", ["website", "referral", "cold_call", "social_media", "event", "other"]).default("other").notNull(),
  stage: mysqlEnum("stage", ["new", "contacted", "qualified", "proposal", "negotiation", "won", "lost"]).default("new").notNull(),
  estimatedValue: decimal("estimatedValue", { precision: 10, scale: 2 }),
  assignedTo: int("assignedTo").references(() => users.id),
  notes: text("notes"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var leadActivities = mysqlTable("lead_activities", {
  id: int("id").autoincrement().primaryKey(),
  leadId: int("leadId").notNull().references(() => leads.id, { onDelete: "cascade" }),
  activityType: mysqlEnum("activityType", ["call", "meeting", "email", "follow_up", "note"]).notNull(),
  subject: varchar("subject", { length: 255 }).notNull(),
  description: text("description"),
  scheduledDate: timestamp("scheduledDate"),
  completedDate: timestamp("completedDate"),
  status: mysqlEnum("status", ["scheduled", "completed", "cancelled"]).default("scheduled").notNull(),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var proposals = mysqlTable("proposals", {
  id: int("id").autoincrement().primaryKey(),
  leadId: int("leadId").references(() => leads.id),
  customerId: int("customerId").references(() => customers.id),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  totalValue: decimal("totalValue", { precision: 10, scale: 2 }).notNull(),
  estimatedTax: decimal("estimatedTax", { precision: 10, scale: 2 }),
  validUntil: timestamp("validUntil"),
  status: mysqlEnum("status", ["draft", "sent", "accepted", "rejected", "expired"]).default("draft").notNull(),
  notes: text("notes"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var proposalItems = mysqlTable("proposal_items", {
  id: int("id").autoincrement().primaryKey(),
  proposalId: int("proposalId").notNull().references(() => proposals.id, { onDelete: "cascade" }),
  description: varchar("description", { length: 500 }).notNull(),
  quantity: int("quantity").default(1).notNull(),
  unitPrice: decimal("unitPrice", { precision: 10, scale: 2 }).notNull(),
  totalPrice: decimal("totalPrice", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var contracts = mysqlTable("contracts", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull().references(() => customers.id),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  contractType: mysqlEnum("contractType", ["maintenance", "hosting", "support", "software_license", "other"]).default("other").notNull(),
  contractContent: text("contractContent"),
  monthlyValue: decimal("monthlyValue", { precision: 10, scale: 2 }).notNull(),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate"),
  renewalDate: timestamp("renewalDate"),
  adjustmentRate: decimal("adjustmentRate", { precision: 5, scale: 2 }),
  status: mysqlEnum("status", ["active", "suspended", "cancelled", "expired"]).default("active").notNull(),
  billingDay: int("billingDay").default(1).notNull(),
  notes: text("notes"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var contractItems = mysqlTable("contract_items", {
  id: int("id").autoincrement().primaryKey(),
  contractId: int("contractId").notNull().references(() => contracts.id, { onDelete: "cascade" }),
  description: varchar("description", { length: 500 }).notNull(),
  quantity: int("quantity").default(1).notNull(),
  unitPrice: decimal("unitPrice", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var tasks = mysqlTable("tasks", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  projectId: int("projectId").references(() => projects.id),
  assignedTo: int("assignedTo").references(() => users.id),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  status: mysqlEnum("status", ["todo", "in_progress", "review", "done", "cancelled"]).default("todo").notNull(),
  estimatedHours: decimal("estimatedHours", { precision: 5, scale: 2 }),
  dueDate: timestamp("dueDate"),
  completedDate: timestamp("completedDate"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var timeEntries = mysqlTable("time_entries", {
  id: int("id").autoincrement().primaryKey(),
  taskId: int("taskId").references(() => tasks.id),
  projectId: int("projectId").references(() => projects.id),
  userId: int("userId").notNull().references(() => users.id),
  description: text("description"),
  hours: decimal("hours", { precision: 5, scale: 2 }).notNull(),
  date: timestamp("date").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var tickets = mysqlTable("tickets", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull().references(() => customers.id),
  subject: varchar("subject", { length: 255 }).notNull(),
  description: text("description").notNull(),
  category: mysqlEnum("category", ["bug", "adjustment", "content", "financial", "other"]).default("other").notNull(),
  priority: mysqlEnum("priority", ["low", "medium", "high", "urgent"]).default("medium").notNull(),
  sla: mysqlEnum("sla", ["4h", "24h", "72h"]).default("24h").notNull(),
  status: mysqlEnum("status", ["open", "in_progress", "waiting_customer", "resolved", "closed"]).default("open").notNull(),
  assignedTo: int("assignedTo").references(() => users.id),
  dueDate: timestamp("dueDate"),
  resolvedDate: timestamp("resolvedDate"),
  closedDate: timestamp("closedDate"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var ticketComments = mysqlTable("ticket_comments", {
  id: int("id").autoincrement().primaryKey(),
  ticketId: int("ticketId").notNull().references(() => tickets.id, { onDelete: "cascade" }),
  comment: text("comment").notNull(),
  isInternal: int("isInternal").default(0).notNull(),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var projectChecklists = mysqlTable("project_checklists", {
  id: int("id").autoincrement().primaryKey(),
  projectId: int("projectId").notNull().references(() => projects.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  completed: int("completed").default(0).notNull(),
  order: int("order").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var taskChecklists = mysqlTable("task_checklists", {
  id: int("id").autoincrement().primaryKey(),
  taskId: int("taskId").notNull().references(() => tasks.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  completed: int("completed").default(0).notNull(),
  order: int("order").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var recurringExpenses = mysqlTable("recurring_expenses", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  category: mysqlEnum("category", [
    "electricity",
    "water",
    "phone",
    "internet",
    "rent",
    "insurance",
    "software",
    "maintenance",
    "other"
  ]).default("other").notNull(),
  supplierId: int("supplierId").references(() => suppliers.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  frequency: mysqlEnum("frequency", ["monthly", "quarterly", "yearly"]).default("monthly").notNull(),
  dayOfMonth: int("dayOfMonth").default(1).notNull(),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate"),
  status: mysqlEnum("status", ["active", "paused", "cancelled"]).default("active").notNull(),
  lastGenerated: timestamp("lastGenerated"),
  notes: text("notes"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var productSubscriptions = mysqlTable("product_subscriptions", {
  id: int("id").autoincrement().primaryKey(),
  productId: int("productId").notNull().references(() => products.id),
  customerId: int("customerId").notNull().references(() => customers.id),
  frequency: mysqlEnum("frequency", ["monthly", "quarterly", "yearly"]).default("monthly").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  startDate: timestamp("startDate").notNull(),
  endDate: timestamp("endDate"),
  status: mysqlEnum("status", ["active", "paused", "cancelled"]).default("active").notNull(),
  lastBilled: timestamp("lastBilled"),
  nextBillingDate: timestamp("nextBillingDate").notNull(),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var taxSettings = mysqlTable("tax_settings", {
  id: int("id").autoincrement().primaryKey(),
  // Tributos sobre consumo (novo sistema)
  cbsRate: decimal("cbsRate", { precision: 5, scale: 2 }).default("0.00").notNull(),
  // CBS - Contribuição sobre Bens e Serviços (Federal)
  ibsRate: decimal("ibsRate", { precision: 5, scale: 2 }).default("0.00").notNull(),
  // IBS - Imposto sobre Bens e Serviços (Estadual/Municipal)
  // Tributos sobre lucro
  irpjRate: decimal("irpjRate", { precision: 5, scale: 2 }).default("0.00").notNull(),
  // IRPJ
  csllRate: decimal("csllRate", { precision: 5, scale: 2 }).default("0.00").notNull(),
  // CSLL
  // Configurações
  minimumMargin: decimal("minimumMargin", { precision: 5, scale: 2 }).default("20.00").notNull(),
  // Margem mínima recomendada
  taxRegime: mysqlEnum("taxRegime", ["new", "old", "transition"]).default("new").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var companySettings = mysqlTable("company_settings", {
  id: int("id").autoincrement().primaryKey(),
  companyName: varchar("companyName", { length: 255 }).notNull(),
  tradeName: varchar("tradeName", { length: 255 }),
  // Nome fantasia
  logo: longtext("logo"),
  // Logo em base64 ou URL
  cnpj: varchar("cnpj", { length: 20 }).notNull(),
  stateRegistration: varchar("stateRegistration", { length: 50 }),
  // Inscrição estadual
  municipalRegistration: varchar("municipalRegistration", { length: 50 }),
  // Inscrição municipal
  address: text("address"),
  neighborhood: varchar("neighborhood", { length: 100 }),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 2 }),
  zipCode: varchar("zipCode", { length: 20 }),
  phone: varchar("phone", { length: 50 }),
  email: varchar("email", { length: 255 }),
  website: varchar("website", { length: 255 }),
  // Dados do responsável
  ownerName: varchar("ownerName", { length: 255 }),
  ownerCpf: varchar("ownerCpf", { length: 20 }),
  ownerRole: varchar("ownerRole", { length: 100 }),
  // Cargo (ex: Diretor, Sócio)
  ownerNationality: varchar("ownerNationality", { length: 50 }).default("brasileiro"),
  ownerMaritalStatus: varchar("ownerMaritalStatus", { length: 50 }),
  ownerProfession: varchar("ownerProfession", { length: 100 }),
  ownerAddress: text("ownerAddress"),
  // Configurações
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var budgets = mysqlTable("budgets", {
  id: int("id").autoincrement().primaryKey(),
  budgetNumber: varchar("budgetNumber", { length: 50 }).notNull(),
  customerId: int("customerId").references(() => customers.id),
  customerName: varchar("customerName", { length: 255 }),
  customerEmail: varchar("customerEmail", { length: 255 }),
  customerPhone: varchar("customerPhone", { length: 50 }),
  customerDocument: varchar("customerDocument", { length: 50 }),
  // CPF/CNPJ
  customerAddress: text("customerAddress"),
  customerNeighborhood: varchar("customerNeighborhood", { length: 100 }),
  customerCity: varchar("customerCity", { length: 100 }),
  customerState: varchar("customerState", { length: 2 }),
  customerZipCode: varchar("customerZipCode", { length: 20 }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  // Custos diretos
  laborCost: decimal("laborCost", { precision: 10, scale: 2 }).default("0.00").notNull(),
  laborHours: decimal("laborHours", { precision: 8, scale: 2 }).default("0.00").notNull(),
  laborRate: decimal("laborRate", { precision: 10, scale: 2 }).default("0.00").notNull(),
  // Valor por hora
  materialCost: decimal("materialCost", { precision: 10, scale: 2 }).default("0.00").notNull(),
  thirdPartyCost: decimal("thirdPartyCost", { precision: 10, scale: 2 }).default("0.00").notNull(),
  otherDirectCosts: decimal("otherDirectCosts", { precision: 10, scale: 2 }).default("0.00").notNull(),
  // Custos indiretos (rateados)
  indirectCostsTotal: decimal("indirectCostsTotal", { precision: 10, scale: 2 }).default("0.00").notNull(),
  // Margem e impostos
  profitMargin: decimal("profitMargin", { precision: 5, scale: 2 }).default("20.00").notNull(),
  // %
  cbsRate: decimal("cbsRate", { precision: 5, scale: 2 }).notNull(),
  // % usado no cálculo
  ibsRate: decimal("ibsRate", { precision: 5, scale: 2 }).notNull(),
  // % usado no cálculo
  irpjRate: decimal("irpjRate", { precision: 5, scale: 2 }).notNull(),
  // % usado no cálculo
  csllRate: decimal("csllRate", { precision: 5, scale: 2 }).notNull(),
  // % usado no cálculo
  // Valores calculados
  totalDirectCosts: decimal("totalDirectCosts", { precision: 10, scale: 2 }).notNull(),
  totalCosts: decimal("totalCosts", { precision: 10, scale: 2 }).notNull(),
  grossValue: decimal("grossValue", { precision: 10, scale: 2 }).notNull(),
  cbsAmount: decimal("cbsAmount", { precision: 10, scale: 2 }).notNull(),
  ibsAmount: decimal("ibsAmount", { precision: 10, scale: 2 }).notNull(),
  totalConsumptionTaxes: decimal("totalConsumptionTaxes", { precision: 10, scale: 2 }).notNull(),
  netRevenue: decimal("netRevenue", { precision: 10, scale: 2 }).notNull(),
  profitBeforeTaxes: decimal("profitBeforeTaxes", { precision: 10, scale: 2 }).notNull(),
  irpjAmount: decimal("irpjAmount", { precision: 10, scale: 2 }).notNull(),
  csllAmount: decimal("csllAmount", { precision: 10, scale: 2 }).notNull(),
  netProfit: decimal("netProfit", { precision: 10, scale: 2 }).notNull(),
  finalPrice: decimal("finalPrice", { precision: 10, scale: 2 }).notNull(),
  // Metadata
  taxRegime: mysqlEnum("taxRegime", ["new", "old", "transition"]).default("new").notNull(),
  status: mysqlEnum("status", ["draft", "sent", "approved", "rejected", "converted"]).default("draft").notNull(),
  validUntil: timestamp("validUntil"),
  notes: text("notes"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});
var budgetItems = mysqlTable("budget_items", {
  id: int("id").autoincrement().primaryKey(),
  budgetId: int("budgetId").notNull().references(() => budgets.id, { onDelete: "cascade" }),
  productId: int("productId").references(() => products.id),
  type: mysqlEnum("type", ["labor", "material", "thirdparty", "indirect", "other", "service"]).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).default("1.00").notNull(),
  unitPrice: decimal("unitPrice", { precision: 10, scale: 2 }).notNull(),
  totalPrice: decimal("totalPrice", { precision: 10, scale: 2 }).notNull(),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull()
});
var budgetTemplates = mysqlTable("budget_templates", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  // Valores padrão
  laborCost: decimal("laborCost", { precision: 10, scale: 2 }).default("0.00").notNull(),
  laborHours: decimal("laborHours", { precision: 8, scale: 2 }).default("0.00").notNull(),
  materialCost: decimal("materialCost", { precision: 10, scale: 2 }).default("0.00").notNull(),
  thirdPartyCost: decimal("thirdPartyCost", { precision: 10, scale: 2 }).default("0.00").notNull(),
  otherDirectCosts: decimal("otherDirectCosts", { precision: 10, scale: 2 }).default("0.00").notNull(),
  indirectCostsTotal: decimal("indirectCostsTotal", { precision: 10, scale: 2 }).default("0.00").notNull(),
  profitMargin: decimal("profitMargin", { precision: 5, scale: 2 }).default("20.00").notNull(),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull()
});

// server/db.ts
init_env();
var _db = null;
async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      const connectionUrl = process.env.DATABASE_URL;
      _db = drizzle(connectionUrl);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}
async function upsertUser(user) {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values = {
      openId: user.openId
    };
    const updateSet = {};
    const textFields = ["name", "email", "loginMethod"];
    const assignNullable = (field) => {
      const value = user[field];
      if (value === void 0) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== void 0) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== void 0) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) {
      values.lastSignedIn = /* @__PURE__ */ new Date();
    }
    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = /* @__PURE__ */ new Date();
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}
async function getUserByOpenId(openId) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return void 0;
  }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : void 0;
}
async function createCustomer(customer) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(customers).values(customer);
  return result;
}
async function getCustomers(userId) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(customers).where(eq(customers.createdBy, userId)).orderBy(desc(customers.createdAt));
}
async function getCustomerById(id) {
  const db = await getDb();
  if (!db) return void 0;
  const result = await db.select().from(customers).where(eq(customers.id, id)).limit(1);
  return result[0];
}
async function updateCustomer(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(customers).set(data).where(eq(customers.id, id));
}
async function deleteCustomer(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(customers).where(eq(customers.id, id));
}
async function createProduct(product) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(products).values(product);
  return result;
}
async function getProducts(activeOnly = false) {
  const db = await getDb();
  if (!db) return [];
  if (activeOnly) {
    return await db.select().from(products).where(eq(products.active, "yes")).orderBy(desc(products.createdAt));
  }
  return await db.select().from(products).orderBy(desc(products.createdAt));
}
async function getProductById(id) {
  const db = await getDb();
  if (!db) return void 0;
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result[0];
}
async function updateProduct(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(products).set(data).where(eq(products.id, id));
}
async function deleteProduct(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(products).where(eq(products.id, id));
}
async function createOrder(order, items) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const orderResult = await db.insert(orders).values(order);
  const orderId = Number(orderResult[0].insertId);
  const itemsWithOrderId = items.map((item) => ({ ...item, orderId }));
  await db.insert(orderItems).values(itemsWithOrderId);
  return orderId;
}
async function getOrders(filters) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(orders.status, filters.status));
  }
  if (filters?.startDate) {
    conditions.push(gte(orders.orderDate, filters.startDate));
  }
  if (filters?.endDate) {
    conditions.push(lte(orders.orderDate, filters.endDate));
  }
  const baseQuery = db.select({
    order: orders,
    customer: customers
  }).from(orders).leftJoin(customers, eq(orders.customerId, customers.id));
  if (conditions.length > 0) {
    return await baseQuery.where(and(...conditions)).orderBy(desc(orders.createdAt));
  }
  return await baseQuery.orderBy(desc(orders.createdAt));
}
async function getOrderById(id) {
  const db = await getDb();
  if (!db) return void 0;
  const orderResult = await db.select({
    order: orders,
    customer: customers
  }).from(orders).leftJoin(customers, eq(orders.customerId, customers.id)).where(eq(orders.id, id)).limit(1);
  if (orderResult.length === 0) return void 0;
  const items = await db.select({
    item: orderItems,
    product: products
  }).from(orderItems).leftJoin(products, eq(orderItems.productId, products.id)).where(eq(orderItems.orderId, id));
  return {
    ...orderResult[0],
    items
  };
}
async function updateOrderStatus(id, status) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(orders).set({ status }).where(eq(orders.id, id));
}
async function updateOrder(id, orderData, items) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  if (Object.keys(orderData).length > 0) {
    await db.update(orders).set(orderData).where(eq(orders.id, id));
  }
  if (items && items.length > 0) {
    await db.delete(orderItems).where(eq(orderItems.orderId, id));
    const itemsWithOrderId = items.map((item) => ({ ...item, orderId: id }));
    await db.insert(orderItems).values(itemsWithOrderId);
  }
  return id;
}
async function deleteOrder(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(orderItems).where(eq(orderItems.orderId, id));
  await db.delete(orders).where(eq(orders.id, id));
  return { success: true };
}
async function createSupplier(supplier) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(suppliers).values(supplier);
  return result;
}
async function getSuppliers() {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(suppliers).orderBy(desc(suppliers.createdAt));
}
async function getSupplierById(id) {
  const db = await getDb();
  if (!db) return void 0;
  const result = await db.select().from(suppliers).where(eq(suppliers.id, id)).limit(1);
  return result[0];
}
async function updateSupplier(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(suppliers).set(data).where(eq(suppliers.id, id));
}
async function createFinancialCategory(category) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(financialCategories).values(category);
  return result;
}
async function getFinancialCategories(type) {
  const db = await getDb();
  if (!db) return [];
  if (type) {
    return await db.select().from(financialCategories).where(eq(financialCategories.type, type));
  }
  return await db.select().from(financialCategories);
}
async function createAccountPayable(account) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(accountsPayable).values(account);
  return result;
}
async function createAccountPayableWithInstallments(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const installments = data.installments || 1;
  if (installments === 1) {
    return await createAccountPayable(data);
  }
  const totalAmount = parseFloat(data.amount);
  const installmentAmount = totalAmount / installments;
  const roundedInstallmentAmount = Math.floor(installmentAmount * 100) / 100;
  const lastInstallmentAmount = totalAmount - roundedInstallmentAmount * (installments - 1);
  const payablesToCreate = [];
  let firstPayableId = null;
  for (let i = 0; i < installments; i++) {
    const dueDate = new Date(data.dueDate);
    dueDate.setMonth(dueDate.getMonth() + i);
    const isLastInstallment = i === installments - 1;
    const amount = isLastInstallment ? lastInstallmentAmount.toFixed(2) : roundedInstallmentAmount.toFixed(2);
    const payable = {
      ...data,
      amount,
      dueDate,
      description: `${data.description} (${i + 1}/${installments})`,
      installmentNumber: i + 1,
      totalInstallments: installments,
      parentPayableId: firstPayableId
    };
    const result = await db.insert(accountsPayable).values(payable);
    if (i === 0) {
      firstPayableId = Number(result[0].insertId);
    }
  }
  return { success: true, installmentsCreated: installments };
}
async function getAccountsPayable(filters) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(accountsPayable.status, filters.status));
  }
  if (filters?.startDate) {
    conditions.push(gte(accountsPayable.dueDate, filters.startDate));
  }
  if (filters?.endDate) {
    conditions.push(lte(accountsPayable.dueDate, filters.endDate));
  }
  const baseQuery = db.select({
    account: accountsPayable,
    supplier: suppliers,
    category: financialCategories
  }).from(accountsPayable).leftJoin(suppliers, eq(accountsPayable.supplierId, suppliers.id)).leftJoin(financialCategories, eq(accountsPayable.categoryId, financialCategories.id));
  if (conditions.length > 0) {
    return await baseQuery.where(and(...conditions)).orderBy(desc(accountsPayable.dueDate));
  }
  return await baseQuery.orderBy(desc(accountsPayable.dueDate));
}
async function updateAccountPayable(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(accountsPayable).set(data).where(eq(accountsPayable.id, id));
}
async function markAccountPayableAsPaid(id, paymentDate) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(accountsPayable).set({ status: "paid", paymentDate }).where(eq(accountsPayable.id, id));
}
async function deleteAccountPayable(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(accountsPayable).where(eq(accountsPayable.id, id));
}
async function deleteAllAccountsPayable() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(accountsPayable);
}
async function createAccountReceivableWithInstallments(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const installments = data.installments || 1;
  const totalAmount = parseFloat(data.amount);
  const installmentAmount = (totalAmount / installments).toFixed(2);
  if (installments === 1) {
    return await db.insert(accountsReceivable).values({
      ...data,
      installmentNumber: 1,
      totalInstallments: 1,
      parentReceivableId: null
    });
  }
  const accounts = [];
  let firstAccountId = null;
  for (let i = 1; i <= installments; i++) {
    const dueDate = new Date(data.dueDate);
    dueDate.setMonth(dueDate.getMonth() + (i - 1));
    const amount = i === installments ? (totalAmount - parseFloat(installmentAmount) * (installments - 1)).toFixed(2) : installmentAmount;
    const accountData = {
      ...data,
      amount,
      dueDate,
      description: `${data.description} (${i}/${installments})`,
      installmentNumber: i,
      totalInstallments: installments,
      parentReceivableId: i === 1 ? null : firstAccountId
    };
    const result = await db.insert(accountsReceivable).values(accountData);
    if (i === 1) {
      firstAccountId = result.insertId;
    }
    accounts.push(result);
  }
  return { success: true, installmentsCreated: installments };
}
async function getAccountsReceivable(filters) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(accountsReceivable.status, filters.status));
  }
  if (filters?.startDate) {
    conditions.push(gte(accountsReceivable.dueDate, filters.startDate));
  }
  if (filters?.endDate) {
    conditions.push(lte(accountsReceivable.dueDate, filters.endDate));
  }
  const baseQuery = db.select({
    account: accountsReceivable,
    customer: customers,
    order: orders
  }).from(accountsReceivable).leftJoin(customers, eq(accountsReceivable.customerId, customers.id)).leftJoin(orders, eq(accountsReceivable.orderId, orders.id));
  if (conditions.length > 0) {
    return await baseQuery.where(and(...conditions)).orderBy(desc(accountsReceivable.dueDate));
  }
  return await baseQuery.orderBy(desc(accountsReceivable.dueDate));
}
async function updateAccountReceivable(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(accountsReceivable).set(data).where(eq(accountsReceivable.id, id));
}
async function markAccountReceivableAsReceived(id, receivedDate) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(accountsReceivable).set({ status: "received", receivedDate }).where(eq(accountsReceivable.id, id));
}
async function deleteAccountReceivable(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(accountsReceivable).where(eq(accountsReceivable.id, id));
}
async function deleteAllAccountsReceivable() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(accountsReceivable);
}
async function getDashboardStats(startDate, endDate) {
  const db = await getDb();
  if (!db) return null;
  const conditions = [];
  if (startDate) conditions.push(gte(orders.orderDate, startDate));
  if (endDate) conditions.push(lte(orders.orderDate, endDate));
  const salesQuery = db.select({
    total: sql`COALESCE(SUM(${orders.totalAmount}), 0)`
  }).from(orders).where(and(...conditions, eq(orders.status, "completed")));
  const payableQuery = db.select({
    pending: sql`COALESCE(SUM(CASE WHEN ${accountsPayable.status} = 'pending' THEN ${accountsPayable.amount} ELSE 0 END), 0)`,
    paid: sql`COALESCE(SUM(CASE WHEN ${accountsPayable.status} = 'paid' THEN ${accountsPayable.amount} ELSE 0 END), 0)`
  }).from(accountsPayable);
  const receivableQuery = db.select({
    pending: sql`COALESCE(SUM(CASE WHEN ${accountsReceivable.status} = 'pending' THEN ${accountsReceivable.amount} ELSE 0 END), 0)`,
    received: sql`COALESCE(SUM(CASE WHEN ${accountsReceivable.status} = 'received' THEN ${accountsReceivable.amount} ELSE 0 END), 0)`
  }).from(accountsReceivable);
  const [salesResult, payableResult, receivableResult] = await Promise.all([
    salesQuery,
    payableQuery,
    receivableQuery
  ]);
  return {
    totalSales: parseFloat(salesResult[0]?.total || "0"),
    accountsPayable: {
      pending: parseFloat(payableResult[0]?.pending || "0"),
      paid: parseFloat(payableResult[0]?.paid || "0")
    },
    accountsReceivable: {
      pending: parseFloat(receivableResult[0]?.pending || "0"),
      received: parseFloat(receivableResult[0]?.received || "0")
    }
  };
}
async function getProjects(filters) {
  const db = await getDb();
  if (!db) return [];
  const baseQuery = db.select({
    project: projects,
    customer: customers
  }).from(projects).leftJoin(customers, eq(projects.customerId, customers.id));
  if (filters?.status) {
    return await baseQuery.where(eq(projects.status, filters.status)).orderBy(desc(projects.createdAt));
  }
  return await baseQuery.orderBy(desc(projects.createdAt));
}
async function createProject(project) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(projects).values(project);
  return result;
}
async function updateProject(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(projects).set(data).where(eq(projects.id, id));
}
async function deleteProject(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(projects).where(eq(projects.id, id));
}
async function getCalendarEvents(filters) {
  const db = await getDb();
  if (!db) return [];
  const eventsBaseQuery = db.select({
    event: calendarEvents,
    customer: customers,
    project: projects
  }).from(calendarEvents).leftJoin(customers, eq(calendarEvents.customerId, customers.id)).leftJoin(projects, eq(calendarEvents.projectId, projects.id));
  const events = filters?.startDate && filters?.endDate ? await eventsBaseQuery.where(and(
    gte(calendarEvents.startDate, filters.startDate),
    lte(calendarEvents.endDate, filters.endDate)
  )).orderBy(calendarEvents.startDate) : await eventsBaseQuery.orderBy(calendarEvents.startDate);
  const tasksBaseQuery = db.select({
    task: tasks,
    project: projects
  }).from(tasks).leftJoin(projects, eq(tasks.projectId, projects.id));
  const tasksData = filters?.startDate && filters?.endDate ? await tasksBaseQuery.where(and(
    gte(tasks.dueDate, filters.startDate),
    lte(tasks.dueDate, filters.endDate)
  )).orderBy(tasks.dueDate) : await tasksBaseQuery.orderBy(tasks.dueDate);
  const payablesBaseQuery = db.select({
    payable: accountsPayable,
    supplier: suppliers,
    category: financialCategories
  }).from(accountsPayable).leftJoin(suppliers, eq(accountsPayable.supplierId, suppliers.id)).leftJoin(financialCategories, eq(accountsPayable.categoryId, financialCategories.id));
  const payables = filters?.startDate && filters?.endDate ? await payablesBaseQuery.where(and(
    gte(accountsPayable.dueDate, filters.startDate),
    lte(accountsPayable.dueDate, filters.endDate)
  )).orderBy(accountsPayable.dueDate) : await payablesBaseQuery.orderBy(accountsPayable.dueDate);
  const receivablesBaseQuery = db.select({
    receivable: accountsReceivable,
    customer: customers,
    order: orders
  }).from(accountsReceivable).leftJoin(customers, eq(accountsReceivable.customerId, customers.id)).leftJoin(orders, eq(accountsReceivable.orderId, orders.id));
  const receivables = filters?.startDate && filters?.endDate ? await receivablesBaseQuery.where(and(
    gte(accountsReceivable.dueDate, filters.startDate),
    lte(accountsReceivable.dueDate, filters.endDate)
  )).orderBy(accountsReceivable.dueDate) : await receivablesBaseQuery.orderBy(accountsReceivable.dueDate);
  const recurringExpensesData = await db.select({
    expense: recurringExpenses,
    supplier: suppliers
  }).from(recurringExpenses).leftJoin(suppliers, eq(recurringExpenses.supplierId, suppliers.id)).where(eq(recurringExpenses.status, "active"));
  const allEvents = [];
  events.forEach((e) => {
    allEvents.push({
      type: "event",
      id: e.event.id,
      title: e.event.title,
      description: e.event.description,
      startDate: e.event.startDate,
      endDate: e.event.endDate,
      eventType: e.event.eventType,
      customerId: e.event.customerId,
      projectId: e.event.projectId,
      customer: e.customer,
      project: e.project,
      location: e.event.location
    });
  });
  tasksData.forEach((t2) => {
    if (t2.task.dueDate) {
      allEvents.push({
        type: "task",
        id: `task-${t2.task.id}`,
        title: `[Tarefa] ${t2.task.title}`,
        description: t2.task.description,
        startDate: t2.task.dueDate,
        endDate: t2.task.dueDate,
        status: t2.task.status,
        priority: t2.task.priority,
        project: t2.project
      });
    }
  });
  payables.forEach((p) => {
    allEvents.push({
      type: "payable",
      id: `payable-${p.payable.id}`,
      title: `[A Pagar] ${p.supplier?.name || "Fornecedor"} - ${p.category?.name || ""}`,
      description: p.payable.description,
      startDate: p.payable.dueDate,
      endDate: p.payable.dueDate,
      amount: p.payable.amount,
      status: p.payable.status,
      supplier: p.supplier,
      category: p.category
    });
  });
  receivables.forEach((r) => {
    allEvents.push({
      type: "receivable",
      id: `receivable-${r.receivable.id}`,
      title: `[A Receber] ${r.customer?.name || "Cliente"}`,
      description: r.receivable.description,
      startDate: r.receivable.dueDate,
      endDate: r.receivable.dueDate,
      amount: r.receivable.amount,
      status: r.receivable.status,
      customer: r.customer,
      order: r.order
    });
  });
  if (filters?.startDate && filters?.endDate) {
    recurringExpensesData.forEach((re) => {
      const startMonth = filters.startDate.getMonth();
      const startYear = filters.startDate.getFullYear();
      const endMonth = filters.endDate.getMonth();
      const endYear = filters.endDate.getFullYear();
      for (let year = startYear; year <= endYear; year++) {
        const monthStart = year === startYear ? startMonth : 0;
        const monthEnd = year === endYear ? endMonth : 11;
        for (let month = monthStart; month <= monthEnd; month++) {
          const dayOfMonth = typeof re.expense.dayOfMonth === "string" ? parseInt(re.expense.dayOfMonth) : re.expense.dayOfMonth;
          const eventDate = new Date(year, month, dayOfMonth);
          if (eventDate >= filters.startDate && eventDate <= filters.endDate) {
            allEvents.push({
              type: "recurring",
              id: `recurring-${re.expense.id}-${year}-${month}`,
              title: `[Despesa Recorrente] ${re.expense.name}`,
              description: `${re.supplier?.name || ""} - ${re.expense.frequency}`,
              startDate: eventDate,
              endDate: eventDate,
              amount: re.expense.amount,
              supplier: re.supplier,
              frequency: re.expense.frequency
            });
          }
        }
      }
    });
  }
  allEvents.sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
  return allEvents;
}
async function createCalendarEvent(event) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(calendarEvents).values(event);
  return result;
}
async function updateCalendarEvent(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(calendarEvents).set(data).where(eq(calendarEvents.id, id));
}
async function deleteCalendarEvent(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(calendarEvents).where(eq(calendarEvents.id, id));
}
async function getMonthlyCashFlow(year) {
  const db = await getDb();
  if (!db) return [];
  try {
    const receivables = await db.execute(sql`
      SELECT MONTH(receivedDate) as month, SUM(amount) as amount
      FROM accountsReceivable
      WHERE status = 'received'
        AND receivedDate IS NOT NULL
        AND YEAR(receivedDate) = ${year}
      GROUP BY MONTH(receivedDate)
    `);
    const payables = await db.execute(sql`
      SELECT MONTH(paymentDate) as month, SUM(amount) as amount
      FROM accountsPayable
      WHERE status = 'paid'
        AND paymentDate IS NOT NULL
        AND YEAR(paymentDate) = ${year}
      GROUP BY MONTH(paymentDate)
    `);
    const receivablesData = receivables[0];
    const payablesData = payables[0];
    const cashFlow = [];
    for (let month = 1; month <= 12; month++) {
      const income = receivablesData.find((r) => r.month === month);
      const expense = payablesData.find((p) => p.month === month);
      cashFlow.push({
        month,
        income: parseFloat(income?.amount || "0"),
        expense: parseFloat(expense?.amount || "0"),
        balance: parseFloat(income?.amount || "0") - parseFloat(expense?.amount || "0")
      });
    }
    return cashFlow;
  } catch (error) {
    console.error("Error in getMonthlyCashFlow:", error);
    return Array.from({ length: 12 }, (_, i) => ({
      month: i + 1,
      income: 0,
      expense: 0,
      balance: 0
    }));
  }
}
async function getPaymentsDueToday() {
  const db = await getDb();
  if (!db) return { accounts: [], totalAmount: 0, count: 0 };
  try {
    const today = /* @__PURE__ */ new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const accounts = await db.select({
      account: accountsPayable,
      supplier: suppliers,
      category: financialCategories
    }).from(accountsPayable).leftJoin(suppliers, eq(accountsPayable.supplierId, suppliers.id)).leftJoin(financialCategories, eq(accountsPayable.categoryId, financialCategories.id)).where(
      and(
        eq(accountsPayable.status, "pending"),
        gte(accountsPayable.dueDate, today),
        lt(accountsPayable.dueDate, tomorrow)
      )
    );
    const totalAmount = accounts.reduce((sum, row) => {
      return sum + parseFloat(row.account.amount);
    }, 0);
    return {
      accounts,
      totalAmount,
      count: accounts.length
    };
  } catch (error) {
    console.error("Error in getPaymentsDueToday:", error);
    return { accounts: [], totalAmount: 0, count: 0 };
  }
}
async function getRecurringExpensesDueToday() {
  const db = await getDb();
  if (!db) return { expenses: [], totalAmount: 0, count: 0 };
  try {
    const today = /* @__PURE__ */ new Date();
    const currentDay = today.getDate();
    const expenses = await db.select({
      expense: recurringExpenses,
      supplier: suppliers
    }).from(recurringExpenses).leftJoin(suppliers, eq(recurringExpenses.supplierId, suppliers.id)).where(
      and(
        eq(recurringExpenses.status, "active"),
        eq(recurringExpenses.dayOfMonth, currentDay)
      )
    );
    const totalAmount = expenses.reduce((sum, row) => {
      return sum + parseFloat(row.expense.amount);
    }, 0);
    return {
      expenses,
      totalAmount,
      count: expenses.length
    };
  } catch (error) {
    console.error("Error in getRecurringExpensesDueToday:", error);
    return { expenses: [], totalAmount: 0, count: 0 };
  }
}
async function markRecurringExpenseAsPaid(recurringExpenseId, userId) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  try {
    const [expense] = await db.select().from(recurringExpenses).where(eq(recurringExpenses.id, recurringExpenseId));
    if (!expense) {
      throw new Error("Despesa recorrente n\xE3o encontrada");
    }
    const today = /* @__PURE__ */ new Date();
    await db.insert(accountsPayable).values({
      supplierId: expense.supplierId || void 0,
      description: `${expense.name} - ${today.toLocaleDateString("pt-BR")}`,
      amount: expense.amount,
      dueDate: today,
      status: "paid",
      paymentDate: today,
      createdBy: userId || expense.createdBy
    });
    return { success: true };
  } catch (error) {
    console.error("Error in markRecurringExpenseAsPaid:", error);
    throw error;
  }
}
async function getMonthlyFinancialAlerts(year, month) {
  const db = await getDb();
  if (!db) return { payables: [], receivables: [] };
  const startDate = new Date(year, month - 1, 1);
  const endDate = new Date(year, month, 0, 23, 59, 59);
  const payables = await db.select({
    accountPayable: accountsPayable,
    supplier: suppliers,
    category: financialCategories
  }).from(accountsPayable).leftJoin(suppliers, eq(accountsPayable.supplierId, suppliers.id)).leftJoin(financialCategories, eq(accountsPayable.categoryId, financialCategories.id)).where(and(
    eq(accountsPayable.status, "pending"),
    gte(accountsPayable.dueDate, startDate),
    lte(accountsPayable.dueDate, endDate)
  )).orderBy(accountsPayable.dueDate);
  const receivables = await db.select({
    accountReceivable: accountsReceivable,
    order: orders,
    customer: customers
  }).from(accountsReceivable).leftJoin(orders, eq(accountsReceivable.orderId, orders.id)).leftJoin(customers, eq(orders.customerId, customers.id)).where(and(
    eq(accountsReceivable.status, "pending"),
    gte(accountsReceivable.dueDate, startDate),
    lte(accountsReceivable.dueDate, endDate)
  )).orderBy(accountsReceivable.dueDate);
  return { payables, receivables };
}
async function getLeads(filters) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.stage) conditions.push(eq(leads.stage, filters.stage));
  if (filters?.assignedTo) conditions.push(eq(leads.assignedTo, filters.assignedTo));
  const baseQuery = db.select({
    lead: leads,
    assignedUser: users
  }).from(leads).leftJoin(users, eq(leads.assignedTo, users.id));
  if (conditions.length > 0) {
    return await baseQuery.where(and(...conditions)).orderBy(desc(leads.createdAt));
  }
  return await baseQuery.orderBy(desc(leads.createdAt));
}
async function createLead(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(leads).values(data);
  return result;
}
async function updateLead(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(leads).set(data).where(eq(leads.id, id));
  return { success: true };
}
async function deleteAllLeads() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(leadActivities);
  await db.delete(leads);
  return { success: true, message: "Todos os leads foram exclu\xEDdos" };
}
async function getLeadActivities(leadId) {
  const db = await getDb();
  if (!db) return [];
  return await db.select({
    activity: leadActivities,
    creator: users
  }).from(leadActivities).leftJoin(users, eq(leadActivities.createdBy, users.id)).where(eq(leadActivities.leadId, leadId)).orderBy(desc(leadActivities.createdAt));
}
async function createLeadActivity(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(leadActivities).values(data);
  return result;
}
async function getProposals(filters) {
  const db = await getDb();
  if (!db) return [];
  const baseQuery = db.select({
    proposal: proposals,
    lead: leads,
    customer: customers,
    creator: users
  }).from(proposals).leftJoin(leads, eq(proposals.leadId, leads.id)).leftJoin(customers, eq(proposals.customerId, customers.id)).leftJoin(users, eq(proposals.createdBy, users.id));
  if (filters?.status) {
    return await baseQuery.where(eq(proposals.status, filters.status)).orderBy(desc(proposals.createdAt));
  }
  return await baseQuery.orderBy(desc(proposals.createdAt));
}
async function createProposal(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(proposals).values(data);
  return result;
}
async function getProposalItems(proposalId) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(proposalItems).where(eq(proposalItems.proposalId, proposalId));
}
async function getContracts(filters) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.status) conditions.push(eq(contracts.status, filters.status));
  if (filters?.customerId) conditions.push(eq(contracts.customerId, filters.customerId));
  const baseQuery = db.select({
    contract: contracts,
    customer: customers,
    creator: users
  }).from(contracts).leftJoin(customers, eq(contracts.customerId, customers.id)).leftJoin(users, eq(contracts.createdBy, users.id));
  if (conditions.length > 0) {
    return await baseQuery.where(and(...conditions)).orderBy(desc(contracts.createdAt));
  }
  return await baseQuery.orderBy(desc(contracts.createdAt));
}
async function createContract(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(contracts).values(data);
  return result;
}
async function updateContract(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(contracts).set(data).where(eq(contracts.id, id));
  return { success: true };
}
async function deleteContract(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(contractItems).where(eq(contractItems.contractId, id));
  await db.delete(contracts).where(eq(contracts.id, id));
  return { success: true };
}
async function getContractItems(contractId) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(contractItems).where(eq(contractItems.contractId, contractId));
}
async function getTasks(filters) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.status) conditions.push(eq(tasks.status, filters.status));
  if (filters?.projectId) conditions.push(eq(tasks.projectId, filters.projectId));
  if (filters?.assignedTo) conditions.push(eq(tasks.assignedTo, filters.assignedTo));
  const baseQuery = db.select({
    task: tasks,
    project: projects,
    assignedUser: users,
    creator: users
  }).from(tasks).leftJoin(projects, eq(tasks.projectId, projects.id)).leftJoin(users, eq(tasks.assignedTo, users.id));
  if (conditions.length > 0) {
    return await baseQuery.where(and(...conditions)).orderBy(tasks.dueDate, desc(tasks.createdAt));
  }
  return await baseQuery.orderBy(tasks.dueDate, desc(tasks.createdAt));
}
async function createTask(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(tasks).values(data);
  return result;
}
async function updateTask(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(tasks).set(data).where(eq(tasks.id, id));
  return { success: true };
}
async function deleteTask(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(tasks).where(eq(tasks.id, id));
  return { success: true };
}
async function getTimeEntries(filters) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.userId) conditions.push(eq(timeEntries.userId, filters.userId));
  if (filters?.projectId) conditions.push(eq(timeEntries.projectId, filters.projectId));
  if (filters?.startDate) conditions.push(gte(timeEntries.date, filters.startDate));
  if (filters?.endDate) conditions.push(lte(timeEntries.date, filters.endDate));
  const baseQuery = db.select({
    timeEntry: timeEntries,
    task: tasks,
    project: projects,
    user: users
  }).from(timeEntries).leftJoin(tasks, eq(timeEntries.taskId, tasks.id)).leftJoin(projects, eq(timeEntries.projectId, projects.id)).leftJoin(users, eq(timeEntries.userId, users.id));
  if (conditions.length > 0) {
    return await baseQuery.where(and(...conditions)).orderBy(desc(timeEntries.date));
  }
  return await baseQuery.orderBy(desc(timeEntries.date));
}
async function createTimeEntry(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(timeEntries).values(data);
  return result;
}
async function getTickets(filters) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.status) conditions.push(eq(tickets.status, filters.status));
  if (filters?.customerId) conditions.push(eq(tickets.customerId, filters.customerId));
  if (filters?.assignedTo) conditions.push(eq(tickets.assignedTo, filters.assignedTo));
  const baseQuery = db.select({
    ticket: tickets,
    customer: customers,
    assignedUser: users,
    creator: users
  }).from(tickets).leftJoin(customers, eq(tickets.customerId, customers.id)).leftJoin(users, eq(tickets.assignedTo, users.id));
  if (conditions.length > 0) {
    return await baseQuery.where(and(...conditions)).orderBy(desc(tickets.createdAt));
  }
  return await baseQuery.orderBy(desc(tickets.createdAt));
}
async function createTicket(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const now = /* @__PURE__ */ new Date();
  let dueDate = new Date(now);
  switch (data.sla) {
    case "4h":
      dueDate.setHours(dueDate.getHours() + 4);
      break;
    case "24h":
      dueDate.setHours(dueDate.getHours() + 24);
      break;
    case "72h":
      dueDate.setHours(dueDate.getHours() + 72);
      break;
  }
  const result = await db.insert(tickets).values({ ...data, dueDate });
  return result;
}
async function updateTicket(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(tickets).set(data).where(eq(tickets.id, id));
  return { success: true };
}
async function getTicketComments(ticketId) {
  const db = await getDb();
  if (!db) return [];
  return await db.select({
    comment: ticketComments,
    creator: users
  }).from(ticketComments).leftJoin(users, eq(ticketComments.createdBy, users.id)).where(eq(ticketComments.ticketId, ticketId)).orderBy(ticketComments.createdAt);
}
async function createTicketComment(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(ticketComments).values(data);
  return result;
}
async function getProjectChecklists(projectId) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(projectChecklists).where(eq(projectChecklists.projectId, projectId)).orderBy(projectChecklists.order);
}
async function createProjectChecklist(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(projectChecklists).values(data);
  return result;
}
async function updateProjectChecklist(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(projectChecklists).set(data).where(eq(projectChecklists.id, id));
  return { success: true };
}
async function deleteProjectChecklist(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(projectChecklists).where(eq(projectChecklists.id, id));
  return { success: true };
}
async function updateProjectProgressFromChecklists(projectId) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const checklists = await db.select().from(projectChecklists).where(eq(projectChecklists.projectId, projectId));
  if (checklists.length === 0) {
    return { progress: 0 };
  }
  const completedCount = checklists.filter((c) => c.completed === 1).length;
  const progress = Math.round(completedCount / checklists.length * 100);
  await db.update(projects).set({ progress }).where(eq(projects.id, projectId));
  return { progress, total: checklists.length, completed: completedCount };
}
async function getTaskChecklists(taskId) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(taskChecklists).where(eq(taskChecklists.taskId, taskId)).orderBy(taskChecklists.order);
}
async function createTaskChecklist(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(taskChecklists).values(data);
  return result;
}
async function updateTaskChecklist(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(taskChecklists).set(data).where(eq(taskChecklists.id, id));
  return { success: true };
}
async function deleteTaskChecklist(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(taskChecklists).where(eq(taskChecklists.id, id));
  return { success: true };
}
async function getTaskChecklistProgress(taskId) {
  const db = await getDb();
  if (!db) return { progress: 0, total: 0, completed: 0 };
  const checklists = await db.select().from(taskChecklists).where(eq(taskChecklists.taskId, taskId));
  if (checklists.length === 0) {
    return { progress: 0, total: 0, completed: 0 };
  }
  const completedCount = checklists.filter((c) => c.completed === 1).length;
  const progress = Math.round(completedCount / checklists.length * 100);
  return { progress, total: checklists.length, completed: completedCount };
}
async function getRecurringExpenses(filters) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.status) conditions.push(eq(recurringExpenses.status, filters.status));
  if (filters?.category) conditions.push(eq(recurringExpenses.category, filters.category));
  const baseQuery = db.select({
    expense: recurringExpenses,
    supplier: suppliers,
    creator: users
  }).from(recurringExpenses).leftJoin(suppliers, eq(recurringExpenses.supplierId, suppliers.id)).leftJoin(users, eq(recurringExpenses.createdBy, users.id));
  if (conditions.length > 0) {
    return await baseQuery.where(and(...conditions)).orderBy(desc(recurringExpenses.createdAt));
  }
  return await baseQuery.orderBy(desc(recurringExpenses.createdAt));
}
async function createRecurringExpense(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(recurringExpenses).values(data);
  return result;
}
async function updateRecurringExpense(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(recurringExpenses).set(data).where(eq(recurringExpenses.id, id));
  return { success: true };
}
async function deleteRecurringExpense(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(recurringExpenses).where(eq(recurringExpenses.id, id));
  return { success: true };
}
async function deleteAllRecurringExpenses() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(recurringExpenses);
  return { success: true, message: "Todas as despesas recorrentes foram exclu\xEDdas" };
}
async function generateRecurringExpensesBills(userId, month, year) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const now = /* @__PURE__ */ new Date();
  const targetMonth = month ?? now.getMonth();
  const targetYear = year ?? now.getFullYear();
  const activeExpenses = await db.select().from(recurringExpenses).where(eq(recurringExpenses.status, "active"));
  const generated = [];
  const skipped = [];
  for (const expense of activeExpenses) {
    const existingBill = await db.select().from(accountsPayable).where(
      and(
        sql`${accountsPayable.description} LIKE ${`%despesa recorrente #${expense.id}%`}`,
        sql`MONTH(${accountsPayable.dueDate}) = ${targetMonth + 1}`,
        sql`YEAR(${accountsPayable.dueDate}) = ${targetYear}`
      )
    );
    if (existingBill.length > 0) {
      skipped.push({ id: expense.id, name: expense.name, reason: "J\xE1 gerada" });
      continue;
    }
    const dueDate = new Date(targetYear, targetMonth, expense.dayOfMonth);
    const monthName = dueDate.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
    const payableData = {
      amount: expense.amount,
      dueDate,
      status: "pending",
      description: `${expense.name} - ${monthName}`,
      notes: `Gerado automaticamente de despesa recorrente #${expense.id}`,
      createdBy: userId
    };
    if (expense.supplierId) {
      payableData.supplierId = expense.supplierId;
    }
    await db.insert(accountsPayable).values(payableData);
    await db.update(recurringExpenses).set({ lastGenerated: now }).where(eq(recurringExpenses.id, expense.id));
    generated.push({ id: expense.id, name: expense.name });
  }
  return {
    success: true,
    generated: generated.length,
    skipped: skipped.length,
    details: { generated, skipped }
  };
}
async function getProductSubscriptions(filters) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [];
  if (filters?.status) conditions.push(eq(productSubscriptions.status, filters.status));
  if (filters?.customerId) conditions.push(eq(productSubscriptions.customerId, filters.customerId));
  const baseQuery = db.select({
    subscription: productSubscriptions,
    product: products,
    customer: customers,
    creator: users
  }).from(productSubscriptions).leftJoin(products, eq(productSubscriptions.productId, products.id)).leftJoin(customers, eq(productSubscriptions.customerId, customers.id)).leftJoin(users, eq(productSubscriptions.createdBy, users.id));
  if (conditions.length > 0) {
    return await baseQuery.where(and(...conditions)).orderBy(desc(productSubscriptions.createdAt));
  }
  return await baseQuery.orderBy(desc(productSubscriptions.createdAt));
}
async function createProductSubscription(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(productSubscriptions).values(data);
  return result;
}
async function updateProductSubscription(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(productSubscriptions).set(data).where(eq(productSubscriptions.id, id));
  return { success: true };
}
async function getTaxSettings() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const settings = await db.select().from(taxSettings).where(eq(taxSettings.isActive, true)).limit(1);
  return settings[0] || null;
}
async function getCompanySettings() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const settings = await db.select().from(companySettings).where(eq(companySettings.isActive, true)).limit(1);
  return settings[0] || null;
}
async function createCompanySettings(data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.insert(companySettings).values(data);
}
async function updateCompanySettings(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  console.log("updateCompanySettings - id:", id, "data keys:", Object.keys(data), "logo length:", data.logo?.length || 0);
  const result = await db.update(companySettings).set(data).where(eq(companySettings.id, id));
  console.log("updateCompanySettings - result:", result);
  return result;
}
async function getBudgets(filters) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const baseQuery = db.select({
    budget: budgets,
    customer: customers,
    order: orders
  }).from(budgets).leftJoin(customers, eq(budgets.customerId, customers.id)).leftJoin(orders, eq(budgets.id, orders.budgetId));
  if (filters?.status && filters?.customerId) {
    return await baseQuery.where(and(
      eq(budgets.status, filters.status),
      eq(budgets.customerId, filters.customerId)
    )).orderBy(desc(budgets.createdAt));
  } else if (filters?.status) {
    return await baseQuery.where(eq(budgets.status, filters.status)).orderBy(desc(budgets.createdAt));
  } else if (filters?.customerId) {
    return await baseQuery.where(eq(budgets.customerId, filters.customerId)).orderBy(desc(budgets.createdAt));
  }
  return await baseQuery.orderBy(desc(budgets.createdAt));
}
async function getBudgetById(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select({
    budget: budgets,
    customer: customers
  }).from(budgets).leftJoin(customers, eq(budgets.customerId, customers.id)).where(eq(budgets.id, id)).limit(1);
  return result[0] || null;
}
async function createBudget(budget) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  const existingBudgets = await db.select({ budgetNumber: budgets.budgetNumber }).from(budgets).where(sql`${budgets.budgetNumber} LIKE ${`ORC-${year}-%`}`);
  const nextNumber = existingBudgets.length + 1;
  const budgetNumber = `ORC-${year}-${nextNumber.toString().padStart(3, "0")}`;
  const result = await db.insert(budgets).values({
    ...budget,
    budgetNumber
  });
  return result;
}
async function updateBudget(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.update(budgets).set(data).where(eq(budgets.id, id));
}
async function deleteBudget(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(budgets).where(eq(budgets.id, id));
}
async function saveBudgetItems(budgetId, selectedProducts) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const productIds = selectedProducts.map((p) => p.productId);
  const productList = await db.select().from(products).where(inArray(products.id, productIds));
  for (const sp of selectedProducts) {
    const product = productList.find((p) => p.id === sp.productId);
    await db.insert(budgetItems).values({
      budgetId,
      productId: sp.productId,
      type: "service",
      description: product?.name || "Servi\xE7o",
      quantity: sp.quantity.toString(),
      unitPrice: sp.price.toString(),
      totalPrice: (sp.quantity * sp.price).toString()
    });
  }
}
async function getBudgetItems(budgetId) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select({
    item: budgetItems,
    product: products
  }).from(budgetItems).leftJoin(products, eq(budgetItems.productId, products.id)).where(eq(budgetItems.budgetId, budgetId));
}
async function deleteAllBudgets() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(budgets);
  return { success: true, message: "Todos os or\xE7amentos foram exclu\xEDdos" };
}
async function convertBudgetToOrder(budgetId, userId) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const budgetResult = await getBudgetById(budgetId);
  if (!budgetResult) throw new Error("Or\xE7amento n\xE3o encontrado");
  const budget = budgetResult.budget;
  if (budget.status !== "approved") {
    throw new Error("Apenas or\xE7amentos aprovados podem ser convertidos em pedidos");
  }
  let customerId = budget.customerId;
  if (!customerId && budget.customerName) {
    const customerResult = await db.insert(customers).values({
      name: budget.customerName,
      email: budget.customerEmail || null,
      phone: budget.customerPhone || null,
      document: budget.customerDocument || null,
      address: budget.customerAddress || null,
      city: budget.customerCity || null,
      state: budget.customerState || null,
      zipCode: budget.customerZipCode || null,
      createdBy: userId
    });
    customerId = Number(customerResult[0].insertId);
    await db.update(budgets).set({ customerId }).where(eq(budgets.id, budgetId));
  }
  const year = (/* @__PURE__ */ new Date()).getFullYear();
  const countResult = await db.select({ count: sql`COUNT(*)` }).from(orders);
  const count = Number(countResult[0]?.count || 0) + 1;
  const orderNumber = `PED-${year}-${count.toString().padStart(4, "0")}`;
  const orderResult = await db.insert(orders).values({
    orderNumber,
    customerId: customerId || null,
    customerName: budget.customerName || null,
    customerEmail: budget.customerEmail || null,
    customerPhone: budget.customerPhone || null,
    customerAddress: budget.customerAddress || null,
    budgetId,
    status: "pending",
    totalAmount: budget.finalPrice,
    notes: `Convertido do or\xE7amento #${budget.id}: ${budget.title}`,
    createdBy: userId
  });
  const orderId = Number(orderResult[0].insertId);
  let genericProductId = 1;
  const genericProduct = await db.select().from(products).where(eq(products.name, "Servi\xE7o de Or\xE7amento")).limit(1);
  if (genericProduct.length === 0) {
    const newProduct = await db.insert(products).values({
      name: "Servi\xE7o de Or\xE7amento",
      description: "Produto gen\xE9rico para convers\xE3o de or\xE7amentos",
      price: "0",
      category: "Servi\xE7os",
      createdBy: userId
    });
    genericProductId = Number(newProduct[0].insertId);
  } else {
    genericProductId = genericProduct[0].id;
  }
  await db.insert(orderItems).values({
    orderId,
    productId: genericProductId,
    quantity: "1",
    unitPrice: budget.finalPrice,
    subtotal: budget.finalPrice
  });
  await db.update(budgets).set({ status: "converted" }).where(eq(budgets.id, budgetId));
  return { orderId, orderNumber, budget, customerId };
}
async function createProjectFromBudget(budgetId, userId) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const budgetResult = await getBudgetById(budgetId);
  if (!budgetResult) throw new Error("Or\xE7amento n\xE3o encontrado");
  const budget = budgetResult.budget;
  if (budget.status !== "approved" && budget.status !== "converted") {
    throw new Error("Apenas or\xE7amentos aprovados podem gerar projetos");
  }
  const existingProject = await db.select().from(projects).where(sql`${projects.name} LIKE ${`%Or\xE7amento #${budgetId}%`}`).limit(1);
  if (existingProject.length > 0) {
    throw new Error("J\xE1 existe um projeto criado para este or\xE7amento");
  }
  const deadline = /* @__PURE__ */ new Date();
  deadline.setDate(deadline.getDate() + 30);
  const projectResult = await db.insert(projects).values({
    name: `${budget.title} - Or\xE7amento #${budgetId}`,
    description: budget.description || `Projeto gerado a partir do or\xE7amento #${budgetId}`,
    customerId: budget.customerId || null,
    status: "project",
    progress: 0,
    value: budget.finalPrice,
    deadline,
    createdBy: userId
  });
  const projectId = Number(projectResult[0].insertId);
  return {
    projectId,
    message: `Projeto criado com sucesso a partir do or\xE7amento #${budgetId}`
  };
}
async function getBudgetTemplates() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.select().from(budgetTemplates).orderBy(budgetTemplates.name);
}
async function getBudgetTemplateById(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.select().from(budgetTemplates).where(eq(budgetTemplates.id, id));
  return result[0] || null;
}
async function createBudgetTemplate(template) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(budgetTemplates).values(template);
  const id = Number(result[0].insertId);
  return await getBudgetTemplateById(id);
}
async function updateBudgetTemplate(id, data) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(budgetTemplates).set(data).where(eq(budgetTemplates.id, id));
  return await getBudgetTemplateById(id);
}
async function deleteBudgetTemplate(id) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return await db.delete(budgetTemplates).where(eq(budgetTemplates.id, id));
}

// server/_core/cookies.ts
function isSecureRequest(req) {
  if (req.protocol === "https") return true;
  const forwardedProto = req.headers["x-forwarded-proto"];
  if (!forwardedProto) return false;
  const protoList = Array.isArray(forwardedProto) ? forwardedProto : forwardedProto.split(",");
  return protoList.some((proto) => proto.trim().toLowerCase() === "https");
}
function getSessionCookieOptions(req) {
  return {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: isSecureRequest(req)
  };
}

// shared/_core/errors.ts
var HttpError = class extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.name = "HttpError";
  }
};
var ForbiddenError = (msg) => new HttpError(403, msg);

// server/_core/sdk.ts
import axios from "axios";
import { parse as parseCookieHeader } from "cookie";
import { SignJWT, jwtVerify } from "jose";
init_env();
var isNonEmptyString = (value) => typeof value === "string" && value.length > 0;
var EXCHANGE_TOKEN_PATH = `/webdev.v1.WebDevAuthPublicService/ExchangeToken`;
var GET_USER_INFO_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfo`;
var GET_USER_INFO_WITH_JWT_PATH = `/webdev.v1.WebDevAuthPublicService/GetUserInfoWithJwt`;
var OAuthService = class {
  constructor(client) {
    this.client = client;
    console.log("[OAuth] Initialized with baseURL:", ENV.oAuthServerUrl);
    if (!ENV.oAuthServerUrl) {
      console.error(
        "[OAuth] ERROR: OAUTH_SERVER_URL is not configured! Set OAUTH_SERVER_URL environment variable."
      );
    }
  }
  decodeState(state) {
    const redirectUri = atob(state);
    return redirectUri;
  }
  async getTokenByCode(code, state) {
    const payload = {
      clientId: ENV.appId,
      grantType: "authorization_code",
      code,
      redirectUri: this.decodeState(state)
    };
    const { data } = await this.client.post(
      EXCHANGE_TOKEN_PATH,
      payload
    );
    return data;
  }
  async getUserInfoByToken(token) {
    const { data } = await this.client.post(
      GET_USER_INFO_PATH,
      {
        accessToken: token.accessToken
      }
    );
    return data;
  }
};
var createOAuthHttpClient = () => axios.create({
  baseURL: ENV.oAuthServerUrl,
  timeout: AXIOS_TIMEOUT_MS
});
var SDKServer = class {
  client;
  oauthService;
  constructor(client = createOAuthHttpClient()) {
    this.client = client;
    this.oauthService = new OAuthService(this.client);
  }
  deriveLoginMethod(platforms, fallback) {
    if (fallback && fallback.length > 0) return fallback;
    if (!Array.isArray(platforms) || platforms.length === 0) return null;
    const set = new Set(
      platforms.filter((p) => typeof p === "string")
    );
    if (set.has("REGISTERED_PLATFORM_EMAIL")) return "email";
    if (set.has("REGISTERED_PLATFORM_GOOGLE")) return "google";
    if (set.has("REGISTERED_PLATFORM_APPLE")) return "apple";
    if (set.has("REGISTERED_PLATFORM_MICROSOFT") || set.has("REGISTERED_PLATFORM_AZURE"))
      return "microsoft";
    if (set.has("REGISTERED_PLATFORM_GITHUB")) return "github";
    const first = Array.from(set)[0];
    return first ? first.toLowerCase() : null;
  }
  /**
   * Exchange OAuth authorization code for access token
   * @example
   * const tokenResponse = await sdk.exchangeCodeForToken(code, state);
   */
  async exchangeCodeForToken(code, state) {
    return this.oauthService.getTokenByCode(code, state);
  }
  /**
   * Get user information using access token
   * @example
   * const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
   */
  async getUserInfo(accessToken) {
    const data = await this.oauthService.getUserInfoByToken({
      accessToken
    });
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  parseCookies(cookieHeader) {
    if (!cookieHeader) {
      return /* @__PURE__ */ new Map();
    }
    const parsed = parseCookieHeader(cookieHeader);
    return new Map(Object.entries(parsed));
  }
  getSessionSecret() {
    const secret = ENV.cookieSecret;
    return new TextEncoder().encode(secret);
  }
  /**
   * Create a session token for a Manus user openId
   * @example
   * const sessionToken = await sdk.createSessionToken(userInfo.openId);
   */
  async createSessionToken(openId, options = {}) {
    return this.signSession(
      {
        openId,
        appId: ENV.appId,
        name: options.name || ""
      },
      options
    );
  }
  async signSession(payload, options = {}) {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1e3);
    const secretKey = this.getSessionSecret();
    return new SignJWT({
      openId: payload.openId,
      appId: payload.appId,
      name: payload.name
    }).setProtectedHeader({ alg: "HS256", typ: "JWT" }).setExpirationTime(expirationSeconds).sign(secretKey);
  }
  async verifySession(cookieValue) {
    if (!cookieValue) {
      console.warn("[Auth] Missing session cookie");
      return null;
    }
    try {
      const secretKey = this.getSessionSecret();
      const { payload } = await jwtVerify(cookieValue, secretKey, {
        algorithms: ["HS256"]
      });
      const { openId, appId, name } = payload;
      if (!isNonEmptyString(openId) || !isNonEmptyString(appId) || !isNonEmptyString(name)) {
        console.warn("[Auth] Session payload missing required fields");
        return null;
      }
      return {
        openId,
        appId,
        name
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed", String(error));
      return null;
    }
  }
  async getUserInfoWithJwt(jwtToken) {
    const payload = {
      jwtToken,
      projectId: ENV.appId
    };
    const { data } = await this.client.post(
      GET_USER_INFO_WITH_JWT_PATH,
      payload
    );
    const loginMethod = this.deriveLoginMethod(
      data?.platforms,
      data?.platform ?? data.platform ?? null
    );
    return {
      ...data,
      platform: loginMethod,
      loginMethod
    };
  }
  async authenticateRequest(req) {
    const cookies = this.parseCookies(req.headers.cookie);
    const sessionCookie = cookies.get(COOKIE_NAME);
    const session = await this.verifySession(sessionCookie);
    if (!session) {
      throw ForbiddenError("Invalid session cookie");
    }
    const sessionUserId = session.openId;
    const signedInAt = /* @__PURE__ */ new Date();
    let user = await getUserByOpenId(sessionUserId);
    if (!user) {
      try {
        const userInfo = await this.getUserInfoWithJwt(sessionCookie ?? "");
        await upsertUser({
          openId: userInfo.openId,
          name: userInfo.name || null,
          email: userInfo.email ?? null,
          loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
          lastSignedIn: signedInAt
        });
        user = await getUserByOpenId(userInfo.openId);
      } catch (error) {
        console.error("[Auth] Failed to sync user from OAuth:", error);
        throw ForbiddenError("Failed to sync user info");
      }
    }
    if (!user) {
      throw ForbiddenError("User not found");
    }
    await upsertUser({
      openId: user.openId,
      lastSignedIn: signedInAt
    });
    return user;
  }
};
var sdk = new SDKServer();

// server/_core/oauth.ts
function getQueryParam(req, key) {
  const value = req.query[key];
  return typeof value === "string" ? value : void 0;
}
function registerOAuthRoutes(app) {
  app.get("/api/oauth/callback", async (req, res) => {
    const code = getQueryParam(req, "code");
    const state = getQueryParam(req, "state");
    if (!code || !state) {
      res.status(400).json({ error: "code and state are required" });
      return;
    }
    try {
      const tokenResponse = await sdk.exchangeCodeForToken(code, state);
      const userInfo = await sdk.getUserInfo(tokenResponse.accessToken);
      if (!userInfo.openId) {
        res.status(400).json({ error: "openId missing from user info" });
        return;
      }
      await upsertUser({
        openId: userInfo.openId,
        name: userInfo.name || null,
        email: userInfo.email ?? null,
        loginMethod: userInfo.loginMethod ?? userInfo.platform ?? null,
        lastSignedIn: /* @__PURE__ */ new Date()
      });
      const sessionToken = await sdk.createSessionToken(userInfo.openId, {
        name: userInfo.name || "",
        expiresInMs: ONE_YEAR_MS
      });
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      res.redirect(302, "/");
    } catch (error) {
      console.error("[OAuth] Callback failed", error);
      res.status(500).json({ error: "OAuth callback failed" });
    }
  });
}

// server/routers.ts
import { z as z2 } from "zod";
import { TRPCError as TRPCError3 } from "@trpc/server";

// server/_core/systemRouter.ts
import { z } from "zod";

// server/_core/notification.ts
init_env();
import { TRPCError } from "@trpc/server";
var TITLE_MAX_LENGTH = 1200;
var CONTENT_MAX_LENGTH = 2e4;
var trimValue = (value) => value.trim();
var isNonEmptyString2 = (value) => typeof value === "string" && value.trim().length > 0;
var buildEndpointUrl = (baseUrl) => {
  const normalizedBase = baseUrl.endsWith("/") ? baseUrl : `${baseUrl}/`;
  return new URL(
    "webdevtoken.v1.WebDevService/SendNotification",
    normalizedBase
  ).toString();
};
var validatePayload = (input) => {
  if (!isNonEmptyString2(input.title)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification title is required."
    });
  }
  if (!isNonEmptyString2(input.content)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification content is required."
    });
  }
  const title = trimValue(input.title);
  const content = trimValue(input.content);
  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification title must be at most ${TITLE_MAX_LENGTH} characters.`
    });
  }
  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification content must be at most ${CONTENT_MAX_LENGTH} characters.`
    });
  }
  return { title, content };
};
async function notifyOwner(payload) {
  const { title, content } = validatePayload(payload);
  if (!ENV.forgeApiUrl) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service URL is not configured."
    });
  }
  if (!ENV.forgeApiKey) {
    throw new TRPCError({
      code: "INTERNAL_SERVER_ERROR",
      message: "Notification service API key is not configured."
    });
  }
  const endpoint = buildEndpointUrl(ENV.forgeApiUrl);
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        accept: "application/json",
        authorization: `Bearer ${ENV.forgeApiKey}`,
        "content-type": "application/json",
        "connect-protocol-version": "1"
      },
      body: JSON.stringify({ title, content })
    });
    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.warn(
        `[Notification] Failed to notify owner (${response.status} ${response.statusText})${detail ? `: ${detail}` : ""}`
      );
      return false;
    }
    return true;
  } catch (error) {
    console.warn("[Notification] Error calling notification service:", error);
    return false;
  }
}

// server/_core/trpc.ts
import { initTRPC, TRPCError as TRPCError2 } from "@trpc/server";
import superjson from "superjson";
var t = initTRPC.context().create({
  transformer: superjson
});
var router = t.router;
var publicProcedure = t.procedure;
var requireUser = t.middleware(async (opts) => {
  const { ctx, next } = opts;
  if (!ctx.user) {
    throw new TRPCError2({ code: "UNAUTHORIZED", message: UNAUTHED_ERR_MSG });
  }
  return next({
    ctx: {
      ...ctx,
      user: ctx.user
    }
  });
});
var protectedProcedure = t.procedure.use(requireUser);
var adminProcedure = t.procedure.use(
  t.middleware(async (opts) => {
    const { ctx, next } = opts;
    if (!ctx.user || ctx.user.role !== "admin") {
      throw new TRPCError2({ code: "FORBIDDEN", message: NOT_ADMIN_ERR_MSG });
    }
    return next({
      ctx: {
        ...ctx,
        user: ctx.user
      }
    });
  })
);

// server/_core/systemRouter.ts
var systemRouter = router({
  health: publicProcedure.input(
    z.object({
      timestamp: z.number().min(0, "timestamp cannot be negative")
    })
  ).query(() => ({
    ok: true
  })),
  notifyOwner: adminProcedure.input(
    z.object({
      title: z.string().min(1, "title is required"),
      content: z.string().min(1, "content is required")
    })
  ).mutation(async ({ input }) => {
    const delivered = await notifyOwner(input);
    return {
      success: delivered
    };
  })
});

// server/routers.ts
var appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true
      };
    })
  }),
  // ============ CUSTOMERS ============
  customers: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await getCustomers(ctx.user.id);
    }),
    getById: protectedProcedure.input(z2.object({ id: z2.number() })).query(async ({ input }) => {
      return await getCustomerById(input.id);
    }),
    create: protectedProcedure.input(z2.object({
      name: z2.string().min(1),
      email: z2.string().email().optional().or(z2.literal("")),
      phone: z2.string().optional(),
      document: z2.string().optional(),
      address: z2.string().optional(),
      city: z2.string().optional(),
      state: z2.string().max(2).optional(),
      zipCode: z2.string().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ ctx, input }) => {
      const customer = {
        ...input,
        email: input.email || null,
        createdBy: ctx.user.id
      };
      return await createCustomer(customer);
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      name: z2.string().min(1).optional(),
      email: z2.string().email().optional().or(z2.literal("")),
      phone: z2.string().optional(),
      document: z2.string().optional(),
      address: z2.string().optional(),
      city: z2.string().optional(),
      state: z2.string().max(2).optional(),
      zipCode: z2.string().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      if (data.email === "") data.email = void 0;
      return await updateCustomer(id, data);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteCustomer(input.id);
    })
  }),
  // ============ PRODUCTS ============
  products: router({
    list: protectedProcedure.input(z2.object({ activeOnly: z2.boolean().optional() }).optional()).query(async ({ input }) => {
      return await getProducts(input?.activeOnly);
    }),
    getById: protectedProcedure.input(z2.object({ id: z2.number() })).query(async ({ input }) => {
      return await getProductById(input.id);
    }),
    create: protectedProcedure.input(z2.object({
      name: z2.string().min(1),
      description: z2.string().optional(),
      type: z2.enum(["product", "service"]),
      price: z2.string().regex(/^\d+(\.\d{1,2})?$/),
      unit: z2.string().default("un"),
      category: z2.string().optional(),
      active: z2.enum(["yes", "no"]).default("yes")
    })).mutation(async ({ ctx, input }) => {
      const product = {
        ...input,
        createdBy: ctx.user.id
      };
      return await createProduct(product);
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      name: z2.string().min(1).optional(),
      description: z2.string().optional(),
      type: z2.enum(["product", "service"]).optional(),
      price: z2.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
      unit: z2.string().optional(),
      category: z2.string().optional(),
      active: z2.enum(["yes", "no"]).optional()
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await updateProduct(id, data);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteProduct(input.id);
    })
  }),
  // ============ SUPPLIERS ============
  suppliers: router({
    list: protectedProcedure.query(async () => {
      return await getSuppliers();
    }),
    getById: protectedProcedure.input(z2.object({ id: z2.number() })).query(async ({ input }) => {
      return await getSupplierById(input.id);
    }),
    create: protectedProcedure.input(z2.object({
      name: z2.string().min(1),
      email: z2.string().email().optional().or(z2.literal("")),
      phone: z2.string().optional(),
      document: z2.string().optional(),
      address: z2.string().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ ctx, input }) => {
      const supplier = {
        ...input,
        email: input.email || null,
        createdBy: ctx.user.id
      };
      return await createSupplier(supplier);
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      name: z2.string().min(1).optional(),
      email: z2.string().email().optional().or(z2.literal("")),
      phone: z2.string().optional(),
      document: z2.string().optional(),
      address: z2.string().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      if (data.email === "") data.email = void 0;
      return await updateSupplier(id, data);
    })
  }),
  // ============ ORDERS ============
  orders: router({
    list: protectedProcedure.input(z2.object({
      status: z2.enum(["pending", "approved", "in_production", "completed", "cancelled"]).optional(),
      startDate: z2.date().optional(),
      endDate: z2.date().optional()
    }).optional()).query(async ({ input }) => {
      return await getOrders(input);
    }),
    getById: protectedProcedure.input(z2.object({ id: z2.number() })).query(async ({ input }) => {
      return await getOrderById(input.id);
    }),
    create: protectedProcedure.input(z2.object({
      customerId: z2.number(),
      orderNumber: z2.string(),
      items: z2.array(z2.object({
        productId: z2.number(),
        quantity: z2.string(),
        unitPrice: z2.string(),
        subtotal: z2.string()
      })),
      totalAmount: z2.string(),
      notes: z2.string().optional()
    })).mutation(async ({ ctx, input }) => {
      const { items, ...orderData } = input;
      const order = {
        ...orderData,
        status: "pending",
        createdBy: ctx.user.id
      };
      return await createOrder(order, items);
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      customerId: z2.number().optional(),
      orderNumber: z2.string().optional(),
      items: z2.array(z2.object({
        productId: z2.number(),
        quantity: z2.string(),
        unitPrice: z2.string(),
        subtotal: z2.string()
      })).optional(),
      totalAmount: z2.string().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input }) => {
      const { id, items, ...orderData } = input;
      return await updateOrder(id, orderData, items);
    }),
    updateStatus: protectedProcedure.input(z2.object({
      id: z2.number(),
      status: z2.enum(["pending", "approved", "in_production", "completed", "cancelled"])
    })).mutation(async ({ input }) => {
      return await updateOrderStatus(input.id, input.status);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteOrder(input.id);
    })
  }),
  // ============ FINANCIAL CATEGORIES ============
  financialCategories: router({
    list: protectedProcedure.input(z2.object({ type: z2.enum(["expense", "income"]).optional() }).optional()).query(async ({ input }) => {
      return await getFinancialCategories(input?.type);
    }),
    create: protectedProcedure.input(z2.object({
      name: z2.string().min(1),
      type: z2.enum(["expense", "income"]),
      color: z2.string().optional()
    })).mutation(async ({ ctx, input }) => {
      const category = {
        ...input,
        createdBy: ctx.user.id
      };
      return await createFinancialCategory(category);
    })
  }),
  // ============ ACCOUNTS PAYABLE ============
  accountsPayable: router({
    list: protectedProcedure.input(z2.object({
      status: z2.enum(["pending", "paid", "overdue", "cancelled"]).optional(),
      startDate: z2.date().optional(),
      endDate: z2.date().optional()
    }).optional()).query(async ({ input }) => {
      return await getAccountsPayable(input);
    }),
    create: protectedProcedure.input(z2.object({
      supplierId: z2.number().optional(),
      categoryId: z2.number().optional(),
      description: z2.string().min(1),
      amount: z2.string().regex(/^\d+(\.\d{1,2})?$/),
      dueDate: z2.date(),
      notes: z2.string().optional(),
      installments: z2.number().min(1).max(120).default(1)
    })).mutation(async ({ ctx, input }) => {
      return await createAccountPayableWithInstallments({
        ...input,
        createdBy: ctx.user.id
      });
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      supplierId: z2.number().optional(),
      categoryId: z2.number().optional(),
      description: z2.string().min(1).optional(),
      amount: z2.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
      dueDate: z2.date().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await updateAccountPayable(id, data);
    }),
    markAsPaid: protectedProcedure.input(z2.object({
      id: z2.number(),
      paymentDate: z2.date()
    })).mutation(async ({ input }) => {
      return await markAccountPayableAsPaid(input.id, input.paymentDate);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteAccountPayable(input.id);
    }),
    deleteAll: protectedProcedure.mutation(async () => {
      return await deleteAllAccountsPayable();
    })
  }),
  // ============ ACCOUNTS RECEIVABLE ============
  accountsReceivable: router({
    list: protectedProcedure.input(z2.object({
      status: z2.enum(["pending", "received", "overdue", "cancelled"]).optional(),
      startDate: z2.date().optional(),
      endDate: z2.date().optional()
    }).optional()).query(async ({ input }) => {
      return await getAccountsReceivable(input);
    }),
    create: protectedProcedure.input(z2.object({
      orderId: z2.number().optional(),
      customerId: z2.number(),
      description: z2.string().min(1),
      amount: z2.string().regex(/^\d+(\.\d{1,2})?$/),
      dueDate: z2.date(),
      notes: z2.string().optional(),
      installments: z2.number().min(1).max(120).default(1)
    })).mutation(async ({ ctx, input }) => {
      return await createAccountReceivableWithInstallments({
        ...input,
        createdBy: ctx.user.id
      });
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      orderId: z2.number().optional(),
      customerId: z2.number().optional(),
      description: z2.string().min(1).optional(),
      amount: z2.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
      dueDate: z2.date().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await updateAccountReceivable(id, data);
    }),
    markAsReceived: protectedProcedure.input(z2.object({
      id: z2.number(),
      receivedDate: z2.date()
    })).mutation(async ({ input }) => {
      return await markAccountReceivableAsReceived(input.id, input.receivedDate);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteAccountReceivable(input.id);
    }),
    deleteAll: protectedProcedure.mutation(async () => {
      return await deleteAllAccountsReceivable();
    })
  }),
  // ============ PROJECTS ============
  projects: router({
    list: protectedProcedure.input(z2.object({ status: z2.enum(["project", "development", "design", "review", "launched", "cancelled"]).optional() }).optional()).query(async ({ input }) => {
      return await getProjects(input);
    }),
    create: protectedProcedure.input(z2.object({
      name: z2.string().min(1),
      description: z2.string().optional(),
      customerId: z2.number().optional(),
      status: z2.enum(["project", "development", "design", "review", "launched", "cancelled"]),
      progress: z2.number().min(0).max(100),
      value: z2.string().regex(/^\d+(\.\d{1,2})?$/),
      deadline: z2.date()
    })).mutation(async ({ ctx, input }) => {
      const project = {
        ...input,
        createdBy: ctx.user.id
      };
      return await createProject(project);
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      name: z2.string().min(1).optional(),
      description: z2.string().optional(),
      customerId: z2.number().optional(),
      status: z2.enum(["project", "development", "design", "review", "launched", "cancelled"]).optional(),
      progress: z2.number().min(0).max(100).optional(),
      value: z2.string().regex(/^\d+(\.\d{1,2})?$/).optional(),
      deadline: z2.date().optional()
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await updateProject(id, data);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteProject(input.id);
    }),
    // Checklist
    getChecklists: protectedProcedure.input(z2.object({ projectId: z2.number() })).query(async ({ input }) => {
      return await getProjectChecklists(input.projectId);
    }),
    createChecklist: protectedProcedure.input(z2.object({
      projectId: z2.number(),
      title: z2.string().min(1),
      order: z2.number().optional()
    })).mutation(async ({ input }) => {
      return await createProjectChecklist(input);
    }),
    updateChecklist: protectedProcedure.input(z2.object({
      id: z2.number(),
      title: z2.string().optional(),
      completed: z2.number().optional(),
      order: z2.number().optional()
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await updateProjectChecklist(id, data);
    }),
    deleteChecklist: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteProjectChecklist(input.id);
    }),
    updateProgress: protectedProcedure.input(z2.object({ projectId: z2.number() })).mutation(async ({ input }) => {
      return await updateProjectProgressFromChecklists(input.projectId);
    })
  }),
  // ============ CALENDAR ============
  calendar: router({
    events: protectedProcedure.input(z2.object({
      startDate: z2.date().optional(),
      endDate: z2.date().optional()
    }).optional()).query(async ({ input }) => {
      return await getCalendarEvents(input);
    }),
    financialAlerts: protectedProcedure.input(z2.object({
      year: z2.number(),
      month: z2.number()
    })).query(async ({ input }) => {
      return await getMonthlyFinancialAlerts(input.year, input.month);
    }),
    create: protectedProcedure.input(z2.object({
      title: z2.string(),
      description: z2.string().optional(),
      eventType: z2.enum(["meeting", "visit", "call", "other"]),
      startDate: z2.date(),
      endDate: z2.date(),
      customerId: z2.number().optional(),
      projectId: z2.number().optional(),
      location: z2.string().optional()
    })).mutation(async ({ input, ctx }) => {
      return await createCalendarEvent({ ...input, createdBy: ctx.user.id });
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      data: z2.object({
        title: z2.string().optional(),
        description: z2.string().optional(),
        eventType: z2.enum(["meeting", "visit", "call", "other"]).optional(),
        startDate: z2.date().optional(),
        endDate: z2.date().optional(),
        customerId: z2.number().optional(),
        projectId: z2.number().optional(),
        location: z2.string().optional()
      })
    })).mutation(async ({ input }) => {
      return await updateCalendarEvent(input.id, input.data);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteCalendarEvent(input.id);
    })
  }),
  // ============ LEADS / CRM ============
  leads: router({
    list: protectedProcedure.input(z2.object({
      stage: z2.enum(["new", "contacted", "qualified", "proposal", "negotiation", "won", "lost"]).optional(),
      assignedTo: z2.number().optional()
    }).optional()).query(async ({ input }) => {
      return await getLeads(input);
    }),
    create: protectedProcedure.input(z2.object({
      name: z2.string(),
      company: z2.string().optional(),
      email: z2.string().optional(),
      phone: z2.string().optional(),
      source: z2.enum(["website", "referral", "cold_call", "social_media", "event", "other"]),
      stage: z2.enum(["new", "contacted", "qualified", "proposal", "negotiation", "won", "lost"]).default("new"),
      estimatedValue: z2.string().optional(),
      assignedTo: z2.number().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input, ctx }) => {
      return await createLead({ ...input, createdBy: ctx.user.id });
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      data: z2.object({
        name: z2.string().optional(),
        company: z2.string().optional(),
        email: z2.string().optional(),
        phone: z2.string().optional(),
        source: z2.enum(["website", "referral", "cold_call", "social_media", "event", "other"]).optional(),
        stage: z2.enum(["new", "contacted", "qualified", "proposal", "negotiation", "won", "lost"]).optional(),
        estimatedValue: z2.string().optional(),
        assignedTo: z2.number().optional(),
        notes: z2.string().optional()
      })
    })).mutation(async ({ input }) => {
      return await updateLead(input.id, input.data);
    }),
    activities: protectedProcedure.input(z2.object({ leadId: z2.number() })).query(async ({ input }) => {
      return await getLeadActivities(input.leadId);
    }),
    createActivity: protectedProcedure.input(z2.object({
      leadId: z2.number(),
      activityType: z2.enum(["call", "meeting", "email", "follow_up", "note"]),
      subject: z2.string(),
      description: z2.string().optional(),
      scheduledDate: z2.date().optional(),
      status: z2.enum(["scheduled", "completed", "cancelled"]).default("scheduled")
    })).mutation(async ({ input, ctx }) => {
      return await createLeadActivity({ ...input, createdBy: ctx.user.id });
    }),
    deleteAll: protectedProcedure.mutation(async () => {
      return await deleteAllLeads();
    })
  }),
  // ============ PROPOSALS ============
  proposals: router({
    list: protectedProcedure.input(z2.object({ status: z2.enum(["draft", "sent", "accepted", "rejected", "expired"]).optional() }).optional()).query(async ({ input }) => {
      return await getProposals(input);
    }),
    create: protectedProcedure.input(z2.object({
      leadId: z2.number().optional(),
      customerId: z2.number().optional(),
      title: z2.string(),
      description: z2.string().optional(),
      totalValue: z2.string(),
      estimatedTax: z2.string().optional(),
      validUntil: z2.date().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input, ctx }) => {
      return await createProposal({ ...input, status: "draft", createdBy: ctx.user.id });
    }),
    items: protectedProcedure.input(z2.object({ proposalId: z2.number() })).query(async ({ input }) => {
      return await getProposalItems(input.proposalId);
    })
  }),
  // ============ CONTRACTS ============
  contracts: router({
    list: protectedProcedure.input(z2.object({
      status: z2.enum(["active", "suspended", "cancelled", "expired"]).optional(),
      customerId: z2.number().optional()
    }).optional()).query(async ({ input }) => {
      return await getContracts(input);
    }),
    create: protectedProcedure.input(z2.object({
      customerId: z2.number(),
      title: z2.string(),
      description: z2.string().optional(),
      contractType: z2.enum(["maintenance", "hosting", "support", "software_license", "other"]),
      monthlyValue: z2.string(),
      startDate: z2.date(),
      endDate: z2.date().optional(),
      renewalDate: z2.date().optional(),
      adjustmentRate: z2.string().optional(),
      billingDay: z2.number().default(1),
      notes: z2.string().optional()
    })).mutation(async ({ input, ctx }) => {
      return await createContract({ ...input, status: "active", createdBy: ctx.user.id });
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      data: z2.object({
        customerId: z2.number().optional(),
        title: z2.string().optional(),
        description: z2.string().optional(),
        contractType: z2.enum(["maintenance", "hosting", "support", "software_license", "other"]).optional(),
        monthlyValue: z2.string().optional(),
        startDate: z2.date().optional(),
        status: z2.enum(["active", "suspended", "cancelled", "expired"]).optional(),
        endDate: z2.date().optional(),
        renewalDate: z2.date().optional(),
        billingDay: z2.number().optional(),
        notes: z2.string().optional()
      })
    })).mutation(async ({ input }) => {
      return await updateContract(input.id, input.data);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteContract(input.id);
    }),
    items: protectedProcedure.input(z2.object({ contractId: z2.number() })).query(async ({ input }) => {
      return await getContractItems(input.contractId);
    })
  }),
  // ============ TASKS ============
  tasks: router({
    list: protectedProcedure.input(z2.object({
      status: z2.enum(["todo", "in_progress", "review", "done", "cancelled"]).optional(),
      projectId: z2.number().optional(),
      assignedTo: z2.number().optional()
    }).optional()).query(async ({ input }) => {
      return await getTasks(input);
    }),
    create: protectedProcedure.input(z2.object({
      title: z2.string(),
      description: z2.string().optional(),
      projectId: z2.number().optional(),
      assignedTo: z2.number().optional(),
      priority: z2.enum(["low", "medium", "high", "urgent"]).default("medium"),
      estimatedHours: z2.string().optional(),
      dueDate: z2.date().optional()
    })).mutation(async ({ input, ctx }) => {
      return await createTask({ ...input, status: "todo", createdBy: ctx.user.id });
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      data: z2.object({
        title: z2.string().optional(),
        description: z2.string().optional(),
        status: z2.enum(["todo", "in_progress", "review", "done", "cancelled"]).optional(),
        priority: z2.enum(["low", "medium", "high", "urgent"]).optional(),
        assignedTo: z2.number().optional(),
        dueDate: z2.date().optional(),
        completedDate: z2.date().optional()
      })
    })).mutation(async ({ input }) => {
      return await updateTask(input.id, input.data);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteTask(input.id);
    }),
    // Checklist
    getChecklists: protectedProcedure.input(z2.object({ taskId: z2.number() })).query(async ({ input }) => {
      return await getTaskChecklists(input.taskId);
    }),
    createChecklist: protectedProcedure.input(z2.object({
      taskId: z2.number(),
      title: z2.string().min(1),
      order: z2.number().optional()
    })).mutation(async ({ input }) => {
      return await createTaskChecklist(input);
    }),
    updateChecklist: protectedProcedure.input(z2.object({
      id: z2.number(),
      title: z2.string().optional(),
      completed: z2.number().optional(),
      order: z2.number().optional()
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await updateTaskChecklist(id, data);
    }),
    deleteChecklist: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteTaskChecklist(input.id);
    }),
    getChecklistProgress: protectedProcedure.input(z2.object({ taskId: z2.number() })).query(async ({ input }) => {
      return await getTaskChecklistProgress(input.taskId);
    })
  }),
  // ============ TIME ENTRIES ============
  timeEntries: router({
    list: protectedProcedure.input(z2.object({
      userId: z2.number().optional(),
      projectId: z2.number().optional(),
      startDate: z2.date().optional(),
      endDate: z2.date().optional()
    }).optional()).query(async ({ input }) => {
      return await getTimeEntries(input);
    }),
    create: protectedProcedure.input(z2.object({
      taskId: z2.number().optional(),
      projectId: z2.number().optional(),
      description: z2.string().optional(),
      hours: z2.string(),
      date: z2.date()
    })).mutation(async ({ input, ctx }) => {
      return await createTimeEntry({ ...input, userId: ctx.user.id });
    })
  }),
  // ============ TICKETS / SUPPORT ============
  tickets: router({
    list: protectedProcedure.input(z2.object({
      status: z2.enum(["open", "in_progress", "waiting_customer", "resolved", "closed"]).optional(),
      customerId: z2.number().optional(),
      assignedTo: z2.number().optional()
    }).optional()).query(async ({ input }) => {
      return await getTickets(input);
    }),
    create: protectedProcedure.input(z2.object({
      customerId: z2.number(),
      subject: z2.string(),
      description: z2.string(),
      category: z2.enum(["bug", "adjustment", "content", "financial", "other"]),
      priority: z2.enum(["low", "medium", "high", "urgent"]).default("medium"),
      sla: z2.enum(["4h", "24h", "72h"]).default("24h"),
      assignedTo: z2.number().optional()
    })).mutation(async ({ input, ctx }) => {
      return await createTicket({ ...input, status: "open", createdBy: ctx.user.id });
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      data: z2.object({
        status: z2.enum(["open", "in_progress", "waiting_customer", "resolved", "closed"]).optional(),
        assignedTo: z2.number().optional(),
        resolvedDate: z2.date().optional(),
        closedDate: z2.date().optional()
      })
    })).mutation(async ({ input }) => {
      return await updateTicket(input.id, input.data);
    }),
    comments: protectedProcedure.input(z2.object({ ticketId: z2.number() })).query(async ({ input }) => {
      return await getTicketComments(input.ticketId);
    }),
    createComment: protectedProcedure.input(z2.object({
      ticketId: z2.number(),
      comment: z2.string(),
      isInternal: z2.number().default(0)
    })).mutation(async ({ input, ctx }) => {
      return await createTicketComment({ ...input, createdBy: ctx.user.id });
    })
  }),
  // ============ RECURRING EXPENSES ============
  recurringExpenses: router({
    list: protectedProcedure.input(z2.object({ status: z2.enum(["active", "paused", "cancelled"]).optional(), category: z2.enum(["electricity", "water", "phone", "internet", "rent", "insurance", "software", "maintenance", "other"]).optional() }).optional()).query(async ({ input }) => {
      return await getRecurringExpenses(input);
    }),
    create: protectedProcedure.input(z2.object({
      name: z2.string(),
      category: z2.enum(["electricity", "water", "phone", "internet", "rent", "insurance", "software", "maintenance", "other"]),
      supplierId: z2.number().optional(),
      amount: z2.string(),
      frequency: z2.enum(["monthly", "quarterly", "yearly"]),
      dayOfMonth: z2.number().min(1).max(31),
      startDate: z2.date(),
      endDate: z2.date().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input, ctx }) => {
      return await createRecurringExpense({ ...input, createdBy: ctx.user.id });
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      status: z2.enum(["active", "paused", "cancelled"]).optional(),
      amount: z2.string().optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await updateRecurringExpense(id, data);
    }),
    markAsPaid: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input, ctx }) => {
      return await markRecurringExpenseAsPaid(input.id, ctx.user.id);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteRecurringExpense(input.id);
    }),
    deleteAll: protectedProcedure.mutation(async () => {
      return await deleteAllRecurringExpenses();
    }),
    generateMonthlyBills: protectedProcedure.input(z2.object({ month: z2.number(), year: z2.number() }).optional()).mutation(async ({ ctx }) => {
      return await generateRecurringExpensesBills(ctx.user.id);
    })
  }),
  productSubscriptions: router({
    list: protectedProcedure.input(z2.object({ status: z2.enum(["active", "paused", "cancelled"]).optional(), customerId: z2.number().optional() }).optional()).query(async ({ input }) => {
      return await getProductSubscriptions(input);
    }),
    create: protectedProcedure.input(z2.object({
      productId: z2.number(),
      customerId: z2.number(),
      frequency: z2.enum(["monthly", "quarterly", "yearly"]),
      price: z2.string(),
      startDate: z2.date(),
      endDate: z2.date().optional(),
      nextBillingDate: z2.date()
    })).mutation(async ({ input, ctx }) => {
      return await createProductSubscription({ ...input, createdBy: ctx.user.id, status: "active" });
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      status: z2.enum(["active", "paused", "cancelled"]).optional(),
      price: z2.string().optional()
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      return await updateProductSubscription(id, data);
    })
  }),
  // ============ DASHBOARD ============
  dashboard: router({
    stats: protectedProcedure.input(z2.object({
      startDate: z2.date().optional(),
      endDate: z2.date().optional()
    }).optional()).query(async ({ input }) => {
      return await getDashboardStats(input?.startDate, input?.endDate);
    }),
    cashFlow: protectedProcedure.input(z2.object({ year: z2.number() })).query(async ({ input }) => {
      return await getMonthlyCashFlow(input.year);
    }),
    paymentsDueToday: protectedProcedure.query(async () => {
      return await getPaymentsDueToday();
    }),
    recurringExpensesDueToday: protectedProcedure.query(async () => {
      return await getRecurringExpensesDueToday();
    })
  }),
  budgets: router({
    list: protectedProcedure.input(z2.object({
      status: z2.enum(["draft", "sent", "approved", "rejected"]).optional(),
      customerId: z2.number().optional()
    }).optional()).query(async ({ input }) => {
      return await getBudgets(input || {});
    }),
    getById: protectedProcedure.input(z2.object({ id: z2.number() })).query(async ({ input }) => {
      return await getBudgetById(input.id);
    }),
    create: protectedProcedure.input(z2.object({
      customerId: z2.number().optional(),
      customerName: z2.string().optional(),
      customerEmail: z2.string().optional(),
      customerPhone: z2.string().optional(),
      customerDocument: z2.string().optional(),
      customerAddress: z2.string().optional(),
      customerCity: z2.string().optional(),
      customerState: z2.string().optional(),
      customerZipCode: z2.string().optional(),
      title: z2.string(),
      description: z2.string().optional(),
      laborCost: z2.number(),
      laborHours: z2.number(),
      laborRate: z2.number().optional(),
      materialCost: z2.number(),
      thirdPartyCost: z2.number(),
      otherDirectCosts: z2.number(),
      indirectCostsTotal: z2.number(),
      profitMargin: z2.number(),
      cbsRate: z2.number().optional(),
      ibsRate: z2.number().optional(),
      irpjRate: z2.number().optional(),
      csllRate: z2.number().optional(),
      notes: z2.string().optional(),
      selectedProducts: z2.array(z2.object({
        productId: z2.number(),
        quantity: z2.number(),
        price: z2.number()
      })).optional()
    })).mutation(async ({ input, ctx }) => {
      const taxConfig = await getTaxSettings();
      if (!taxConfig) throw new TRPCError3({ code: "NOT_FOUND", message: "Configura\xE7\xF5es fiscais n\xE3o encontradas" });
      const cbsRate = input.cbsRate ?? Number(taxConfig.cbsRate);
      const ibsRate = input.ibsRate ?? Number(taxConfig.ibsRate);
      const irpjRate = input.irpjRate ?? Number(taxConfig.irpjRate);
      const csllRate = input.csllRate ?? Number(taxConfig.csllRate);
      const totalDirectCosts = input.laborCost + input.materialCost + input.thirdPartyCost + input.otherDirectCosts;
      const totalCosts = totalDirectCosts + input.indirectCostsTotal;
      const grossValue = input.profitMargin >= 100 ? totalCosts : totalCosts / (1 - input.profitMargin / 100);
      const cbsAmount = grossValue * (cbsRate / 100);
      const ibsAmount = grossValue * (ibsRate / 100);
      const totalConsumptionTaxes = cbsAmount + ibsAmount;
      const netRevenue = grossValue - totalConsumptionTaxes;
      const profitBeforeTaxes = netRevenue - totalCosts;
      const irpjAmount = profitBeforeTaxes * (irpjRate / 100);
      const csllAmount = profitBeforeTaxes * (csllRate / 100);
      const netProfit = profitBeforeTaxes - irpjAmount - csllAmount;
      const { selectedProducts, ...inputWithoutProducts } = input;
      const budgetData = {
        ...inputWithoutProducts,
        laborCost: input.laborCost.toString(),
        laborHours: input.laborHours.toString(),
        laborRate: (input.laborRate || 0).toString(),
        materialCost: input.materialCost.toString(),
        thirdPartyCost: input.thirdPartyCost.toString(),
        otherDirectCosts: input.otherDirectCosts.toString(),
        indirectCostsTotal: input.indirectCostsTotal.toString(),
        profitMargin: input.profitMargin.toString(),
        cbsRate: cbsRate.toString(),
        ibsRate: ibsRate.toString(),
        irpjRate: irpjRate.toString(),
        csllRate: csllRate.toString(),
        totalDirectCosts: totalDirectCosts.toString(),
        totalCosts: totalCosts.toString(),
        grossValue: grossValue.toString(),
        cbsAmount: cbsAmount.toString(),
        ibsAmount: ibsAmount.toString(),
        totalConsumptionTaxes: totalConsumptionTaxes.toString(),
        netRevenue: netRevenue.toString(),
        profitBeforeTaxes: profitBeforeTaxes.toString(),
        irpjAmount: irpjAmount.toString(),
        csllAmount: csllAmount.toString(),
        netProfit: netProfit.toString(),
        finalPrice: grossValue.toString(),
        taxRegime: taxConfig.taxRegime,
        createdBy: ctx.user.id
      };
      const result = await createBudget(budgetData);
      if (input.selectedProducts && input.selectedProducts.length > 0) {
        const budgetId = Number(result[0].insertId);
        await saveBudgetItems(budgetId, input.selectedProducts);
      }
      return result;
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      customerId: z2.number().optional(),
      customerName: z2.string().optional(),
      customerEmail: z2.string().optional(),
      customerPhone: z2.string().optional(),
      customerDocument: z2.string().optional(),
      customerAddress: z2.string().optional(),
      customerCity: z2.string().optional(),
      customerState: z2.string().optional(),
      customerZipCode: z2.string().optional(),
      title: z2.string().optional(),
      description: z2.string().optional(),
      laborCost: z2.number().optional(),
      laborHours: z2.number().optional(),
      laborRate: z2.number().optional(),
      materialCost: z2.number().optional(),
      thirdPartyCost: z2.number().optional(),
      otherDirectCosts: z2.number().optional(),
      indirectCostsTotal: z2.number().optional(),
      profitMargin: z2.number().optional(),
      cbsRate: z2.number().optional(),
      ibsRate: z2.number().optional(),
      irpjRate: z2.number().optional(),
      csllRate: z2.number().optional(),
      status: z2.enum(["draft", "sent", "approved", "rejected"]).optional(),
      notes: z2.string().optional()
    })).mutation(async ({ input, ctx }) => {
      const { id, ...rest } = input;
      if (rest.laborCost !== void 0 || rest.materialCost !== void 0 || rest.thirdPartyCost !== void 0 || rest.otherDirectCosts !== void 0 || rest.indirectCostsTotal !== void 0 || rest.profitMargin !== void 0) {
        const taxConfig = await getTaxSettings();
        if (!taxConfig) throw new TRPCError3({ code: "NOT_FOUND", message: "Configura\xE7\xF5es fiscais n\xE3o encontradas" });
        const current = await getBudgetById(id);
        if (!current) throw new TRPCError3({ code: "NOT_FOUND", message: "Or\xE7amento n\xE3o encontrado" });
        const laborCost = rest.laborCost !== void 0 ? rest.laborCost : Number(current.budget.laborCost);
        const materialCost = rest.materialCost !== void 0 ? rest.materialCost : Number(current.budget.materialCost);
        const thirdPartyCost = rest.thirdPartyCost !== void 0 ? rest.thirdPartyCost : Number(current.budget.thirdPartyCost);
        const otherDirectCosts = rest.otherDirectCosts !== void 0 ? rest.otherDirectCosts : Number(current.budget.otherDirectCosts);
        const indirectCostsTotal = rest.indirectCostsTotal !== void 0 ? rest.indirectCostsTotal : Number(current.budget.indirectCostsTotal);
        const profitMargin = rest.profitMargin !== void 0 ? rest.profitMargin : Number(current.budget.profitMargin);
        const totalDirectCosts = laborCost + materialCost + thirdPartyCost + otherDirectCosts;
        const totalCosts = totalDirectCosts + indirectCostsTotal;
        const grossValue = totalCosts / (1 - profitMargin / 100);
        const cbsAmount = grossValue * (Number(taxConfig.cbsRate) / 100);
        const ibsAmount = grossValue * (Number(taxConfig.ibsRate) / 100);
        const totalConsumptionTaxes = cbsAmount + ibsAmount;
        const netRevenue = grossValue - totalConsumptionTaxes;
        const profitBeforeTaxes = netRevenue - totalCosts;
        const irpjAmount = profitBeforeTaxes * (Number(taxConfig.irpjRate) / 100);
        const csllAmount = profitBeforeTaxes * (Number(taxConfig.csllRate) / 100);
        const netProfit = profitBeforeTaxes - irpjAmount - csllAmount;
        const data2 = {
          ...rest,
          totalDirectCosts,
          totalCosts,
          grossValue,
          cbsAmount,
          ibsAmount,
          totalConsumptionTaxes,
          netRevenue,
          profitBeforeTaxes,
          irpjAmount,
          csllAmount,
          netProfit,
          finalPrice: grossValue
        };
        return await updateBudget(id, data2);
      }
      const data = { ...rest };
      if (data.laborCost !== void 0) data.laborCost = data.laborCost.toString();
      if (data.laborHours !== void 0) data.laborHours = data.laborHours.toString();
      if (data.materialCost !== void 0) data.materialCost = data.materialCost.toString();
      if (data.thirdPartyCost !== void 0) data.thirdPartyCost = data.thirdPartyCost.toString();
      if (data.otherDirectCosts !== void 0) data.otherDirectCosts = data.otherDirectCosts.toString();
      if (data.indirectCostsTotal !== void 0) data.indirectCostsTotal = data.indirectCostsTotal.toString();
      if (data.profitMargin !== void 0) data.profitMargin = data.profitMargin.toString();
      return await updateBudget(id, data);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteBudget(input.id);
    }),
    deleteAll: protectedProcedure.mutation(async () => {
      return await deleteAllBudgets();
    }),
    exportPDF: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      const { generateBudgetPDF: generateBudgetPDF2 } = await Promise.resolve().then(() => (init_budgetPDF(), budgetPDF_exports));
      const result = await getBudgetById(input.id);
      if (!result) throw new TRPCError3({ code: "NOT_FOUND", message: "Or\xE7amento n\xE3o encontrado" });
      const budgetItems2 = await getBudgetItems(input.id);
      const items = budgetItems2.map((bi) => ({
        productName: bi.product?.name || bi.item.description,
        description: bi.item.description
      }));
      const pdfBuffer = await generateBudgetPDF2({ ...result, items });
      return {
        pdf: pdfBuffer.toString("base64"),
        filename: `orcamento-${input.id.toString().padStart(6, "0")}.pdf`
      };
    }),
    convertToOrder: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input, ctx }) => {
      return await convertBudgetToOrder(input.id, ctx.user.id);
    }),
    createProject: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input, ctx }) => {
      return await createProjectFromBudget(input.id, ctx.user.id);
    }),
    generatePDFForWhatsApp: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input, ctx }) => {
      const result = await getBudgetById(input.id);
      if (!result) {
        throw new TRPCError3({ code: "NOT_FOUND", message: "Or\xE7amento n\xE3o encontrado" });
      }
      const { generateBudgetPDF: generateBudgetPDF2 } = await Promise.resolve().then(() => (init_budgetPDF(), budgetPDF_exports));
      const pdfBuffer = await generateBudgetPDF2(result);
      const { storagePut: storagePut2 } = await Promise.resolve().then(() => (init_storage(), storage_exports));
      const filename = `orcamento-${result.budget.budgetNumber || input.id}.pdf`;
      const fileKey = `budgets/${ctx.user.id}/${Date.now()}-${filename}`;
      const { url } = await storagePut2(fileKey, pdfBuffer, "application/pdf");
      return {
        url,
        filename,
        customerName: result.budget.customerName || "Cliente",
        budgetNumber: result.budget.budgetNumber || `#${input.id}`,
        customerPhone: result.budget.customerPhone || null
      };
    })
  }),
  budgetTemplates: router({
    list: protectedProcedure.query(async () => {
      return await getBudgetTemplates();
    }),
    getById: protectedProcedure.input(z2.object({ id: z2.number() })).query(async ({ input }) => {
      return await getBudgetTemplateById(input.id);
    }),
    create: protectedProcedure.input(z2.object({
      name: z2.string(),
      description: z2.string().optional(),
      laborCost: z2.number(),
      laborHours: z2.number(),
      materialCost: z2.number(),
      thirdPartyCost: z2.number(),
      otherDirectCosts: z2.number(),
      indirectCostsTotal: z2.number(),
      profitMargin: z2.number()
    })).mutation(async ({ input, ctx }) => {
      return await createBudgetTemplate({
        name: input.name,
        description: input.description,
        laborCost: input.laborCost.toString(),
        laborHours: input.laborHours.toString(),
        materialCost: input.materialCost.toString(),
        thirdPartyCost: input.thirdPartyCost.toString(),
        otherDirectCosts: input.otherDirectCosts.toString(),
        indirectCostsTotal: input.indirectCostsTotal.toString(),
        profitMargin: input.profitMargin.toString(),
        createdBy: ctx.user.id
      });
    }),
    update: protectedProcedure.input(z2.object({
      id: z2.number(),
      name: z2.string().optional(),
      description: z2.string().optional(),
      laborCost: z2.number().optional(),
      laborHours: z2.number().optional(),
      materialCost: z2.number().optional(),
      thirdPartyCost: z2.number().optional(),
      otherDirectCosts: z2.number().optional(),
      indirectCostsTotal: z2.number().optional(),
      profitMargin: z2.number().optional()
    })).mutation(async ({ input }) => {
      const { id, ...rest } = input;
      const data = {};
      if (rest.name !== void 0) data.name = rest.name;
      if (rest.description !== void 0) data.description = rest.description;
      if (rest.laborCost !== void 0) data.laborCost = rest.laborCost.toString();
      if (rest.laborHours !== void 0) data.laborHours = rest.laborHours.toString();
      if (rest.materialCost !== void 0) data.materialCost = rest.materialCost.toString();
      if (rest.thirdPartyCost !== void 0) data.thirdPartyCost = rest.thirdPartyCost.toString();
      if (rest.otherDirectCosts !== void 0) data.otherDirectCosts = rest.otherDirectCosts.toString();
      if (rest.indirectCostsTotal !== void 0) data.indirectCostsTotal = rest.indirectCostsTotal.toString();
      if (rest.profitMargin !== void 0) data.profitMargin = rest.profitMargin.toString();
      return await updateBudgetTemplate(id, data);
    }),
    delete: protectedProcedure.input(z2.object({ id: z2.number() })).mutation(async ({ input }) => {
      return await deleteBudgetTemplate(input.id);
    })
  }),
  taxSettings: publicProcedure.query(async () => {
    return await getTaxSettings();
  }),
  companySettings: router({
    get: publicProcedure.query(async () => {
      return await getCompanySettings();
    }),
    upsert: protectedProcedure.input(z2.object({
      id: z2.number().optional(),
      companyName: z2.string().min(1),
      tradeName: z2.string().optional(),
      logo: z2.string().nullable().optional(),
      cnpj: z2.string().min(1),
      stateRegistration: z2.string().optional(),
      municipalRegistration: z2.string().optional(),
      address: z2.string().optional(),
      neighborhood: z2.string().optional(),
      city: z2.string().optional(),
      state: z2.string().optional(),
      zipCode: z2.string().optional(),
      phone: z2.string().optional(),
      email: z2.string().optional(),
      website: z2.string().optional(),
      ownerName: z2.string().optional(),
      ownerCpf: z2.string().optional(),
      ownerRole: z2.string().optional(),
      ownerNationality: z2.string().optional(),
      ownerMaritalStatus: z2.string().optional(),
      ownerProfession: z2.string().optional(),
      ownerAddress: z2.string().optional()
    })).mutation(async ({ input }) => {
      console.log("companySettings.upsert input:", {
        ...input,
        logo: input.logo ? `[base64 length: ${input.logo.length}]` : "empty/null/undefined"
      });
      const dataToSave = {
        ...input,
        logo: input.logo && input.logo.length > 0 ? input.logo : null
      };
      if (input.id) {
        const { id, ...data } = dataToSave;
        console.log("Updating company settings id:", id, "logo length:", data.logo?.length || 0);
        const result = await updateCompanySettings(id, data);
        console.log("Update result:", result);
        return result;
      } else {
        console.log("Creating new company settings");
        return await createCompanySettings(dataToSave);
      }
    })
  })
});

// server/_core/context.ts
var devUser = {
  id: 1,
  openId: "dev-user-001",
  name: "Desenvolvedor",
  email: "dev@wiisite.com.br",
  loginMethod: "development",
  role: "admin",
  createdAt: /* @__PURE__ */ new Date(),
  updatedAt: /* @__PURE__ */ new Date(),
  lastSignedIn: /* @__PURE__ */ new Date()
};
async function createContext(opts) {
  let user = null;
  const isDev = process.env.NODE_ENV === "development";
  const hasOAuth = Boolean(process.env.OAUTH_SERVER_URL);
  if (isDev && !hasOAuth) {
    user = devUser;
  } else {
    try {
      user = await sdk.authenticateRequest(opts.req);
    } catch (error) {
      user = null;
    }
  }
  return {
    req: opts.req,
    res: opts.res,
    user
  };
}

// server/_core/index.prod.ts
function isPortAvailable(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}
async function findAvailablePort(startPort = 3e3) {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}
function serveStatic(app) {
  const distPath = path.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    console.error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app.use(express.static(distPath));
  app.use("*", (_req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}
async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  const uploadsDir = path.resolve(process.cwd(), "uploads");
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
  }
  app.use("/uploads", express.static(uploadsDir));
  app.post("/api/upload-logo", async (req, res) => {
    try {
      const { logo } = req.body;
      if (!logo || typeof logo !== "string") {
        return res.status(400).json({ error: "Logo \xE9 obrigat\xF3rio" });
      }
      const matches = logo.match(/^data:image\/([a-zA-Z+]+);base64,(.+)$/);
      if (!matches) {
        return res.status(400).json({ error: "Formato de imagem inv\xE1lido" });
      }
      const ext = matches[1] === "svg+xml" ? "svg" : matches[1];
      const base64Data = matches[2];
      const buffer = Buffer.from(base64Data, "base64");
      const filename = `company-logo-${Date.now()}.${ext}`;
      const filepath = path.join(uploadsDir, filename);
      fs.writeFileSync(filepath, buffer);
      const logoUrl = `/uploads/${filename}`;
      console.log("Logo saved:", logoUrl);
      res.json({ logoUrl });
    } catch (error) {
      console.error("Error uploading logo:", error);
      res.status(500).json({ error: "Erro ao fazer upload do logo" });
    }
  });
  registerOAuthRoutes(app);
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext
    })
  );
  serveStatic(app);
  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);
  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }
  server.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}
startServer().catch(console.error);
