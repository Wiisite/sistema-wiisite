import{c as Ce,r as w,t as v,d as D,j as e}from"./index-B8o5CPxc.js";import{D as Te,b as H,c as he,d as Z,e as W,f as Q,F as $,m as X,n as Y,o as K,p as j,q as ee}from"./DashboardLayout-BB9_LpO8.js";import{B as u,C as ae,a as te,b as se,c as oe}from"./card-BLFi8Aig.js";import{L as A,I as f}from"./label-D3aUZo0H.js";import{S as re,a as ne,b as ce,c as ie,d as le}from"./select-DBqi4syx.js";import{T as De,a as Ne,b as z,c as N,d as Ee,e as h}from"./table-jGN1H9qb.js";import{P as Oe,T as k}from"./textarea-CYXB0h_U.js";import{B as ve}from"./badge-ZhgGQ86b.js";import{C as de}from"./circle-alert-D4evwSwQ.js";import{P as je}from"./pen-BnIBIiTW.js";import{T as fe}from"./trash-2-DpixYZH1.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const Re=Ce("FileX",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"m14.5 12.5-5 5",key:"b62r18"}],["path",{d:"m9.5 12.5 5 5",key:"1rk7el"}]]);/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const F=Ce("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]),_e={active:{label:"Ativo",color:"bg-green-500"},suspended:{label:"Suspenso",color:"bg-yellow-500"},cancelled:{label:"Cancelado",color:"bg-red-500"},expired:{label:"Expirado",color:"bg-gray-500"}},pe={maintenance:"Manutenção",hosting:"Hospedagem",support:"Suporte",software_license:"Licença de Software",other:"Outro"},B=(s,c,o)=>{const g=new Date().toLocaleDateString("pt-BR",{day:"2-digit",month:"long",year:"numeric"}),l=o?.companyName||"[RAZÃO SOCIAL DA CONTRATADA]",d=o?.cnpj||"[CNPJ DA CONTRATADA]",C=o?.address||"[ENDEREÇO DA CONTRATADA]",t=o?.neighborhood||"",i=o?.city||"[CIDADE]",_=o?.state||"[UF]",x=o?.zipCode||"[CEP]",O=o?.ownerName||"[NOME DO RESPONSÁVEL]",p=o?.ownerCpf||"[CPF]",R=o?.ownerRole||"Diretor",S=o?.ownerNationality||"brasileiro",q=o?.ownerMaritalStatus||"[ESTADO CIVIL]",y=o?.ownerProfession||"[PROFISSÃO]",L=o?.ownerAddress||"[ENDEREÇO COMPLETO]";return`CONTRATO DE LICENÇA DE USO DE SOFTWARE

CONTRATANTE: ${s?.name||"[RAZÃO SOCIAL DA EMPRESA]"}, com sede em ${s?.address||"[ENDEREÇO]"}${s?.neighborhood?", bairro "+s.neighborhood:""}, CEP ${s?.zipCode||"[CEP]"}, ${s?.city||"[CIDADE]"} - ${s?.state||"[ESTADO]"}, inscrita no CNPJ/CPF sob o nº ${s?.document||"[CNPJ/CPF]"}.

CONTRATADA: ${l}, com sede em ${C}${t?", bairro "+t:""}, CEP ${x}, ${i} - ${_}, inscrita no CNPJ sob o nº: ${d}, neste ato representada pelo seu ${R} ${O}, ${S}, ${q}, ${y}, CPF nº: ${p}, residente e domiciliado em ${L}.

As partes acima identificadas têm, entre si, justo e acertado o presente Contrato de Licença de Uso e Prestação de Serviços de Software, que se regerá pelas cláusulas seguintes e pelas condições descritas no presente.

DO OBJETO DO CONTRATO

Cláusula 1°: O presente instrumento tem como objeto a licença de uso do Software de gestão e gerenciamento ERP, de propriedade da CONTRATADA, o qual é capaz de controlar todas as informações da empresa contratante, integrando dados, recursos e processos, das áreas de vendas, finanças, contabilidade, fiscal, estoque, compras, produção e logística.

DA LICENÇA DE USO DO SOFTWARE

Cláusula 2°: A licença de uso concedida por meio deste Contrato dá à CONTRATANTE o direito não exclusivo e intransferível de usar o Software unicamente para processamento de seus dados, conforme condições aqui descritas.

Parágrafo único: Somente poderá ter acesso ao sistema a CONTRATANTE, seus funcionários e o contador da empresa contratante. Nenhuma outra pessoa poderá ter acesso ao sistema.

DA LIMITAÇÃO DE RESPONSABILIDADE

Cláusula 3°: O acesso ao Software é totalmente web e realizado através de navegadores de internet. A CONTRATADA não é responsável por disponibilizar internet para uso dos sistemas;

Cláusula 4°: As informações inseridas no sistema são de total responsabilidade da CONTRATANTE;

Cláusula 5°: A CONTRATANTE pode solicitar a migração das informações do sistema atual utilizado para o sistema contratado e cabe a CONTRATANTE a conferência das informações depois de inseridas no sistema;

Cláusula 6°: Todas as informações fiscais dos produtos para emissão de notas são de responsabilidade da CONTRATANTE e ela deverá pedir auxílio do seu contador no ato do cadastro. A CONTRATANTE é responsável por enviar todas as informações que o contador solicitar, caso precise de ajuda poderá solicitar ao suporte;

Cláusula 7°: O controle de acesso dos funcionários da empresa aos módulos do sistema recai sobre a CONTRATANTE, por sua vez, caso necessite de ajuda, poderá recorrer ao suporte da CONTRATADA para auxiliar na tarefa;

Cláusula 8°: A CONTRATADA não é responsável pelo estado da máquina, ou seja, não é responsável por formatar ou configurar o computador. Em regra, não haverá necessidade, pois o sistema é totalmente WEB e não precisa ser instalado na máquina;

Cláusula 9°: A CONTRATADA não tem responsabilidade pelas informações fiscais, somente disponibiliza o emissor de notas para o cliente usar;

Cláusula 10°: A CONTRATADA não fornece os componentes periféricos para uso na empresa (Mouse, teclado, impressora, leitor de código de barras) a compra desses equipamentos é de responsabilidade do cliente CONTRATANTE do software;

Cláusula 11°: A CONTRATADA não faz e nem é responsável por cadastrar as informações de uso do sistema (produtos, clientes, caixas, contas a pagar, contas a receber);

Cláusula 12°: A CONTRATADA não é responsável por emissão ou atualização do certificado digital, nem geração do CSC para emissão de notas. (Essas ações devem ser feitas com o contador da CONTRATANTE).

DA ATUALIZAÇÃO OU MANUTENÇÃO DO SOFTWARE

Cláusula 13°: O backup do banco de dados é feito 1x por semana e é de responsabilidade da CONTRATADA, caso o cliente solicite que sejam feitas alterações nos dados por meio de backup, então deverá ser solicitado e planejado a restauração dos dados;

Cláusula 14°: O suporte acontecerá através do AnyDesk ou Teamviewer (softwares de conexão remota) caso não seja resolvido pelos programas de conexão remota então será enviado um técnico na empresa da CONTRATANTE. O técnico será enviado de acordo com a disponibilidade.

DAS OBRIGAÇÕES DA CONTRATADA

Cláusula 15°: Fornecer o software ora cedido na forma e modo ajustados;

Cláusula 16°: Auxiliar a CONTRATANTE na solução de quaisquer dúvidas existentes a respeito do software;

Cláusula 17°: Ser responsável pelos atos praticados por seus funcionários, bem como pelos danos que os mesmos venham causar para a CONTRATANTE, em decorrência de eventuais prestações de serviços necessários ao uso do software objeto deste contrato;

Cláusula 18°: Corrigir qualquer erro ou defeito relatado pelo CONTRATANTE que seja referente ao software ora cedido.

DAS OBRIGAÇÕES DA CONTRATANTE

Cláusula 19°: Auxiliar e cooperar com a CONTRATADA, quando se fizer necessário, na análise e solução de erros, caso existentes, no software cedido;

Cláusula 20°: Fornecer à CONTRATADA, quando solicitado, todos os dados, e informações relevantes, para viabilizar e facilitar a prestação dos serviços de manutenção, atualização e, caso necessário, suporte técnico.

DO PAGAMENTO

Cláusula 21°: Pela prestação dos serviços de Software, a CONTRATANTE pagará à CONTRATADA a quantia mensal de R$ ${c.monthlyValue||"0,00"} (${c.monthlyValue?"valor por extenso":"zero reais"}), até o dia 10 de cada mês, sendo cobrada a primeira parcela quando o sistema estiver pronto para uso e for apresentado na empresa.

Parágrafo único: Decorridos 12 (doze) meses de execução deste Contrato, os preços serão reajustados pelo Índice de Preços ao Consumidor Amplo - IPCA.

DO INADIMPLEMENTO E DA MULTA

Cláusula 22°: Em caso de inadimplemento por parte da CONTRATANTE quanto ao pagamento do serviço prestado, do atraso deverá incidir multa diária 1% (um por cento) sobre o valor do preço mensal ajustado acrescido de juros de 1% (um por cento) e correção monetária.

DA RESCISÃO E VIGÊNCIA

Cláusula 23°: A vigência deste contrato é por prazo indeterminado a contar de sua assinatura, no entanto, poderá o presente instrumento ser rescindido por qualquer uma das partes, em qualquer momento, sem que haja qualquer tipo de motivo relevante, não obstante, a outra parte deverá ser avisada previamente por escrito, no prazo mínimo de 30 (trinta) dias do encerramento da atividade. Podendo ser rescindido em comum acordo a qualquer tempo;

Cláusula 24°: A CONTRATADA poderá rescindir o presente contrato, independentemente de qualquer notificação na hipótese de inadimplência reiterada de qualquer cláusula ou condição do presente contrato e demais casos previstos na legislação em vigor;

Cláusula 25°: Caso a CONTRATANTE rescinda o contrato, sem justo motivo, e sem respeito ao prazo mínimo determinado na cláusula 23°, deverá arcar com o valor equivalente a uma parcela deste contrato, a qual não se confunde com os valores devidos pelo uso do software;

Cláusula 26°: Nenhuma das partes será responsável perante a outra por qualquer falha ou atraso no cumprimento das obrigações constantes do presente contrato, causados por caso fortuito ou força maior.

DA PROTEÇÃO DE DADOS

Cláusula 27°: A CONTRATADA, por si e por seus colaboradores, obriga-se a atuar no presente Contrato em conformidade com a Legislação vigente sobre Proteção de Dados Pessoais e as determinações de órgãos reguladores/fiscalizadores sobre a matéria, em especial a Lei 13.709/2018.

DO USO DA IMAGEM

Cláusula 28°: A CONTRATANTE autoriza a CONTRATADA a fazer uso de sua imagem, de seus funcionários e ambiente de trabalho, em fotos e/ou filmes, sem finalidade comercial, para serem usadas nos meios de comunicação que entender pertinentes, para divulgação dos serviços prestados pela CONTRATADA, bem como para a divulgação de promoções e sorteios.

FORO

Cláusula 29°: Para dirimir as controvérsias oriundas desse contrato de prestação de serviços, as partes elegem o foro da comarca de [CIDADE]-[UF].

CONDIÇÕES GERAIS

Cláusula 30°: Fica compactuado entre as partes a total inexistência de vínculo trabalhista, excluindo as obrigações previdenciárias e os encargos sociais, não havendo entre CONTRATADA e CONTRATANTE qualquer tipo de relação de subordinação;

Cláusula 31°: Salvo com a expressa autorização da CONTRATADA, não pode a CONTRATANTE transferir ou subcontratar os serviços previstos neste instrumento, sob o risco de ocorrer a rescisão imediata;

Cláusula 32°: A CONTRATADA não disponibiliza de nenhuma forma os códigos fontes do sistema, esses não podem ser exigidos ou solicitados;

Cláusula 33°: E por estarem assim justas e acertadas, as partes firmam o presente instrumento em 2 (duas) vias de igual teor e forma, assinadas e rubricadas, tudo na presença das duas testemunhas abaixo.

${i}, ${g}


__________________________________________________
CONTRATANTE
${s?.name||"[RAZÃO SOCIAL DA EMPRESA CONTRATANTE]"}


__________________________________________________
CONTRATADA
${l}
CNPJ: ${d}


__________________________________________
TESTEMUNHA 1
Nome:
CPF:


__________________________________________
TESTEMUNHA 2
Nome:
CPF:
`},me=(s,c,o)=>{const g=new Date().toLocaleDateString("pt-BR",{day:"2-digit",month:"long",year:"numeric"}),l=c.totalInstallments||12,d=c.paidInstallments||0,C=l-d,t=parseFloat(c.monthlyValue?.replace(",",".")||"0"),i=(C*t).toFixed(2).replace(".",","),_=o?.companyName||"[RAZÃO SOCIAL DA EMPRESA]",x=o?.cnpj||"[CNPJ DA EMPRESA]",O=`${o?.address||"[ENDEREÇO]"}${o?.neighborhood?", "+o.neighborhood:""}, ${o?.city||"[CIDADE]"} - ${o?.state||"[UF]"}, CEP: ${o?.zipCode||"[CEP]"}`;return`TERMO DE RESCISÃO ANTECIPADA DE CONTRATO DE PRESTAÇÃO DE SERVIÇOS

CONTRATANTE: ${s?.name||"[NOME/RAZÃO SOCIAL DO CONTRATANTE]"}
CPF/CNPJ: ${s?.document||"[CPF/CNPJ]"}
Endereço: ${s?.address||"[ENDEREÇO]"}${s?.neighborhood?", "+s.neighborhood:""}, ${s?.city||"[CIDADE]"} - ${s?.state||"[UF]"}, CEP: ${s?.zipCode||"[CEP]"}
E-mail: ${s?.email||"[E-MAIL]"}
Telefone: ${s?.phone||"[TELEFONE]"}

CONTRATADA: ${_}
CNPJ: ${x}
Endereço: ${O}

REFERÊNCIA: Contrato de Prestação de Serviços firmado em ${c.startDate?new Date(c.startDate).toLocaleDateString("pt-BR"):"[DATA DO CONTRATO ORIGINAL]"}

═══════════════════════════════════════════════════════════════════════════════

1. DO OBJETO

1.1. O presente Termo tem por objeto formalizar a RESCISÃO ANTECIPADA do Contrato de Prestação de Serviços celebrado entre as partes acima qualificadas, conforme condições estabelecidas neste instrumento.

═══════════════════════════════════════════════════════════════════════════════

2. DA SITUAÇÃO FINANCEIRA

2.1. Valor mensal do contrato: R$ ${c.monthlyValue||"0,00"}
2.2. Total de parcelas contratadas: ${l} parcelas
2.3. Parcelas já pagas: ${d} parcelas
2.4. Parcelas restantes: ${C} parcelas
2.5. Valor total restante: R$ ${i}

═══════════════════════════════════════════════════════════════════════════════

3. DAS CONDIÇÕES DE RESCISÃO

3.1. A CONTRATANTE solicita a rescisão antecipada do contrato, estando ciente das seguintes condições:

   a) MULTA POR RESCISÃO ANTECIPADA: Conforme cláusula contratual, a rescisão antecipada sem justo motivo implica no pagamento de multa equivalente a 20% (vinte por cento) do valor restante do contrato.

   b) VALOR DA MULTA: R$ ${(parseFloat(i.replace(",","."))*.2).toFixed(2).replace(".",",")}

   c) VALOR TOTAL A PAGAR: R$ ${(parseFloat(i.replace(",","."))*.2).toFixed(2).replace(".",",")} (multa rescisória)

3.2. A CONTRATANTE declara estar ciente de que:
   - Todos os serviços serão encerrados na data de assinatura deste termo;
   - O acesso aos sistemas será suspenso após a quitação dos valores devidos;
   - Não haverá devolução de valores já pagos referentes a serviços prestados.

═══════════════════════════════════════════════════════════════════════════════

4. DA FORMA DE PAGAMENTO DA MULTA

4.1. O valor da multa rescisória deverá ser pago da seguinte forma:

[ ] À vista, no ato da assinatura deste termo
[ ] Parcelado em _____ vezes de R$ _________
[ ] Outra forma: _________________________________

4.2. O não pagamento dos valores acordados implicará em:
   - Inclusão do nome nos órgãos de proteção ao crédito;
   - Cobrança judicial com acréscimo de custas processuais e honorários advocatícios de 20%.

═══════════════════════════════════════════════════════════════════════════════

5. DA QUITAÇÃO

5.1. Mediante o cumprimento integral das obrigações aqui estabelecidas, as partes darão mútua e recíproca quitação, nada mais tendo a reclamar uma da outra, seja a que título for, em relação ao contrato ora rescindido.

5.2. A quitação final será formalizada mediante recibo específico após a confirmação do pagamento integral.

═══════════════════════════════════════════════════════════════════════════════

6. DAS DISPOSIÇÕES FINAIS

6.1. Este termo entra em vigor na data de sua assinatura.

6.2. As partes elegem o foro da Comarca de [CIDADE]-[UF] para dirimir quaisquer controvérsias oriundas deste instrumento.

6.3. E por estarem assim justas e acordadas, as partes assinam o presente termo em 2 (duas) vias de igual teor e forma.

${s?.city||"[CIDADE]"}, ${g}


_______________________________________________
CONTRATANTE
${s?.name||"[NOME DO CONTRATANTE]"}
CPF/CNPJ: ${s?.document||"[CPF/CNPJ]"}


_______________________________________________
CONTRATADA
${_}
CNPJ: ${x}


_______________________________________________
TESTEMUNHA 1
Nome:
CPF:


_______________________________________________
TESTEMUNHA 2
Nome:
CPF:
`},ue=(s,c,o)=>{const g=new Date().toLocaleDateString("pt-BR",{day:"2-digit",month:"long",year:"numeric"}),l=c.totalInstallments||12,d=parseFloat(c.monthlyValue?.replace(",",".")||"0"),C=(l*d).toFixed(2).replace(".",","),t=o?.companyName||"[RAZÃO SOCIAL DA EMPRESA]",i=o?.cnpj||"[CNPJ DA EMPRESA]",_=`${o?.address||"[ENDEREÇO]"}${o?.neighborhood?", "+o.neighborhood:""}, ${o?.city||"[CIDADE]"} - ${o?.state||"[UF]"}, CEP: ${o?.zipCode||"[CEP]"}`,x=o?.city||"[CIDADE]";return o?.state,`CONTRATO DE PRESTAÇÃO DE SERVIÇOS

CONTRATANTE: ${s?.name||"[NOME/RAZÃO SOCIAL DO CONTRATANTE]"}
CPF/CNPJ: ${s?.document||"[CPF/CNPJ]"}
Endereço: ${s?.address||"[ENDEREÇO]"}${s?.neighborhood?", "+s.neighborhood:""}, ${s?.city||"[CIDADE]"} - ${s?.state||"[UF]"}, CEP: ${s?.zipCode||"[CEP]"}
E-mail: ${s?.email||"[E-MAIL]"}
Telefone: ${s?.phone||"[TELEFONE]"}

CONTRATADA: ${t}
CNPJ: ${i}
Endereço: ${_}

As partes acima qualificadas têm entre si justo e acordado o presente CONTRATO DE PRESTAÇÃO DE SERVIÇOS, que se regerá pelas cláusulas e condições a seguir:

═══════════════════════════════════════════════════════════════════════════════

CLÁUSULA 1ª - DO OBJETO

1.1. O presente contrato tem por objeto a prestação dos seguintes serviços pela CONTRATADA à CONTRATANTE:

${c.serviceDescription||"[DESCRIÇÃO DETALHADA DOS SERVIÇOS A SEREM PRESTADOS]"}

═══════════════════════════════════════════════════════════════════════════════

CLÁUSULA 2ª - DO PRAZO

2.1. O presente contrato terá vigência de ${l} meses, iniciando-se em ${c.startDate?new Date(c.startDate).toLocaleDateString("pt-BR"):"[DATA DE INÍCIO]"} e encerrando-se em ${c.endDate?new Date(c.endDate).toLocaleDateString("pt-BR"):"[DATA DE TÉRMINO]"}.

2.2. O contrato poderá ser renovado mediante acordo entre as partes, formalizado por escrito.

═══════════════════════════════════════════════════════════════════════════════

CLÁUSULA 3ª - DO VALOR E FORMA DE PAGAMENTO

3.1. Pela prestação dos serviços objeto deste contrato, a CONTRATANTE pagará à CONTRATADA:

   • Valor Total: R$ ${C}
   • Número de Parcelas: ${l}
   • Valor de Cada Parcela: R$ ${c.monthlyValue||"0,00"}
   • Vencimento: Todo dia 10 de cada mês

3.2. O pagamento deverá ser efetuado mediante:
   [ ] Boleto bancário
   [ ] Transferência bancária (PIX/TED)
   [ ] Cartão de crédito
   [ ] Outra forma: _________________

3.3. Em caso de atraso no pagamento, incidirá:
   • Multa de 2% (dois por cento) sobre o valor da parcela;
   • Juros de mora de 1% (um por cento) ao mês;
   • Correção monetária pelo IPCA.

═══════════════════════════════════════════════════════════════════════════════

CLÁUSULA 4ª - DAS OBRIGAÇÕES DA CONTRATADA

4.1. Prestar os serviços com qualidade e dentro dos prazos acordados;
4.2. Manter sigilo sobre as informações da CONTRATANTE;
4.3. Comunicar imediatamente qualquer impedimento na execução dos serviços;
4.4. Fornecer suporte técnico durante a vigência do contrato.

═══════════════════════════════════════════════════════════════════════════════

CLÁUSULA 5ª - DAS OBRIGAÇÕES DA CONTRATANTE

5.1. Efetuar os pagamentos nas datas acordadas;
5.2. Fornecer as informações necessárias para a execução dos serviços;
5.3. Comunicar à CONTRATADA qualquer irregularidade observada;
5.4. Não ceder ou transferir este contrato a terceiros sem autorização.

═══════════════════════════════════════════════════════════════════════════════

CLÁUSULA 6ª - DA RESCISÃO

6.1. O presente contrato poderá ser rescindido:
   a) Por mútuo acordo entre as partes;
   b) Por inadimplemento de qualquer das cláusulas contratuais;
   c) Por solicitação de qualquer das partes, mediante aviso prévio de 30 dias.

6.2. Em caso de rescisão antecipada por iniciativa da CONTRATANTE, sem justo motivo, será devida multa de 20% (vinte por cento) sobre o valor restante do contrato.

6.3. Em caso de rescisão por inadimplemento da CONTRATANTE, além da multa prevista, serão devidos todos os valores em aberto, acrescidos de juros e correção.

═══════════════════════════════════════════════════════════════════════════════

CLÁUSULA 7ª - DO FORO

7.1. As partes elegem o foro da Comarca de [CIDADE]-[UF] para dirimir quaisquer dúvidas ou controvérsias oriundas deste contrato, renunciando a qualquer outro, por mais privilegiado que seja.

═══════════════════════════════════════════════════════════════════════════════

E por estarem assim justas e contratadas, as partes assinam o presente instrumento em 2 (duas) vias de igual teor e forma, na presença das testemunhas abaixo.

${x}, ${g}


_______________________________________________
CONTRATANTE
${s?.name||"[NOME DO CONTRATANTE]"}
CPF/CNPJ: ${s?.document||"[CPF/CNPJ]"}


_______________________________________________
CONTRATADA
${t}
CNPJ: ${i}


_______________________________________________
TESTEMUNHA 1
Nome:
CPF:


_______________________________________________
TESTEMUNHA 2
Nome:
CPF:
`};function Ve(){const[s,c]=w.useState(!1),[o,E]=w.useState(!1),[g,l]=w.useState(""),[d,C]=w.useState(null),[t,i]=w.useState({customerId:"",title:"",description:"",contractType:"maintenance",monthlyValue:"",startDate:"",endDate:"",renewalDate:"",billingDay:"1",notes:""}),{data:_,refetch:x}=v.contracts.list.useQuery(),{data:O}=v.customers.list.useQuery(),{data:p}=v.companySettings.get.useQuery(),R=v.contracts.create.useMutation({onSuccess:()=>{D.success("Contrato criado com sucesso!"),c(!1),x(),i({customerId:"",title:"",description:"",contractType:"maintenance",monthlyValue:"",startDate:"",endDate:"",renewalDate:"",billingDay:"1",notes:""})},onError:a=>{D.error("Erro ao criar contrato: "+a.message)}}),S=v.contracts.update.useMutation({onSuccess:()=>{D.success("Contrato atualizado com sucesso!"),c(!1),C(null),x(),y()},onError:a=>{D.error("Erro ao atualizar contrato: "+a.message)}}),q=v.contracts.delete.useMutation({onSuccess:()=>{D.success("Contrato excluído com sucesso!"),x()},onError:a=>{D.error("Erro ao excluir contrato: "+a.message)}}),y=()=>{i({customerId:"",title:"",description:"",contractType:"maintenance",monthlyValue:"",startDate:"",endDate:"",renewalDate:"",billingDay:"1",notes:""})},L=a=>{const r=a.contract;C(r),i({customerId:r.customerId?.toString()||"",title:r.title||"",description:r.description||"",contractType:r.contractType||"maintenance",monthlyValue:r.monthlyValue||"",startDate:r.startDate?new Date(r.startDate).toISOString().split("T")[0]:"",endDate:r.endDate?new Date(r.endDate).toISOString().split("T")[0]:"",renewalDate:r.renewalDate?new Date(r.renewalDate).toISOString().split("T")[0]:"",billingDay:r.billingDay?.toString()||"1",notes:r.notes||""}),c(!0)},xe=a=>{confirm("Tem certeza que deseja excluir este contrato?")&&q.mutate({id:a})},M=(a,r)=>{const n=a.contract,m=a.customer;let T="",b="";switch(r){case"license":T=B(m,{monthlyValue:n.monthlyValue,startDate:n.startDate},p),b="CONTRATO DE LICENÇA DE USO DE SOFTWARE";break;case"service":T=ue(m,{monthlyValue:n.monthlyValue,startDate:n.startDate,endDate:n.endDate,totalInstallments:12,serviceDescription:n.description},p),b="CONTRATO DE PRESTAÇÃO DE SERVIÇOS";break;case"termination":T=me(m,{monthlyValue:n.monthlyValue,startDate:n.startDate,totalInstallments:12,paidInstallments:0},p),b="TERMO DE RESCISÃO ANTECIPADA";break}const P=window.open("","_blank");if(P){const ge=p?.logo?`<img src="${p.logo}" alt="Logo" style="max-height: 60px; max-width: 200px; object-fit: contain;" />`:"",G=p?.tradeName||p?.companyName||"";P.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>${b} - ${n.title}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 40px; line-height: 1.6; }
            .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
            .header-logo { margin-bottom: 15px; }
            .header h1 { margin: 0; font-size: 24px; }
            .header h2 { margin: 5px 0 15px 0; font-size: 16px; color: #444; font-weight: normal; }
            .header p { margin: 5px 0; color: #666; }
            .contract-content { white-space: pre-wrap; }
            @media print { body { padding: 20px; } }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="header-logo">${ge}</div>
            ${G?`<h2>${G}</h2>`:""}
            <h1>${b}</h1>
            <p>Contrato: ${n.title}</p>
            <p>Cliente: ${m?.name||"-"}</p>
            <p>Valor Mensal: R$ ${parseFloat(n.monthlyValue||"0").toLocaleString("pt-BR",{minimumFractionDigits:2})}</p>
          </div>
          <div class="contract-content">${T}</div>
        </body>
        </html>
      `),P.document.close(),P.print()}},V=(a,r)=>{const n=a.contract,m=a.customer;let T="";switch(r){case"license":T=B(m,{monthlyValue:n.monthlyValue,startDate:n.startDate},p);break;case"service":T=ue(m,{monthlyValue:n.monthlyValue,startDate:n.startDate,endDate:n.endDate,totalInstallments:12,serviceDescription:n.description},p);break;case"termination":T=me(m,{monthlyValue:n.monthlyValue,startDate:n.startDate,totalInstallments:12,paidInstallments:0},p);break}l(T),E(!0)},Ae=a=>{a.preventDefault();const r={customerId:parseInt(t.customerId),title:t.title,description:t.description,contractType:t.contractType,monthlyValue:t.monthlyValue,startDate:new Date(t.startDate),endDate:t.endDate?new Date(t.endDate):void 0,renewalDate:t.renewalDate?new Date(t.renewalDate):void 0,billingDay:parseInt(t.billingDay),notes:t.notes};d?S.mutate({id:d.id,data:r}):R.mutate(r)},J=a=>a?`R$ ${parseFloat(a).toLocaleString("pt-BR",{minimumFractionDigits:2})}`:"R$ 0,00",I=a=>a?new Date(a).toLocaleDateString("pt-BR"):"-",U=a=>{if(!a)return!1;const r=new Date(a),n=new Date,m=Math.ceil((r.getTime()-n.getTime())/(1e3*60*60*24));return m<=30&&m>=0};return e.jsx(Te,{"data-loc":"client\\src\\pages\\Contracts.tsx:755",children:e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:756",className:"space-y-6",children:[e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:757",className:"flex items-center justify-between",children:[e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:758",children:[e.jsx("h1",{"data-loc":"client\\src\\pages\\Contracts.tsx:759",className:"text-3xl font-bold",children:"Contratos"}),e.jsx("p",{"data-loc":"client\\src\\pages\\Contracts.tsx:760",className:"text-muted-foreground",children:"Gerencie contratos recorrentes e renovações"})]}),e.jsxs(H,{"data-loc":"client\\src\\pages\\Contracts.tsx:764",open:s,onOpenChange:a=>{c(a),a||(C(null),y())},children:[e.jsx(he,{"data-loc":"client\\src\\pages\\Contracts.tsx:765",asChild:!0,children:e.jsxs(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:766",children:[e.jsx(Oe,{"data-loc":"client\\src\\pages\\Contracts.tsx:767",className:"mr-2 h-4 w-4"}),"Novo Contrato"]})}),e.jsxs(Z,{"data-loc":"client\\src\\pages\\Contracts.tsx:771",className:"max-w-2xl max-h-[90vh] overflow-y-auto",children:[e.jsx(W,{"data-loc":"client\\src\\pages\\Contracts.tsx:772",children:e.jsx(Q,{"data-loc":"client\\src\\pages\\Contracts.tsx:773",children:d?"Editar Contrato":"Criar Novo Contrato"})}),e.jsxs("form",{"data-loc":"client\\src\\pages\\Contracts.tsx:775",onSubmit:Ae,className:"space-y-4",children:[e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:776",className:"grid grid-cols-2 gap-4",children:[e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:777",className:"col-span-2",children:[e.jsx(A,{"data-loc":"client\\src\\pages\\Contracts.tsx:778",htmlFor:"customerId",children:"Cliente *"}),e.jsxs(re,{"data-loc":"client\\src\\pages\\Contracts.tsx:779",value:t.customerId,onValueChange:a=>i({...t,customerId:a}),required:!0,children:[e.jsx(ne,{"data-loc":"client\\src\\pages\\Contracts.tsx:786",children:e.jsx(ce,{"data-loc":"client\\src\\pages\\Contracts.tsx:787",placeholder:"Selecione um cliente"})}),e.jsx(ie,{"data-loc":"client\\src\\pages\\Contracts.tsx:789",children:O?.map(a=>e.jsx(le,{"data-loc":"client\\src\\pages\\Contracts.tsx:791",value:a.id.toString(),children:a.name},a.id))})]})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:798",className:"col-span-2",children:[e.jsx(A,{"data-loc":"client\\src\\pages\\Contracts.tsx:799",htmlFor:"title",children:"Título do Contrato *"}),e.jsx(f,{"data-loc":"client\\src\\pages\\Contracts.tsx:800",id:"title",value:t.title,onChange:a=>i({...t,title:a.target.value}),required:!0})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:809",children:[e.jsx(A,{"data-loc":"client\\src\\pages\\Contracts.tsx:810",htmlFor:"contractType",children:"Tipo *"}),e.jsxs(re,{"data-loc":"client\\src\\pages\\Contracts.tsx:811",value:t.contractType,onValueChange:a=>i({...t,contractType:a}),children:[e.jsx(ne,{"data-loc":"client\\src\\pages\\Contracts.tsx:817",children:e.jsx(ce,{"data-loc":"client\\src\\pages\\Contracts.tsx:818"})}),e.jsx(ie,{"data-loc":"client\\src\\pages\\Contracts.tsx:820",children:Object.entries(pe).map(([a,r])=>e.jsx(le,{"data-loc":"client\\src\\pages\\Contracts.tsx:822",value:a,children:r},a))})]})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:829",children:[e.jsx(A,{"data-loc":"client\\src\\pages\\Contracts.tsx:830",htmlFor:"monthlyValue",children:"Valor Mensal *"}),e.jsx(f,{"data-loc":"client\\src\\pages\\Contracts.tsx:831",id:"monthlyValue",type:"number",step:"0.01",value:t.monthlyValue,onChange:a=>i({...t,monthlyValue:a.target.value}),required:!0})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:842",children:[e.jsx(A,{"data-loc":"client\\src\\pages\\Contracts.tsx:843",htmlFor:"startDate",children:"Data de Início *"}),e.jsx(f,{"data-loc":"client\\src\\pages\\Contracts.tsx:844",id:"startDate",type:"date",value:t.startDate,onChange:a=>i({...t,startDate:a.target.value}),required:!0})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:854",children:[e.jsx(A,{"data-loc":"client\\src\\pages\\Contracts.tsx:855",htmlFor:"endDate",children:"Data de Término"}),e.jsx(f,{"data-loc":"client\\src\\pages\\Contracts.tsx:856",id:"endDate",type:"date",value:t.endDate,onChange:a=>i({...t,endDate:a.target.value})})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:865",children:[e.jsx(A,{"data-loc":"client\\src\\pages\\Contracts.tsx:866",htmlFor:"renewalDate",children:"Data de Renovação"}),e.jsx(f,{"data-loc":"client\\src\\pages\\Contracts.tsx:867",id:"renewalDate",type:"date",value:t.renewalDate,onChange:a=>i({...t,renewalDate:a.target.value})})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:876",children:[e.jsx(A,{"data-loc":"client\\src\\pages\\Contracts.tsx:877",htmlFor:"billingDay",children:"Dia de Cobrança"}),e.jsx(f,{"data-loc":"client\\src\\pages\\Contracts.tsx:878",id:"billingDay",type:"number",min:"1",max:"31",value:t.billingDay,onChange:a=>i({...t,billingDay:a.target.value})})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:889",className:"col-span-2",children:[e.jsx(A,{"data-loc":"client\\src\\pages\\Contracts.tsx:890",htmlFor:"description",children:"Descrição"}),e.jsx(k,{"data-loc":"client\\src\\pages\\Contracts.tsx:891",id:"description",value:t.description,onChange:a=>i({...t,description:a.target.value}),rows:3})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:900",className:"col-span-2",children:[e.jsx(A,{"data-loc":"client\\src\\pages\\Contracts.tsx:901",htmlFor:"notes",children:"Observações"}),e.jsx(k,{"data-loc":"client\\src\\pages\\Contracts.tsx:902",id:"notes",value:t.notes,onChange:a=>i({...t,notes:a.target.value}),rows:2})]})]}),t.contractType==="software_license"&&t.customerId&&e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:915",className:"col-span-2 p-3 bg-blue-50 rounded-lg border border-blue-200",children:[e.jsx("p",{"data-loc":"client\\src\\pages\\Contracts.tsx:916",className:"text-sm text-blue-700 mb-2",children:"Tipo de contrato: Licença de Software. Você pode gerar o template do contrato automaticamente."}),e.jsxs(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:919",type:"button",variant:"outline",className:"w-full",onClick:()=>{const a=O?.find(n=>n.id.toString()===t.customerId),r=B(a,{monthlyValue:t.monthlyValue,startDate:t.startDate},p);l(r),E(!0)},children:[e.jsx($,{"data-loc":"client\\src\\pages\\Contracts.tsx:933",className:"h-4 w-4 mr-2"}),"Gerar Template do Contrato"]})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:939",className:"flex justify-end gap-2",children:[e.jsx(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:940",type:"button",variant:"outline",onClick:()=>c(!1),children:"Cancelar"}),e.jsx(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:947",type:"submit",disabled:R.isPending||S.isPending,children:R.isPending||S.isPending?d?"Salvando...":"Criando...":d?"Salvar Alterações":"Criar Contrato"})]})]})]})]}),e.jsx(H,{"data-loc":"client\\src\\pages\\Contracts.tsx:958",open:o,onOpenChange:E,children:e.jsxs(Z,{"data-loc":"client\\src\\pages\\Contracts.tsx:959",className:"max-w-4xl max-h-[90vh] overflow-y-auto",children:[e.jsx(W,{"data-loc":"client\\src\\pages\\Contracts.tsx:960",children:e.jsx(Q,{"data-loc":"client\\src\\pages\\Contracts.tsx:961",children:"Contrato de Licença de Software"})}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:963",className:"space-y-4",children:[e.jsx(k,{"data-loc":"client\\src\\pages\\Contracts.tsx:964",value:g,onChange:a=>l(a.target.value),rows:30,className:"font-mono text-sm"}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:970",className:"flex justify-end gap-2",children:[e.jsx(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:971",variant:"outline",onClick:()=>{navigator.clipboard.writeText(g),D.success("Contrato copiado para a área de transferência!")},children:"Copiar"}),e.jsx(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:980",variant:"outline",onClick:()=>{const a=new Blob([g],{type:"text/plain"}),r=URL.createObjectURL(a),n=document.createElement("a");n.href=r,n.download="contrato-licenca-software.txt",n.click(),URL.revokeObjectURL(r),D.success("Contrato baixado!")},children:"Baixar TXT"}),e.jsx(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:995",onClick:()=>E(!1),children:"Fechar"})]})]})]})})]}),_&&_.filter(a=>U(a.contract.renewalDate)).length>0&&e.jsxs(ae,{"data-loc":"client\\src\\pages\\Contracts.tsx:1006",className:"border-yellow-500 bg-yellow-50",children:[e.jsx(te,{"data-loc":"client\\src\\pages\\Contracts.tsx:1007",children:e.jsxs(se,{"data-loc":"client\\src\\pages\\Contracts.tsx:1008",className:"text-sm flex items-center gap-2 text-yellow-700",children:[e.jsx(de,{"data-loc":"client\\src\\pages\\Contracts.tsx:1009",className:"h-4 w-4"}),"Contratos com Renovação Próxima (30 dias)"]})}),e.jsx(oe,{"data-loc":"client\\src\\pages\\Contracts.tsx:1013",children:e.jsx("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:1014",className:"space-y-2",children:_?.filter(a=>U(a.contract.renewalDate)).map(a=>e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:1018",className:"flex items-center justify-between p-2 bg-white rounded",children:[e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:1022",children:[e.jsx("p",{"data-loc":"client\\src\\pages\\Contracts.tsx:1023",className:"font-medium",children:a.contract.title}),e.jsx("p",{"data-loc":"client\\src\\pages\\Contracts.tsx:1024",className:"text-sm text-muted-foreground",children:a.customer?.name})]}),e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:1028",className:"text-right",children:[e.jsxs("p",{"data-loc":"client\\src\\pages\\Contracts.tsx:1029",className:"text-sm font-medium",children:["Renovação: ",I(a.contract.renewalDate)]}),e.jsxs("p",{"data-loc":"client\\src\\pages\\Contracts.tsx:1032",className:"text-sm text-muted-foreground",children:[J(a.contract.monthlyValue),"/mês"]})]})]},a.contract.id))})})]}),e.jsxs(ae,{"data-loc":"client\\src\\pages\\Contracts.tsx:1044",children:[e.jsx(te,{"data-loc":"client\\src\\pages\\Contracts.tsx:1045",children:e.jsx(se,{"data-loc":"client\\src\\pages\\Contracts.tsx:1046",children:"Todos os Contratos"})}),e.jsx(oe,{"data-loc":"client\\src\\pages\\Contracts.tsx:1048",children:e.jsxs(De,{"data-loc":"client\\src\\pages\\Contracts.tsx:1049",children:[e.jsx(Ne,{"data-loc":"client\\src\\pages\\Contracts.tsx:1050",children:e.jsxs(z,{"data-loc":"client\\src\\pages\\Contracts.tsx:1051",children:[e.jsx(N,{"data-loc":"client\\src\\pages\\Contracts.tsx:1052",children:"Cliente"}),e.jsx(N,{"data-loc":"client\\src\\pages\\Contracts.tsx:1053",children:"Título"}),e.jsx(N,{"data-loc":"client\\src\\pages\\Contracts.tsx:1054",children:"Tipo"}),e.jsx(N,{"data-loc":"client\\src\\pages\\Contracts.tsx:1055",children:"Valor Mensal"}),e.jsx(N,{"data-loc":"client\\src\\pages\\Contracts.tsx:1056",children:"Início"}),e.jsx(N,{"data-loc":"client\\src\\pages\\Contracts.tsx:1057",children:"Renovação"}),e.jsx(N,{"data-loc":"client\\src\\pages\\Contracts.tsx:1058",children:"Status"}),e.jsx(N,{"data-loc":"client\\src\\pages\\Contracts.tsx:1059",className:"text-right",children:"Ações"})]})}),e.jsx(Ee,{"data-loc":"client\\src\\pages\\Contracts.tsx:1062",children:_&&_.length>0?_.map(a=>e.jsxs(z,{"data-loc":"client\\src\\pages\\Contracts.tsx:1064",children:[e.jsx(h,{"data-loc":"client\\src\\pages\\Contracts.tsx:1065",className:"font-medium",children:a.customer?.name||"-"}),e.jsx(h,{"data-loc":"client\\src\\pages\\Contracts.tsx:1068",children:a.contract.title}),e.jsx(h,{"data-loc":"client\\src\\pages\\Contracts.tsx:1069",children:pe[a.contract.contractType]||a.contract.contractType}),e.jsx(h,{"data-loc":"client\\src\\pages\\Contracts.tsx:1072",children:J(a.contract.monthlyValue)}),e.jsx(h,{"data-loc":"client\\src\\pages\\Contracts.tsx:1073",children:I(a.contract.startDate)}),e.jsx(h,{"data-loc":"client\\src\\pages\\Contracts.tsx:1074",children:U(a.contract.renewalDate)?e.jsxs("span",{"data-loc":"client\\src\\pages\\Contracts.tsx:1076",className:"flex items-center gap-1 text-yellow-600",children:[e.jsx(de,{"data-loc":"client\\src\\pages\\Contracts.tsx:1077",className:"h-3 w-3"}),I(a.contract.renewalDate)]}):I(a.contract.renewalDate)}),e.jsx(h,{"data-loc":"client\\src\\pages\\Contracts.tsx:1084",children:e.jsx(ve,{"data-loc":"client\\src\\pages\\Contracts.tsx:1085",className:`${_e[a.contract.status]?.color||"bg-gray-500"} text-white`,children:_e[a.contract.status]?.label||a.contract.status})}),e.jsx(h,{"data-loc":"client\\src\\pages\\Contracts.tsx:1091",className:"text-right",children:e.jsxs("div",{"data-loc":"client\\src\\pages\\Contracts.tsx:1092",className:"flex items-center justify-end gap-1",children:[e.jsx(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:1093",variant:"ghost",size:"icon",className:"h-8 w-8",onClick:()=>L(a),title:"Editar",children:e.jsx(je,{"data-loc":"client\\src\\pages\\Contracts.tsx:1100",className:"h-4 w-4"})}),e.jsxs(X,{"data-loc":"client\\src\\pages\\Contracts.tsx:1104",children:[e.jsx(Y,{"data-loc":"client\\src\\pages\\Contracts.tsx:1105",asChild:!0,children:e.jsx(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:1106",variant:"ghost",size:"icon",className:"h-8 w-8",title:"Gerar Contrato",children:e.jsx($,{"data-loc":"client\\src\\pages\\Contracts.tsx:1112",className:"h-4 w-4"})})}),e.jsxs(K,{"data-loc":"client\\src\\pages\\Contracts.tsx:1115",align:"end",children:[e.jsxs(j,{"data-loc":"client\\src\\pages\\Contracts.tsx:1116",onClick:()=>V(a,"license"),children:[e.jsx($,{"data-loc":"client\\src\\pages\\Contracts.tsx:1117",className:"h-4 w-4 mr-2"}),"Contrato de Licença"]}),e.jsxs(j,{"data-loc":"client\\src\\pages\\Contracts.tsx:1120",onClick:()=>V(a,"service"),children:[e.jsx($,{"data-loc":"client\\src\\pages\\Contracts.tsx:1121",className:"h-4 w-4 mr-2"}),"Contrato de Serviços"]}),e.jsx(ee,{"data-loc":"client\\src\\pages\\Contracts.tsx:1124"}),e.jsxs(j,{"data-loc":"client\\src\\pages\\Contracts.tsx:1125",onClick:()=>V(a,"termination"),className:"text-red-600",children:[e.jsx(Re,{"data-loc":"client\\src\\pages\\Contracts.tsx:1126",className:"h-4 w-4 mr-2"}),"Rescisão Antecipada"]})]})]}),e.jsxs(X,{"data-loc":"client\\src\\pages\\Contracts.tsx:1133",children:[e.jsx(Y,{"data-loc":"client\\src\\pages\\Contracts.tsx:1134",asChild:!0,children:e.jsx(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:1135",variant:"ghost",size:"icon",className:"h-8 w-8",title:"Imprimir",children:e.jsx(F,{"data-loc":"client\\src\\pages\\Contracts.tsx:1141",className:"h-4 w-4"})})}),e.jsxs(K,{"data-loc":"client\\src\\pages\\Contracts.tsx:1144",align:"end",children:[e.jsxs(j,{"data-loc":"client\\src\\pages\\Contracts.tsx:1145",onClick:()=>M(a,"license"),children:[e.jsx(F,{"data-loc":"client\\src\\pages\\Contracts.tsx:1146",className:"h-4 w-4 mr-2"}),"Imprimir Licença"]}),e.jsxs(j,{"data-loc":"client\\src\\pages\\Contracts.tsx:1149",onClick:()=>M(a,"service"),children:[e.jsx(F,{"data-loc":"client\\src\\pages\\Contracts.tsx:1150",className:"h-4 w-4 mr-2"}),"Imprimir Serviços"]}),e.jsx(ee,{"data-loc":"client\\src\\pages\\Contracts.tsx:1153"}),e.jsxs(j,{"data-loc":"client\\src\\pages\\Contracts.tsx:1154",onClick:()=>M(a,"termination"),className:"text-red-600",children:[e.jsx(F,{"data-loc":"client\\src\\pages\\Contracts.tsx:1155",className:"h-4 w-4 mr-2"}),"Imprimir Rescisão"]})]})]}),e.jsx(u,{"data-loc":"client\\src\\pages\\Contracts.tsx:1161",variant:"ghost",size:"icon",className:"h-8 w-8 text-red-600 hover:text-red-700",onClick:()=>xe(a.contract.id),title:"Excluir",children:e.jsx(fe,{"data-loc":"client\\src\\pages\\Contracts.tsx:1168",className:"h-4 w-4"})})]})})]},a.contract.id)):e.jsx(z,{"data-loc":"client\\src\\pages\\Contracts.tsx:1174",children:e.jsx(h,{"data-loc":"client\\src\\pages\\Contracts.tsx:1175",colSpan:8,className:"text-center text-muted-foreground",children:"Nenhum contrato encontrado"})})})]})})]})]})})}export{Ve as default};
