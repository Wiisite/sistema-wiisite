import{u as x,t as g,r as m,j as t}from"./index-B8o5CPxc.js";function u(){const i=x(),c=parseInt(i.id),{data:s,isLoading:n}=g.orders.getById.useQuery({id:c});if(m.useEffect(()=>{s&&!n&&setTimeout(()=>{window.print()},500)},[s,n]),n)return t.jsx("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:22",className:"flex items-center justify-center min-h-screen",children:t.jsx("p",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:23",className:"text-lg",children:"Carregando pedido..."})});if(!s)return t.jsx("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:30",className:"flex items-center justify-center min-h-screen",children:t.jsx("p",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:31",className:"text-lg text-red-600",children:"Pedido não encontrado"})});const{order:r,customer:d,items:l}=s,a=e=>new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(parseFloat(e)),o=e=>new Date(e).toLocaleDateString("pt-BR"),p={pending:"Pendente",approved:"Aprovado",in_production:"Em Produção",completed:"Concluído",cancelled:"Cancelado"};return t.jsxs(t.Fragment,{children:[t.jsx("style",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:59",children:`
        @media print {
          body {
            margin: 0;
            padding: 20px;
          }
          .no-print {
            display: none !important;
          }
          @page {
            margin: 1cm;
          }
        }
        
        .print-container {
          max-width: 210mm;
          margin: 0 auto;
          padding: 20px;
          font-family: Arial, sans-serif;
        }
        
        .header {
          border-bottom: 3px solid #2563eb;
          padding-bottom: 20px;
          margin-bottom: 30px;
        }
        
        .company-name {
          font-size: 28px;
          font-weight: bold;
          color: #1e40af;
          margin-bottom: 5px;
        }
        
        .document-title {
          font-size: 20px;
          font-weight: bold;
          color: #374151;
          margin-top: 10px;
        }
        
        .info-section {
          margin-bottom: 25px;
        }
        
        .info-label {
          font-weight: bold;
          color: #4b5563;
          margin-right: 10px;
        }
        
        .info-value {
          color: #111827;
        }
        
        .items-table {
          width: 100%;
          border-collapse: collapse;
          margin: 20px 0;
        }
        
        .items-table th {
          background-color: #f3f4f6;
          padding: 12px;
          text-align: left;
          font-weight: bold;
          border-bottom: 2px solid #d1d5db;
        }
        
        .items-table td {
          padding: 10px 12px;
          border-bottom: 1px solid #e5e7eb;
        }
        
        .items-table tr:last-child td {
          border-bottom: none;
        }
        
        .total-row {
          background-color: #f9fafb;
          font-weight: bold;
          font-size: 16px;
        }
        
        .footer {
          margin-top: 40px;
          padding-top: 20px;
          border-top: 1px solid #d1d5db;
          text-align: center;
          color: #6b7280;
          font-size: 12px;
        }
        
        .no-print-button {
          position: fixed;
          top: 20px;
          right: 20px;
          padding: 10px 20px;
          background-color: #2563eb;
          color: white;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 14px;
          font-weight: 500;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .no-print-button:hover {
          background-color: #1d4ed8;
        }
      `}),t.jsx("button",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:172",className:"no-print no-print-button",onClick:()=>window.close(),children:"Fechar"}),t.jsxs("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:179",className:"print-container",children:[t.jsxs("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:180",className:"header",children:[t.jsx("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:181",className:"company-name",children:"Sistema ERP Empresarial"}),t.jsxs("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:182",className:"document-title",children:["Pedido #",r.orderNumber]})]}),t.jsx("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:185",className:"info-section",children:t.jsxs("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:186",style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"15px"},children:[t.jsxs("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:187",children:[t.jsx("span",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:188",className:"info-label",children:"Cliente:"}),t.jsx("span",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:189",className:"info-value",children:d?.name||"-"})]}),t.jsxs("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:191",children:[t.jsx("span",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:192",className:"info-label",children:"Data:"}),t.jsx("span",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:193",className:"info-value",children:o(r.orderDate)})]}),t.jsxs("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:195",children:[t.jsx("span",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:196",className:"info-label",children:"Status:"}),t.jsx("span",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:197",className:"info-value",children:p[r.status]})]}),t.jsxs("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:199",children:[t.jsx("span",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:200",className:"info-label",children:"Total:"}),t.jsx("span",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:201",className:"info-value",children:a(r.totalAmount)})]})]})}),r.notes&&t.jsxs("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:207",className:"info-section",children:[t.jsx("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:208",className:"info-label",children:"Observações:"}),t.jsx("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:209",className:"info-value",style:{marginTop:"5px"},children:r.notes})]}),t.jsxs("table",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:213",className:"items-table",children:[t.jsx("thead",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:214",children:t.jsxs("tr",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:215",children:[t.jsx("th",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:216",children:"Produto"}),t.jsx("th",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:217",style:{textAlign:"center"},children:"Quantidade"}),t.jsx("th",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:218",style:{textAlign:"right"},children:"Preço Unit."}),t.jsx("th",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:219",style:{textAlign:"right"},children:"Subtotal"})]})}),t.jsxs("tbody",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:222",children:[l.map(e=>t.jsxs("tr",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:224",children:[t.jsx("td",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:225",children:e.product?.name||`Produto #${e.item.productId}`}),t.jsx("td",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:226",style:{textAlign:"center"},children:e.item.quantity}),t.jsx("td",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:227",style:{textAlign:"right"},children:a(e.item.unitPrice)}),t.jsx("td",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:228",style:{textAlign:"right"},children:a(e.item.subtotal)})]},e.item.id)),t.jsxs("tr",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:231",className:"total-row",children:[t.jsx("td",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:232",colSpan:3,style:{textAlign:"right",paddingRight:"20px"},children:"TOTAL:"}),t.jsx("td",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:235",style:{textAlign:"right"},children:a(r.totalAmount)})]})]})]}),t.jsxs("div",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:240",className:"footer",children:[t.jsxs("p",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:241",children:["Documento gerado em ",new Date().toLocaleString("pt-BR")]}),t.jsx("p",{"data-loc":"client\\src\\pages\\OrderPrint.tsx:242",children:"Sistema ERP Empresarial - Gestão Integrada"})]})]})]})}export{u as default};
