import{c as l,r as o}from"./index-B8o5CPxc.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=l("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);function p(){const[n,s]=o.useState(!1),[c,r]=o.useState(null);return{fetchAddress:o.useCallback(async d=>{const t=d.replace(/\D/g,"");if(t.length!==8)return r("CEP deve ter 8 dígitos"),null;s(!0),r(null);try{const a=await fetch(`https://viacep.com.br/ws/${t}/json/`);if(!a.ok)throw new Error("Erro ao buscar CEP");const e=await a.json();return e.erro?(r("CEP não encontrado"),null):{address:e.logradouro||"",neighborhood:e.bairro||"",city:e.localidade||"",state:e.uf||"",zipCode:e.cep||t}}catch{return r("Erro ao buscar endereço. Tente novamente."),null}finally{s(!1)}},[]),isLoading:n,error:c}}export{h as S,p as u};
